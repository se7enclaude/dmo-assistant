"""Base de cartes Yu-Gi-Oh! (anglais + français) tirée de l'API YGOPRODeck, en cache local."""
import json
import os
import re
import time
import unicodedata
import urllib.request

from rapidfuzz import fuzz, process

import sys
# version .exe (PyInstaller) : données et réglages à côté de l'exécutable
ROOT = os.path.dirname(sys.executable if getattr(sys, "frozen", False) else os.path.abspath(__file__))
APP_DIR = os.path.dirname(os.path.abspath(__file__))  # code + interface (remplacés par les mises à jour)
DATA = os.path.join(ROOT, "data")
CUSTOM_PATH = os.path.join(ROOT, "custom_cards.json")      # cartes ajoutées à la main (absentes de la base)
TRANSLATIONS_PATH = os.path.join(DATA, "translations_fr.json")  # traductions automatiques
API = "https://db.ygoprodeck.com/api/v7/cardinfo.php"
MAX_AGE_DAYS = 14

SOURCES = {
    "cards_en.json": "?misc=yes",
    "cards_fr.json": "?language=fr",
    "staples.json": "?staple=yes",
}

TYPES_FR = {
    "Normal Monster": "Monstre Normal", "Effect Monster": "Monstre à Effet",
    "Flip Effect Monster": "Monstre Flip à Effet", "Tuner Monster": "Monstre Syntoniseur",
    "Normal Tuner Monster": "Monstre Syntoniseur Normal", "Gemini Monster": "Monstre Gémeau",
    "Spirit Monster": "Monstre Spirit", "Toon Monster": "Monstre Toon", "Union Effect Monster": "Monstre Union",
    "Ritual Monster": "Monstre Rituel", "Ritual Effect Monster": "Monstre Rituel à Effet",
    "Fusion Monster": "Monstre Fusion", "Synchro Monster": "Monstre Synchro",
    "Synchro Tuner Monster": "Monstre Synchro Syntoniseur", "Synchro Pendulum Effect Monster": "Monstre Synchro Pendule",
    "XYZ Monster": "Monstre Xyz", "XYZ Pendulum Effect Monster": "Monstre Xyz Pendule",
    "Link Monster": "Monstre Lien", "Pendulum Effect Monster": "Monstre Pendule à Effet",
    "Pendulum Normal Monster": "Monstre Pendule Normal", "Pendulum Effect Fusion Monster": "Monstre Fusion Pendule",
    "Pendulum Tuner Effect Monster": "Monstre Pendule Syntoniseur", "Pendulum Flip Effect Monster": "Monstre Pendule Flip",
    "Pendulum Effect Ritual Monster": "Monstre Rituel Pendule",
    "Spell Card": "Carte Magie", "Trap Card": "Carte Piège", "Skill Card": "Carte Compétence", "Token": "Jeton",
}
RACES_FR = {
    "Aqua": "Aqua", "Beast": "Bête", "Beast-Warrior": "Bête-Guerrier", "Creator-God": "Dieu Créateur",
    "Cyberse": "Cyberse", "Dinosaur": "Dinosaure", "Divine-Beast": "Bête Divine", "Dragon": "Dragon",
    "Fairy": "Elfe", "Fiend": "Démon", "Fish": "Poisson", "Insect": "Insecte", "Machine": "Machine",
    "Plant": "Plante", "Psychic": "Psychique", "Pyro": "Pyro", "Reptile": "Reptile", "Rock": "Rocher",
    "Sea Serpent": "Serpent de Mer", "Spellcaster": "Magicien", "Thunder": "Tonnerre", "Warrior": "Guerrier",
    "Winged Beast": "Bête Ailée", "Wyrm": "Wyrm", "Zombie": "Zombie", "Illusion": "Illusion",
    "Normal": "Normale", "Field": "Terrain", "Equip": "Équipement", "Continuous": "Continue",
    "Quick-Play": "Jeu-Rapide", "Ritual": "Rituelle", "Counter": "Contre-Piège",
}
ATTR_FR = {"DARK": "TÉNÈBRES", "LIGHT": "LUMIÈRE", "EARTH": "TERRE", "WATER": "EAU",
           "FIRE": "FEU", "WIND": "VENT", "DIVINE": "DIVIN"}


def norm(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "", s)


def ensure_data(force=False, log=print):
    """Télécharge les fichiers de cartes s'ils manquent ou sont trop vieux."""
    os.makedirs(DATA, exist_ok=True)
    for fname, query in SOURCES.items():
        path = os.path.join(DATA, fname)
        fresh = os.path.exists(path) and time.time() - os.path.getmtime(path) < MAX_AGE_DAYS * 86400
        if fresh and not force:
            continue
        log(f"Téléchargement de {fname}…")
        req = urllib.request.Request(API + query, headers={"User-Agent": "DMO-Assistant/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=180) as r:
                raw = r.read()
            json.loads(raw)  # vérifie que c'est du JSON valide avant d'écraser
            with open(path, "wb") as f:
                f.write(raw)
        except Exception as e:
            if not os.path.exists(path):
                raise RuntimeError(f"Impossible de télécharger {fname} : {e}")
            log(f"Échec de la mise à jour de {fname}, ancienne version conservée ({e})")


def _load(fname):
    with open(os.path.join(DATA, fname), encoding="utf-8") as f:
        return json.load(f)["data"]


class CardDB:
    def __init__(self):
        fr_list = _load("cards_fr.json")
        fr = {c["id"]: c for c in fr_list}
        fr_by_en = {norm(c.get("name_en")): c for c in fr_list if c.get("name_en")}
        self.cards = {}
        for c in _load("cards_en.json"):
            f = fr.get(c["id"]) or fr_by_en.get(norm(c["name"]), {})
            misc = (c.get("misc_info") or [{}])[0]
            ban = c.get("banlist_info") or {}
            self.cards[c["id"]] = {
                "id": c["id"],
                "name_en": c["name"],
                "name_fr": f.get("name") or c["name"],
                "desc_en": c.get("desc", ""),
                "desc_fr": f.get("desc") or "",
                "type": c.get("type", ""),
                "race": c.get("race", ""),
                "attribute": c.get("attribute"),
                "atk": c.get("atk"),
                "def": c.get("def"),
                "level": c.get("level"),
                "linkval": c.get("linkval"),
                "scale": c.get("scale"),
                "archetype": c.get("archetype"),
                "views": misc.get("views", 0),
                "ban_tcg": ban.get("ban_tcg"),
                "image": (c.get("card_images") or [{}])[0].get("image_url_small"),
                "images": [(i["id"], i["image_url_small"]) for i in c.get("card_images") or []],
            }
        self.staples = [c["id"] for c in _load("staples.json") if c["id"] in self.cards]
        self.load_translations()
        for c in self._load_custom():
            self.cards[c["id"]] = c
        self._reindex()

    def _reindex(self):
        """Index des noms normalisés (anglais + français) -> id."""
        self.index = {}
        for card in self.cards.values():
            for name in (card["name_en"], card["name_fr"]):
                k = norm(name)
                if k and (k not in self.index or card["views"] > self.cards[self.index[k]]["views"]):
                    self.index[k] = card["id"]
        self.keys = list(self.index)

    def load_translations(self):
        """Traductions automatiques pour les cartes sans texte français officiel."""
        if not os.path.exists(TRANSLATIONS_PATH):
            return 0
        with open(TRANSLATIONS_PATH, encoding="utf-8") as f:
            tr = json.load(f)
        try:  # réapplique le glossaire (il peut avoir été enrichi depuis la traduction)
            from translate import _post as fix
        except Exception:
            fix = lambda t: t
        n = 0
        for cid, text in tr.items():
            c = self.cards.get(int(cid))
            if c and (not c["desc_fr"] or c.get("fr_auto")):
                c["desc_fr"], c["fr_auto"] = fix(text), True
                n += 1
        return n

    @staticmethod
    def _load_custom():
        if not os.path.exists(CUSTOM_PATH):
            return []
        with open(CUSTOM_PATH, encoding="utf-8") as f:
            cards = json.load(f)
        for c in cards:
            c.setdefault("views", 10 ** 9)  # prioritaires dans les recherches
            c.setdefault("ban_tcg", None)
            c.setdefault("images", [])
            c.setdefault("custom", True)
        return cards

    def add_custom(self, fields):
        """Ajoute une carte absente de la base (anime, carte propre au jeu…). Renvoie la carte."""
        cards = self._load_custom()
        cid = min([-1] + [c["id"] - 1 for c in cards])
        name_fr = fields.get("name_fr") or fields.get("name_en") or "Carte sans nom"
        card = {
            "id": cid, "name_fr": name_fr, "name_en": fields.get("name_en") or name_fr,
            "desc_fr": fields.get("desc_fr") or "", "desc_en": fields.get("desc_en") or "",
            "type": fields.get("type") or "Effect Monster", "race": fields.get("race") or "",
            "attribute": fields.get("attribute") or None,
            "atk": fields.get("atk"), "def": fields.get("def"), "level": fields.get("level"),
            "linkval": None, "scale": None, "archetype": fields.get("archetype") or None,
            "image": None, "views": 10 ** 9, "ban_tcg": None, "images": [], "custom": True,
        }
        cards.append(card)
        with open(CUSTOM_PATH, "w", encoding="utf-8") as f:
            json.dump(cards, f, ensure_ascii=False, indent=2)
        self.cards[cid] = card
        self._reindex()
        return card

    def delete_custom(self, cid):
        cards = [c for c in self._load_custom() if c["id"] != int(cid)]
        with open(CUSTOM_PATH, "w", encoding="utf-8") as f:
            json.dump(cards, f, ensure_ascii=False, indent=2)
        self.cards.pop(int(cid), None)
        self._reindex()

    def __len__(self):
        return len(self.cards)

    def get(self, cid):
        return self.cards.get(cid)

    def match(self, text, min_score=80):
        """Meilleure carte correspondant à un texte (OCR ou saisie). Retourne (carte, score) ou (None, 0)."""
        k = norm(text)
        if len(k) < 4:
            return None, 0
        if k in self.index:
            return self.cards[self.index[k]], 100
        hit = process.extractOne(k, self.keys, scorer=fuzz.ratio, score_cutoff=min_score)
        if not hit:
            return None, 0
        return self.cards[self.index[hit[0]]], hit[1]

    def search(self, text, limit=25):
        """Recherche sur les noms FR/EN : d'abord les cartes contenant tous les mots tapés (dans n'importe
        quel ordre), nom exact puis début de nom, puis par popularité ; sinon recherche approximative."""
        k = norm(text)
        if not k:
            return []
        words = [w for w in (norm(x) for x in re.split(r"[\s\-,'’]+", text)) if w]
        if words:
            hits = {}
            for key, cid in self.index.items():
                if all(w in key for w in words):
                    rank = (key == k, key.startswith(k), key.startswith(words[0]), self.cards[cid]["views"])
                    if cid not in hits or rank > hits[cid]:
                        hits[cid] = rank
            if hits:
                best = sorted(hits, key=lambda cid: hits[cid], reverse=True)[:limit]
                out = [self.cards[cid] for cid in best]
                if len(out) >= limit:
                    return out
                seen = set(best)
                return out + [c for c in self._fuzzy_search(k, limit) if c["id"] not in seen][:limit - len(out)]
        return self._fuzzy_search(k, limit)

    def _fuzzy_search(self, k, limit):
        hits = process.extract(k, self.keys, scorer=fuzz.WRatio, limit=limit * 3)
        seen, out = set(), []
        for key, score, _ in sorted(hits, key=lambda h: (-(k in h[0]), -h[1])):
            cid = self.index[key]
            if cid not in seen:
                seen.add(cid)
                out.append(self.cards[cid])
            if len(out) >= limit:
                break
        return out

    # ---------- aide au deck ----------
    def archetype_cards(self, archetype):
        quoted = f'"{archetype}"'.lower()
        members = [c for c in self.cards.values() if c["archetype"] == archetype]
        support = [c for c in self.cards.values()
                   if c["archetype"] != archetype and quoted in c["desc_en"].lower()]
        key = lambda c: -c["views"]
        return sorted(members, key=key), sorted(support, key=key)

    def related(self, card, limit=20):
        """Cartes liées : même archétype, cartes qui la nomment, cartes qu'elle nomme."""
        out = []
        if card["archetype"]:
            members, support = self.archetype_cards(card["archetype"])
            out += members + support
        quoted = f'"{card["name_en"]}"'.lower()
        out += sorted((c for c in self.cards.values() if quoted in c["desc_en"].lower()), key=lambda c: -c["views"])
        for name in re.findall(r'"([^"]+)"', card["desc_en"]):
            cid = self.index.get(norm(name))
            if cid:
                out.append(self.cards[cid])
        seen, res = {card["id"]}, []
        for c in out:
            if c["id"] not in seen:
                seen.add(c["id"])
                res.append(c)
        return res[:limit]


def type_line(card):
    t = TYPES_FR.get(card["type"], card["type"])
    parts = [t]
    if "Monster" in card["type"]:
        if card["race"]:
            parts.append(RACES_FR.get(card["race"], card["race"]))
        if card["attribute"]:
            parts.append(ATTR_FR.get(card["attribute"], card["attribute"]))
    elif card["race"]:
        parts.append(RACES_FR.get(card["race"], card["race"]))
    return " · ".join(parts)


def stats_line(card):
    if "Monster" not in card["type"]:
        return ""
    bits = []
    if card["linkval"]:
        bits.append(f"LIEN-{card['linkval']}")
    elif card["level"]:
        bits.append(("Rang " if "XYZ" in card["type"] else "Niveau ") + str(card["level"]))
    if card["scale"] is not None:
        bits.append(f"Échelle {card['scale']}")
    bits.append(f"ATK {card['atk'] if card['atk'] is not None else '?'}")
    if card["def"] is not None:
        bits.append(f"DEF {card['def']}")
    return "  ·  ".join(bits)


def kind(card):
    t = card["type"]
    if t == "Spell Card":
        return "magie"
    if t == "Trap Card":
        return "piège"
    if any(x in t for x in ("Fusion", "Synchro", "XYZ", "Link")):
        return "extra"
    return "monstre"
