"""Capture d'écran + OCR Windows intégré (aucune installation de Tesseract nécessaire)."""
import asyncio
import ctypes
import ctypes.wintypes
import io

import mss
from PIL import Image
from winrt.windows.globalization import Language
from winrt.windows.graphics.imaging import BitmapDecoder
from winrt.windows.media.ocr import OcrEngine
from winrt.windows.storage.streams import DataWriter, InMemoryRandomAccessStream

_engine = None


def _get_engine():
    global _engine
    if _engine is None:
        _engine = OcrEngine.try_create_from_language(Language("en-US")) \
            or OcrEngine.try_create_from_user_profile_languages()
        if _engine is None:
            raise RuntimeError("Aucune langue OCR Windows disponible.")
    return _engine


async def _recognize(png):
    stream = InMemoryRandomAccessStream()
    writer = DataWriter(stream)
    writer.write_bytes(png)
    await writer.store_async()
    await writer.flush_async()
    writer.detach_stream()
    stream.seek(0)
    decoder = await BitmapDecoder.create_async(stream)
    bitmap = await decoder.get_software_bitmap_async()
    result = await _get_engine().recognize_async(bitmap)
    lines = []
    for line in result.lines:
        rects = [w.bounding_rect for w in line.words]
        top = min(r.y for r in rects)
        left = min(r.x for r in rects)
        height = max(r.y + r.height for r in rects) - top
        width = max(r.x + r.width for r in rects) - left
        lines.append({"text": line.text, "x": left, "y": top, "w": width, "h": height})
    return lines


def ocr_variants(img, scale=1.0):
    """OCR robuste pour les titres stylisés : image d'origine, puis contraste renforcé, inversée (texte clair
    sur fond sombre) et binarisée. Renvoie la liste des lectures [[lignes], …] (la 1re = image d'origine)."""
    from PIL import ImageOps
    import numpy as np
    gray = ImageOps.autocontrast(img.convert("L"), cutoff=2)
    arr = np.asarray(gray)
    thr = arr.mean()
    binar = Image.fromarray(((arr > thr) * 255).astype("uint8"))
    out = []
    for variant in (img, gray, ImageOps.invert(gray), binar):
        try:
            out.append(ocr_image(variant.convert("RGB"), scale))
        except Exception:
            out.append([])
    return out


def ocr_image(img, scale=1.0):
    """Retourne les lignes de texte d'une image PIL : [{'text','y','h'}]."""
    if scale != 1.0:
        img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
    buf = io.BytesIO()
    img.convert("RGB").save(buf, format="PNG")
    return asyncio.run(_recognize(buf.getvalue()))


def monitor_at(x, y):
    with mss.mss() as sct:
        for m in sct.monitors[1:]:
            if m["left"] <= x < m["left"] + m["width"] and m["top"] <= y < m["top"] + m["height"]:
                return m
        return sct.monitors[1]


def _monitor_under_cursor(monitors):
    pt = ctypes.wintypes.POINT()
    ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
    for m in monitors[1:]:
        if m["left"] <= pt.x < m["left"] + m["width"] and m["top"] <= pt.y < m["top"] + m["height"]:
            return m
    return monitors[1]


def grab(region=None, masks=()):
    """Capture une zone (left, top, width, height) ou l'écran où se trouve la souris. masks = rectangles à noircir."""
    with mss.mss() as sct:
        mon = _monitor_under_cursor(sct.monitors)
        if region:
            mon = {"left": region[0], "top": region[1], "width": region[2], "height": region[3]}
        shot = sct.grab(mon)
    img = Image.frombytes("RGB", shot.size, shot.rgb)
    if masks:
        from PIL import ImageDraw
        d = ImageDraw.Draw(img)
        for (x, y, w, h) in masks:
            d.rectangle([x - mon["left"], y - mon["top"], x - mon["left"] + w, y - mon["top"] + h], fill="black")
    return img
