"""Reconnaissance des cartes affichées dans le jeu par leur illustration.

DMO affiche les cartes comme une illustration (souvent avec un cadre et une barre ATK/DEF), sans
toujours écrire le nom : on retrouve la carte en comparant l'illustration à l'index YGOPRODeck.
Deux façons de viser :
- sous la souris : on cherche le rectangle de carte qui contient le pointeur ;
- zone d'illustration : l'utilisateur a encadré l'endroit où le jeu affiche la carte sélectionnée.
"""
import cv2
import numpy as np

from artindex import ART_BOX, ART_BOX_IN_ART

# distance d'empreinte (pHash + dHash + couleurs) en dessous de laquelle on fait confiance
SURE, MAYBE = 26, 36
HOVER_RADIUS = 330  # demi-taille de la zone capturée autour du pointeur (px)


def _order(pts):
    """Coins dans l'ordre haut-gauche, haut-droit, bas-droit, bas-gauche."""
    pts = np.asarray(pts, dtype=np.float32).reshape(4, 2)
    s, d = pts.sum(axis=1), np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype=np.float32)


def find_quads(img, cx, cy, min_side=40):
    """Cartes vues en perspective (posées sur le terrain 3D) : quadrilatères convexes contenant le pointeur.
    Renvoie [(coins ordonnés, aire)], du plus petit au plus grand."""
    gray = cv2.cvtColor(np.asarray(img.convert("RGB")), cv2.COLOR_RGB2GRAY)
    H, W = gray.shape
    found = []
    for lo, hi in ((20, 70), (40, 120), (70, 200)):
        edges = cv2.dilate(cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), lo, hi), np.ones((3, 3), np.uint8))
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            hull = cv2.convexHull(c)
            area = cv2.contourArea(hull)
            if area < min_side * min_side or area > W * H * 0.8:
                continue
            if cv2.pointPolygonTest(hull, (float(cx), float(cy)), False) < 0:
                continue
            approx = cv2.approxPolyDP(hull, 0.03 * cv2.arcLength(hull, True), True)
            if len(approx) == 4:
                quad = _order(approx)
            else:  # contour arrondi ou un peu bruité : rectangle tourné minimal, s'il colle bien
                rect = cv2.minAreaRect(hull)
                if area < 0.88 * rect[1][0] * rect[1][1]:
                    continue
                quad = _order(cv2.boxPoints(rect))
            tl, tr, br, bl = quad
            wq = (np.linalg.norm(tr - tl) + np.linalg.norm(br - bl)) / 2
            hq = (np.linalg.norm(bl - tl) + np.linalg.norm(br - tr)) / 2
            if wq < min_side or hq < min_side or not 0.5 <= wq / hq <= 1.3:
                continue
            if any(np.abs(quad - q).max() < 6 for q, _ in found):
                continue
            found.append((quad, area))
    return sorted(found, key=lambda f: f[1])


def rectify(img, quad, out_w=240):
    """Redresse une carte vue en perspective : image vue de face."""
    tl, tr, br, bl = quad
    wq = (np.linalg.norm(tr - tl) + np.linalg.norm(br - bl)) / 2
    hq = (np.linalg.norm(bl - tl) + np.linalg.norm(br - tr)) / 2
    out_h = max(20, int(out_w * hq / max(wq, 1)))
    dst = np.float32([[0, 0], [out_w - 1, 0], [out_w - 1, out_h - 1], [0, out_h - 1]])
    M = cv2.getPerspectiveTransform(quad.astype(np.float32), dst)
    from PIL import Image
    return Image.fromarray(cv2.warpPerspective(np.asarray(img.convert("RGB")), M, (out_w, out_h)))


def art_of(card):
    """Partie illustration d'une carte redressée : le carré du haut si la carte a une barre (ATK/DEF, icône)."""
    w, h = card.size
    if h > w * 1.12:
        return card.crop((int(w * 0.04), int(h * 0.025), int(w * 0.96), int(h * 0.025 + w * 0.92)))
    return card


def _quad_views(img, cx, cy):
    """[(image à comparer, rectangle englobant)] pour chaque carte en perspective sous le pointeur."""
    out = []
    for quad, _ in find_quads(img, cx, cy)[:8]:
        card = rectify(img, quad)
        x0, y0 = quad.min(axis=0)
        x1, y1 = quad.max(axis=0)
        rect = [int(x0), int(y0), int(x1 - x0), int(y1 - y0)]
        out.append((art_of(card), rect))
        if art_of(card) is not card:
            out.append((card, rect))
    return out


def _candidates(img, cx, cy):
    """Rectangles susceptibles d'être la carte sous le pointeur (cx, cy), du plus petit au plus grand."""
    rgb = np.asarray(img.convert("RGB"))
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    H, W = gray.shape
    rects = []
    for lo, hi in ((25, 90), (50, 150), (80, 220)):
        edges = cv2.Canny(cv2.GaussianBlur(gray, (3, 3), 0), lo, hi)
        edges = cv2.dilate(edges, np.ones((2, 2), np.uint8))
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            if w < 50 or h < 50 or w > W * 0.95 or h > H * 0.95:
                continue
            if not 0.5 <= w / h <= 1.7:
                continue
            if not (x - 4 <= cx <= x + w + 4 and y - 4 <= cy <= y + h + 4):
                continue
            if cv2.contourArea(cv2.convexHull(c)) < 0.7 * w * h:
                continue
            rects.append((x, y, w, h))
            if h > w * 1.12:  # carte avec barre de stats : l'illustration est le carré du haut
                rects.append((x, y, w, w))
    out = []
    for r in sorted(set(rects), key=lambda r: r[2] * r[3]):
        if not any(max(abs(a - b) for a, b in zip(r, o)) <= 4 for o in out):
            out.append(r)
    # repli : fenêtres carrées centrées sur le pointeur
    for s in (110, 150, 200, 260, 330):
        x, y = max(0, cx - s // 2), max(0, cy - s // 2)
        if x + s <= W and y + s <= H:
            out.append((x, y, s, s))
    return out[:40]


def card_rect_at(img, cx, cy):
    """Cadre de la carte sous le pointeur, trouvé par sa forme seule (sans base d'illustrations) :
    rectangle à 4 coins contenant le pointeur. Renvoie le rectangle de l'ILLUSTRATION (x, y, w, h) ou None.
    Sert à apprendre une carte que la base ne connaît pas."""
    gray = cv2.cvtColor(np.asarray(img.convert("RGB")), cv2.COLOR_RGB2GRAY)
    H, W = gray.shape
    quads = []
    for lo, hi in ((25, 90), (50, 150), (80, 220)):
        edges = cv2.dilate(cv2.Canny(cv2.GaussianBlur(gray, (3, 3), 0), lo, hi), np.ones((2, 2), np.uint8))
        thick = cv2.dilate(edges, np.ones((3, 3), np.uint8)) > 0
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            if w < 50 or h < 50 or w > W * 0.9 or h > H * 0.9 or not (x <= cx <= x + w and y <= cy <= y + h):
                continue
            # vrai rectangle : ses 4 côtés suivent des bords de l'image (pas une forme dans l'illustration).
            # Chaque côté est mesuré sur une bande de ±2 px (le contour peut être décalé d'un pixel ou deux).
            x1, y1 = min(x + w - 1, W - 1), min(y + h - 1, H - 1)
            band = lambda a, b: slice(max(0, a - 2), b + 3)
            sides = [thick[band(y, y), x:x1].any(axis=0).mean(), thick[band(y1, y1), x:x1].any(axis=0).mean(),
                     thick[y:y1, band(x, x)].any(axis=1).mean(), thick[y:y1, band(x1, x1)].any(axis=1).mean()]
            if sorted(sides)[1] < 0.85 or min(sides) < 0.5:  # tolère un côté en partie caché
                continue
            ratio = w / h
            if 0.6 <= ratio <= 0.85:            # carte entière (illustration + barre de stats en dessous)
                b = int(w * 0.045)
                quads.append((0, w * h, (x + b, y + b, w - 2 * b, w - 2 * b)))
            elif 0.85 < ratio <= 1.18:          # illustration seule
                quads.append((1, w * h, (x, y, w, h)))
    if not quads:
        return None
    # carte entière de préférence ; la plus petite qui contient le pointeur (évite les panneaux autour)
    quads.sort(key=lambda q: (q[0], q[1]))
    return quads[0][2]


def card_at(img, cx, cy):
    """Carte entière redressée sous le pointeur (pour lire sa barre : type, ATK/DEF) : (image, rect) ou None."""
    quads = find_quads(img, cx, cy)
    if not quads:
        return None
    quad = quads[0][0]
    x0, y0 = quad.min(axis=0)
    x1, y1 = quad.max(axis=0)
    return rectify(img, quad), [int(x0), int(y0), int(x1 - x0), int(y1 - y0)]


def count_stars(bar):
    """Nombre d'étoiles de niveau (pastilles rouges/orangées en haut de la barre), 0 si aucune."""
    hsv = cv2.cvtColor(np.asarray(bar.convert("RGB")), cv2.COLOR_RGB2HSV)
    top = hsv[: max(4, int(hsv.shape[0] * 0.45))]
    h, s, v = top[..., 0].astype(int), top[..., 1], top[..., 2]
    # étoiles : rouge vif et lumineux ; le fond de barre DMO est d'une teinte proche mais plus sombre
    mask = (((h <= 12) | (h >= 170)) & (s > 110) & (v > 110)).astype(np.uint8)
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    if n <= 1:
        return 0
    areas = stats[1:, cv2.CC_STAT_AREA]
    big = areas[areas >= max(4, 0.35 * np.median(areas))]
    # indice approximatif (reflets, icône d'attribut…) : sert seulement à départager des candidats
    return int(len(big)) if 1 <= len(big) <= 12 else 0


def _bar(card):
    """Barre sous l'illustration d'une carte façon anime/DMO, ou None si la carte n'en a pas."""
    w, h = card.size
    if h < w * 1.12:
        return None
    bar = card.crop((int(w * 0.06), int(h * 0.025 + w * 0.95), int(w * 0.94), int(h * 0.97)))
    return bar if bar.height >= 8 else None


def bar_kind(card):
    """Type de carte d'après la couleur de la barre : monstre (orange/jaune), magie (vert), piège (rose), extra."""
    import colorsys
    bar = _bar(card)
    if bar is None:
        return None
    px = np.asarray(bar.convert("RGB")).reshape(-1, 3).astype(float) / 255
    r, g, b = np.median(px, axis=0)
    hue, light, sat = colorsys.rgb_to_hls(r, g, b)
    hue *= 360
    if sat < 0.18:
        return "extra" if light < 0.35 else None        # noir : Xyz ; blanc/gris : Synchro ou neutre
    if 75 <= hue < 170:
        return "magie"
    if 280 <= hue < 345:
        return "piège"
    if 245 <= hue < 280:
        return "extra"                                    # violet : Fusion
    if 10 <= hue < 70 or hue >= 345:
        return "monstre"
    return None


# couleur de la barre sous l'illustration (cartes façon anime) -> type de carte
def card_hints(card):
    """Indices lus sur une carte redressée : type (couleur de la barre) et ATK/DEF (chiffres de la barre)."""
    import re
    w, h = card.size
    hints = {}
    bar = _bar(card)
    if bar is None:
        return hints
    hints["kind"] = bar_kind(card)
    level = count_stars(bar)
    if level:
        hints["level"] = level
    try:
        import screen_ocr
        lines = sorted(screen_ocr.ocr_image(bar, 3.0 if bar.height < 50 else 2.0), key=lambda l: l["x"])  # ATK à gauche
        nums = [int(n) for l in lines for n in re.findall(r"\d{1,4}", l["text"].replace("O", "0"))
                if int(n) % 50 == 0 and int(n) <= 5000]
        if len(nums) >= 2:
            hints["atk"], hints["def"] = nums[-2], nums[-1]
            hints["kind"] = "monstre" if hints.get("kind") not in ("monstre", "extra") else hints["kind"]
        elif len(nums) == 1:
            hints["stat"] = nums[0]  # une seule valeur lue : ATK ou DEF
    except Exception:
        pass
    return {k: v for k, v in hints.items() if v is not None}


OCR_FIX = str.maketrans({"O": "0", "o": "0", "D": "0", "G": "6", "b": "6", "S": "5", "s": "5", "B": "8", "I": "1",
                          "l": "1", "|": "1", "Z": "2", "z": "2", "A": "4", "q": "9", "g": "9", "T": "7"})


def read_atk(card):
    """ATK écrite dans la case de gauche de la barre (inventaire DMO, où la DEF est souvent cachée)."""
    import re
    import screen_ocr
    w, h = card.size
    box = card.crop((int(w * 0.05), int(h * 0.80), int(w * 0.50), int(h * 0.98)))
    for lines in screen_ocr.ocr_variants(box, 4.0):
        for l in lines:
            for n in re.findall(r"\d{3,4}|\b0\b", l["text"].translate(OCR_FIX)):
                if int(n) % 50 == 0 and int(n) <= 5000:
                    return int(n)
    return None


def read_quantity(card):
    """Nombre d'exemplaires (chiffre blanc dans le badge sombre en bas à droite, inventaire DMO), ou None."""
    import screen_ocr
    from PIL import Image
    w, h = card.size
    badge = card.crop((int(w * 0.72), int(h * 0.84), int(w * 0.99), int(h * 0.995)))  # sous l'icône d'attribut
    a = np.asarray(badge.convert("L")).astype(float)
    if a.size == 0 or a.mean() > 120:  # pas de badge sombre
        return None
    white = a > 200
    ys, xs = np.nonzero(white)
    if len(xs) < 6:
        return None
    digit = Image.fromarray(np.where(white, 0, 255).astype("uint8")).crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
    dw, dh = digit.size
    # chiffre répété 3 fois (« 222 ») : l'OCR lit bien mieux un nombre qu'un caractère isolé
    canvas = Image.new("L", (dw * 7, dh * 3), 255)
    for k in range(3):
        canvas.paste(digit, (dw + k * int(dw * 1.6), dh))
    votes = {}
    for scale in (3.0, 5.0):
        for l in screen_ocr.ocr_image(canvas.convert("RGB"), scale):
            for ch in l["text"].translate(OCR_FIX):
                if ch.isdigit():
                    votes[ch] = votes.get(ch, 0) + 1
    if not votes:
        return None
    q = int(max(votes, key=votes.get))
    return q if q > 0 else None


def candidates_from_hints(db, hints):
    """Cartes compatibles avec ce qui est lu sur la carte : type + ATK/DEF (le niveau ne sert qu'à classer)."""
    from carddb import kind
    pool = db.cards.values()
    if hints.get("kind"):
        pool = [c for c in pool if kind(c) == hints["kind"] or (hints["kind"] == "monstre" and kind(c) == "extra")]
    if "atk" in hints:
        return [c for c in pool if c["atk"] == hints["atk"] and c["def"] == hints["def"]]
    if "atk_only" in hints:
        return [c for c in pool if c["atk"] == hints["atk_only"]]
    if "stat" in hints:
        return [c for c in pool if hints["stat"] in (c["atk"], c["def"])]
    return []


def rank_candidates(art, hints, db, index, k=6):
    """Cartes compatibles avec les indices, de la plus ressemblante à la moins ressemblante (propositions)."""
    cands = candidates_from_hints(db, hints)
    if not cands:
        return []
    dist = index.distances(art, [c["id"] for c in cands])
    cands.sort(key=lambda c: dist.get(c["id"], 99))
    return [c["id"] for c in cands[:k]]


def identify(art, hints, db, index):
    """Illustration (éventuellement inconnue) + indices lus sur la carte -> {id, dist, conf, how} ou None.
    Une ATK/DEF exacte réduit la base à quelques cartes : on prend celle dont l'illustration ressemble le plus,
    si elle est seule ou nettement devant (ou au bon niveau)."""
    r = index.best(art, modes=("art",), insets=(0.0, 0.04, 0.08))
    if r and "atk" in hints:
        c = db.get(r[0])
        if c and (c["atk"], c["def"]) != (hints["atk"], hints["def"]):
            r = None if r[1] >= 12 else r  # l'ATK/DEF lue contredit l'illustration (sauf ressemblance quasi parfaite)
    if r and r[1] < SURE:
        return {"id": r[0], "dist": r[1], "conf": "sûr", "how": "illustration"}
    cands = candidates_from_hints(db, hints)
    if cands and len(cands) <= 600:
        dist = index.distances(art, [c["id"] for c in cands])
        ranked = sorted(cands, key=lambda c: dist.get(c["id"], 99) - (4 if c["level"] == hints.get("level") else 0))
        best = ranked[0]
        d0 = dist.get(best["id"], 99)
        gap = (dist.get(ranked[1]["id"], 99) - d0) if len(ranked) > 1 else 99
        exact = "atk" in hints  # ATK ET DEF lues : très discriminant ; ATK seule : beaucoup moins
        few = exact and len(ranked) <= 3
        # « sûr » seulement avec une vraie preuve : une seule carte possible, ou nettement la plus ressemblante
        sure = (exact and len(ranked) == 1 and d0 < 44) or (few and gap >= 6 and d0 < 40) or (gap >= 8 and d0 < 32) \
            or d0 < SURE
        if sure or few or d0 < 34:
            return {"id": best["id"], "dist": d0, "conf": "sûr" if sure else "probable", "how": "stats",
                    "alts": [c["id"] for c in ranked[1:6]]}
    if r and r[1] < MAYBE:
        return {"id": r[0], "dist": r[1], "conf": "probable", "how": "illustration"}
    return None


def card_art_at(img, cx, cy):
    """Illustration de la carte sous le pointeur, redressée si elle est vue en perspective.
    Renvoie (image de l'illustration, rectangle englobant) ou None. Sert à apprendre une carte."""
    views = _quad_views(img, cx, cy)
    if views:
        return views[0]
    rect = card_rect_at(img, cx, cy)
    if rect:
        x, y, w, h = rect
        return img.crop((x, y, x + w, y + h)), list(rect)
    return None


def analyze_at(img, cx, cy, index):
    """Meilleure zone de carte sous (cx, cy), quelle que soit la confiance : {id, dist, rect} ou None."""
    best = None
    views = _quad_views(img, cx, cy)
    views += [(img.crop((x, y, x + w, y + h)), [x, y, w, h]) for (x, y, w, h) in _candidates(img, cx, cy)]
    for crop, rect in views:
        r = index.best(crop, insets=(0.0, 0.04, 0.08))
        if r and (best is None or r[1] < best["dist"]):
            best = {"id": r[0], "dist": r[1], "rect": rect, "crop": crop}
    return best


def recognize_at(img, cx, cy, index):
    """Carte sous le point (cx, cy) de l'image. Renvoie {id, dist, rect, conf} ou None."""
    best = analyze_at(img, cx, cy, index)
    if not best or best["dist"] >= MAYBE:
        return None
    best["conf"] = "sûr" if best["dist"] < SURE else "probable"
    return best


def suggestions(img, index, k=8):
    """Cartes dont l'illustration ressemble le plus à cette image (pour l'apprentissage)."""
    seen, out = set(), []
    for box in (ART_BOX_IN_ART, ART_BOX):
        for cid, d in index.match(img, k=k, box=box):
            if cid not in seen:
                seen.add(cid)
                out.append((cid, d))
    return [cid for cid, d in sorted(out, key=lambda x: x[1])[:k]]


def recognize_zone(img, index):
    """Illustration encadrée par l'utilisateur. Renvoie {id, dist, conf} ou None."""
    r = index.best(img, insets=(0.0, 0.03, 0.06, 0.1))
    if not r or r[1] >= MAYBE:
        return None
    return {"id": r[0], "dist": r[1], "conf": "sûr" if r[1] < SURE else "probable"}
