/* Écran d'accueil façon menu de jeu : menu au clavier/souris, carte vedette, encart des nouveautés. */
(function () {
  const FEATURED = [
    { art: "img/art-dragon-blanc.webp", card: "img/carte-dragon-blanc.webp" },
    { art: "img/art-magicien.webp", card: "img/carte-magicien-sombre.webp" },
    { art: "img/art-dragon-noir.webp", card: "img/carte-dragon-noir.webp" },
  ];
  const ITEMS = [
    { label: "Traduire", sub: "reconnaître une carte", go: () => goTab("card") },
    { label: "Deck", sub: "mes decks", go: () => goTab("deck") },
    { label: "Deck parfait", sub: "deck + collection", go: () => { goTab("deck"); setTimeout(() => window.openAtelier && openAtelier(), 80); } },
    { label: "Collection", sub: "mes cartes", go: () => goTab("collection") },
    { label: "Générer", sub: "créer un deck", go: () => goTab("build") },
    { label: "Contact", sub: "Discord, pseudo", go: () => goTab("contact") },
    { label: "Aide", sub: "touches, tutoriel", go: () => goTab("help") },
    { label: "Quitter", sub: "", go: () => api().close() },
  ];
  let sel = 0, el = null, slides = [], slide = 0, timer = null;

  function render(info, version) {
    const f = FEATURED[Math.floor(Math.random() * FEATURED.length)];
    const sparks = [[62, 10], [80, 26], [55, 44], [90, 60], [70, 72], [48, 18], [86, 40]]
      .map(([x, y], i) => `<i class="spark" style="left:${x}%;top:${y}%;animation-delay:${i * .37}s"></i>`).join("");
    el.innerHTML = `
      <div class="ghost" style="background-image:url('${f.art}')"></div>
      <div class="streaks"></div>
      <div class="top"><div class="title"><b>SE<span>7</span>EN</b> DMO Assistant v${esc(version)}</div><div class="count" id="home-count"></div></div>
      <div class="stage"><div class="card"><img src="${f.card}" alt=""></div><div class="art" style="background-image:url('${f.art}')"></div>${sparks}</div>
      <nav class="menu" role="menu">${ITEMS.map((it, i) => `<button class="item" role="menuitem" data-i="${i}">
        <span>${esc(it.label)}${it.sub ? `<span class="sub">${esc(it.sub)}</span>` : ""}</span><span class="chev">›</span></button>`).join("")}</nav>
      ${slides.length ? `<div class="news" id="home-news"><button class="x" title="Fermer" data-x>✕</button>
        <div class="bar"><span id="news-title"></span><span>✦</span></div>
        <div class="pic" id="news-pic"><button class="arrow prev" data-step="-1">‹</button><button class="arrow next" data-step="1">›</button></div>
        <div class="cap" id="news-cap"></div><div class="pager" id="news-pager"></div></div>` : ""}
      <div class="hint"><kbd>↑</kbd> <kbd>↓</kbd> choisir · <kbd>Entrée</kbd> valider</div>`;
    const st = $("#status"); if (st) $("#home-count").textContent = st.textContent.replace(/[^0-9 ]+/g, " ").trim().split(" ")[0] || "";
    select(sel);
    showSlide(0);
  }
  function select(i) {
    sel = (i + ITEMS.length) % ITEMS.length;
    el.querySelectorAll(".item").forEach((b, j) => b.classList.toggle("on", j === sel));
  }
  function showSlide(i) {
    if (!slides.length || !el.querySelector("#news-cap")) return;
    slide = (i + slides.length) % slides.length;
    const s = slides[slide], f = FEATURED[slide % FEATURED.length];
    $("#news-title").textContent = s.title;
    $("#news-pic").style.backgroundImage = `url('${f.art}')`;
    $("#news-cap").innerHTML = `<small>${esc(s.date)}</small>${esc(s.text)}`;
    $("#news-pager").textContent = `${slide + 1}/${slides.length}`;
  }
  function choose(i) {
    const it = ITEMS[i];
    hideHome(() => it.go());
  }
  function onKey(e) {
    if (!el || el.classList.contains("out") || !$("#modal").classList.contains("hidden")) return;
    if (e.key === "ArrowDown") { select(sel + 1); e.preventDefault(); }
    else if (e.key === "ArrowUp") { select(sel - 1); e.preventDefault(); }
    else if (e.key === "Enter") { choose(sel); e.preventDefault(); }
    else if (e.key === "ArrowRight") showSlide(slide + 1);
    else if (e.key === "ArrowLeft") showSlide(slide - 1);
  }

  window.showHome = async function () {
    if (el) return;
    const io = await api().intro_settings();
    const news = await api().whats_new(true);
    slides = [];
    (news.entries || []).forEach((e) => (e.notes || []).forEach((n) => slides.push({ title: `Nouveautés v${e.version}`, date: e.date || "", text: n })));
    slides = slides.slice(0, 8);
    el = document.createElement("section");
    el.id = "home";
    const tb = document.querySelector(".titlebar");
    document.getElementById("app").style.setProperty("--home-top", (tb ? tb.offsetHeight : 52) + "px");
    document.getElementById("app").appendChild(el);
    render(news, io.version);
    api().set_layout("wide");
    el.addEventListener("mousemove", (e) => { const b = e.target.closest(".item"); if (b) select(+b.dataset.i); });
    el.addEventListener("click", (e) => {
      const b = e.target.closest(".item"); if (b) return choose(+b.dataset.i);
      const s = e.target.closest("[data-step]"); if (s) { showSlide(slide + +s.dataset.step); clearInterval(timer); return; }
      if (e.target.closest("[data-x]")) { const n = $("#home-news"); if (n) n.remove(); clearInterval(timer); }
    });
    timer = setInterval(() => showSlide(slide + 1), 6000);
  };
  window.homeOpen = () => !!el;
  window.hideHome = function (then) {
    if (!el) { if (then) then(); return; }
    const node = el; el = null; clearInterval(timer);
    node.classList.add("out");
    setTimeout(() => { node.remove(); if (then) then(); }, 200);
    if (!then) goTab(S.tab || "card");
  };
  document.addEventListener("keydown", onKey);
})();
