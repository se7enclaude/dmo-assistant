"use strict";
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const api = () => window.pywebview.api;
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const S = {
  hk: {}, tab: "card", current: null, others: [], related: null, showEn: false,
  collection: [], collKind: "", build: null, arch: null, ready: false,
};
const KIND_LABEL = { monstre: "Monstre", magie: "Magie", "piège": "Piège", extra: "Extra Deck" };
const KIND_COLOR = { monstre: "var(--monstre)", magie: "var(--magie)", "piège": "var(--piege)", extra: "var(--extra)" };
const WIDE_TABS = new Set(["card", "deck", "collection", "build", "contact", "help"]);  // tout en 1120 px
const HK_LABELS = { scan: "Scanner", learn: "Apprendre", zone: "Zone", auto: "Auto", hud: "Overlay", collection: "Collection", toggle: "Masquer" };

/* ------------------------------------------------------------------ images */
let missing = new Set(), missTimer = null;
// image chargée : fin de l'effet de chargement (voir theme.css)
document.addEventListener("load", (e) => { if (e.target.tagName === "IMG") e.target.dataset.loaded = "1"; }, true);
function img(c, cls = "") {
  if (c.img) return `<img class="${cls}" src="${c.img}" data-img="${c.id}" loading="lazy" decoding="async" alt="">`;
  missing.add(c.id);
  clearTimeout(missTimer);
  missTimer = setTimeout(() => { api().ensure_images([...missing]); missing = new Set(); }, 120);
  return `<div class="ph ${cls}" data-ph="${c.id}"></div>`;
}
function imageReady({ id, src }) {
  $$(`[data-ph="${id}"]`).forEach((ph) => {
    const im = document.createElement("img");
    im.decoding = "async"; im.src = src; im.className = ph.className.replace("ph", "").trim(); im.dataset.img = id;
    ph.replaceWith(im);
  });
}

/* ------------------------------------------------------------------ utilitaires */
function toast(msg) {
  $$(".toast").forEach((t) => t.remove());
  const t = document.createElement("div");
  t.className = "toast"; t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}
function setStatus(msg) { $("#status").textContent = msg; }
function kbd(action) { return `<kbd>${esc((S.hk[action] || "").toUpperCase())}</kbd>`; }
function fillKbds() {
  $$("kbd[data-hk]").forEach((k) => (k.textContent = (S.hk[k.dataset.hk] || "").toUpperCase()));
  $("#hk-bar").innerHTML = ["scan", "learn", "zone", "auto", "hud", "collection", "toggle"]
    .map((a) => `<span>${kbd(a)} ${HK_LABELS[a]}</span>`).join("");
  $("#help-keys").innerHTML = [
    ["scan", "Scanner et traduire la carte affichée"], ["learn", "Apprendre la carte visée (non reconnue)"],
    ["zone", "Définir la zone (illustration ou nom)"],
    ["auto", "Scan automatique (suit la carte)"], ["hud", "Activer / couper l'overlay sur le jeu"],
    ["collection", "Scanner ma collection"], ["toggle", "Afficher / masquer cette fenêtre"],
  ].map(([a, t]) => `<div class="help-key">${kbd(a)}<span>${t}</span></div>`).join("");
}
function modal(html) {
  $("#modal-body").innerHTML = html;
  $("#modal").classList.remove("hidden");
}
function closeModal() { $("#modal").classList.add("hidden"); }

/* ------------------------------------------------------------------ onglets */
function goTab(tab) {
  if (window.homeOpen && homeOpen()) { hideHome(() => goTab(tab)); return; }
  S.tab = tab;
  $$(".tab").forEach((b) => b.classList.toggle("active", b.dataset.tab === tab));
  $$(".panel").forEach((p) => p.classList.toggle("active", p.id === "tab-" + tab));
  api().set_layout(WIDE_TABS.has(tab) ? "wide" : "compact");
  if (!S.ready) return;
  if (tab === "deck") loadDeck();
  if (tab === "collection") loadCollection();
  if (tab === "build") loadArchetypes();
}

/* ------------------------------------------------------------------ vue carte */
function cardHTML(c, others = [], related = null) {
  const pills = [`<span class="pill k-${c.kind}">${esc(c.type_line)}</span>`];
  if (c.ban) pills.push(`<span class="pill ban">⛔ ${esc(c.ban)} (TCG)</span>`);
  if (c.owned) pills.push(`<span class="pill own">✓ ${c.owned}× dans ta collection</span>`);
  if (c.archetype) pills.push(`<span class="pill">Archétype : ${esc(c.archetype)}</span>`);
  if (c.custom) pills.push(`<span class="pill custom">Carte ajoutée par toi</span>`);
  if (c.unofficial) pills.push(`<span class="pill custom" title="Carte vue dans l'anime, le manga ou un jeu vidéo, jamais sortie en vrai">Carte anime / non officielle</span>`);
  if (c.fr_auto) pills.push(`<span class="pill auto" title="Pas de texte français officiel : traduit automatiquement depuis l'anglais">Traduction automatique</span>`);
  let effect = c.desc_fr ? esc(c.desc_fr) : c.desc_en ? `<span class="notr">Pas de traduction officielle française — texte anglais :</span>${esc(c.desc_en)}` : `<span class="notr">Pas d'effet renseigné.</span>`;
  if (c.desc_fr && S.showEn) effect += `<span class="orig">${esc(c.desc_en)}</span>`;
  const KANJI = { LIGHT: "光", DARK: "闇", FIRE: "炎", WATER: "水", WIND: "風", EARTH: "地", DIVINE: "神" };
  const attr = c.attribute ? { cls: c.attribute, k: KANJI[c.attribute] || "?" } : c.kind === "magie" ? { cls: "magie", k: "魔" } : c.kind === "piège" ? { cls: "piège", k: "罠" } : null;
  const isMon = c.atk !== undefined && c.atk !== null || (c.ctype || "").includes("Monster");
  const lv = c.linkval ? `LINK-${c.linkval}` : c.level ? `${(c.ctype || "").includes("XYZ") ? "☆" : "★"} ${c.level}` : "";
  const TW = { Normal: "Normal", Effect: "Effet", Fusion: "Fusion", Synchro: "Synchro", XYZ: "Xyz", Link: "Lien", Ritual: "Rituel",
    Pendulum: "Pendule", Tuner: "Syntoniseur", Flip: "Flip", Toon: "Toon", Spirit: "Spirit", Union: "Union", Gemini: "Gémeau", Token: "Jeton" };
  const words = (c.ctype || "").split(/\s+/).map((w) => TW[w]).filter(Boolean);
  if (words.length && !words.includes("Normal") && !words.includes("Effet") && !words.includes("Jeton") && !(c.ctype || "").includes("Normal")) words.push("Effet");
  const typeTxt = isMon ? `【${esc([c.race_fr, ...words].filter(Boolean).join("/"))}】` : `【${esc(c.type_line)}】`;
  const pillsRest = pills.slice(1);
  return `<div class="card-view md-detail" data-card="${c.id}">
    <div class="md-left">
      <div class="md-namebar"><div class="nm">${esc(c.name_fr)}${c.name_en !== c.name_fr ? `<span class="en">${esc(c.name_en)}</span>` : ""}</div>
        ${attr ? `<span class="attr-ico attr-${attr.cls}">${attr.k}</span>` : ""}</div>
      ${isMon ? `<div class="md-statrow"><span class="lv">${esc(lv)}</span><span class="ad"><span><b>ATK</b>${c.atk ?? "?"}</span>${c.linkval ? "" : `<span><b>DEF</b>${c.def_ ?? "?"}</span>`}</span></div>` : ""}
      <div class="md-typebar">${typeTxt}</div>
      <div class="effect">${effect}</div>
      ${pillsRest.length ? `<div class="pills">${pillsRest.join("")}</div>` : ""}
    </div>
    <div class="md-right">
      <div data-zoom="${c.id}">${img(c, "card-img")}</div>
      <div class="stepper"><label>Deck</label><button data-deck="-1">−</button><span data-deckn>${c.in_deck}</span><button data-deck="1">+</button></div>
      <div class="stepper"><label>Collec.</label><button data-own="-1">−</button><span data-ownn>${c.owned}</span><button data-own="1">+</button></div>
      <button class="btn sm" data-related>Cartes liées</button>
      ${c.custom ? `<button class="btn sm danger" data-delcard>Supprimer</button>` : ""}
      <label class="switch"><input type="checkbox" data-en ${S.showEn ? "checked" : ""}> Texte anglais</label>
    </div>
  </div>
  <div class="card-extra">
    ${others.length ? `<h3>Aussi détecté à l'écran</h3><div class="chips">${others.map((o) => `<span class="chip" data-open="${o.id}">${esc(o.name_fr)}</span>`).join("")}</div>` : ""}
    ${related ? `<h3>Cartes liées</h3>${related.length ? `<div class="card-grid">${related.map((r) => tile(r)).join("")}</div>` : `<div class="empty">Aucune carte liée trouvée.</div>`}` : ""}
  </div>`;
}

function bindCard(root, c) {
  root.onclick = async (e) => {
    const t = e.target.closest("[data-deck],[data-own],[data-related],[data-open],[data-zoom],[data-en],[data-delcard]");
    if (!t) return;
    if ("delcard" in t.dataset) {
      await api().delete_card(c.id);
      toast(`« ${c.name_fr} » supprimée`);
      if (S.tab === "card") emptyCard(); else closeModal();
      return;
    }
    if (t.dataset.deck) {
      const n = await api().deck_add(c.id, +t.dataset.deck);
      c.in_deck = n; $("[data-deckn]", root).textContent = n;
      toast(n ? `${c.name_fr} : ${n}× dans « ${$("#deck-select").value || "ton deck"} »` : `${c.name_fr} retirée du deck`);
      if (S.tab === "deck") loadDeck();
    } else if (t.dataset.own) {
      const n = await api().collection_set(c.id, (c.owned || 0) + +t.dataset.own);
      c.owned = n; $("[data-ownn]", root).textContent = n;
    } else if ("related" in t.dataset) {
      const rel = await api().related(c.id);
      root.innerHTML = cardHTML(c, [], rel);
    } else if (t.dataset.open) {
      openCard(+t.dataset.open);
    } else if (t.dataset.zoom) {
      const im = $("img", t);
      if (im) modal(`<img class="big-img" src="${im.src}">`);
    } else if ("en" in t.dataset) {
      S.showEn = t.checked; api().set_show_english(S.showEn);
      root.innerHTML = cardHTML(c, S.others);
    }
  };
}

function showCard(c, others = []) {
  S.current = c; S.others = others;
  const view = $("#card-view");
  view.innerHTML = cardHTML(c, others);
  bindCard(view, c);
}

async function openCard(id) {
  const c = await api().card(id);
  if (!c) return;
  if (S.tab === "card") return showCard(c);
  modal(`<div id="modal-card"></div>`);
  $("#modal-card").innerHTML = cardHTML(c);
  bindCard($("#modal-card"), c);
}

function emptyCard() {
  $("#card-view").innerHTML = `<div class="empty">
    <svg viewBox="0 0 24 24"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h3"/></svg>
    <div class="big">Aucune carte affichée</div>
    Pointe une carte dans le jeu avec la souris et appuie sur ${kbd("scan")},<br>active ${kbd("auto")} pour suivre la souris automatiquement,<br>ou cherche une carte ci-dessus.</div>`;
}

/* ------------------------------------------------------------------ recherche */
let searchTimer = null, searchSel = -1, searchRes = [];
function renderSearch() {
  const dd = $("#search-results");
  if (!searchRes.length) { dd.classList.add("hidden"); return; }
  dd.innerHTML = searchRes.map((c, i) => `<div class="dd-item ${i === searchSel ? "sel" : ""}" data-i="${i}">
    ${img(c)}<div class="t"><b>${esc(c.name_fr)}</b><span>${esc(c.name_en !== c.name_fr ? c.name_en + " · " : "")}${esc(c.type_line)}</span></div></div>`).join("");
  dd.classList.remove("hidden");
}
function pickSearch(i) {
  const c = searchRes[i];
  if (!c) return;
  searchRes = []; renderSearch(); $("#search").blur();
  openCard(c.id);
}

/* ------------------------------------------------------------------ deck */
function tile(c, opts = {}) {
  const qty = opts.qty ?? c.n;
  return `<div class="tile" data-open="${c.id}">
    ${img(c)}
    <span class="bar" style="background:${KIND_COLOR[c.kind]}"></span>
    ${qty ? `<span class="qty">${qty}</span>` : ""}
    ${opts.flag ? opts.flag : ""}
    ${opts.tools ? `<div class="tools">${opts.tools}</div>` : ""}
    <div class="nm">${esc(c.name_fr)}</div>
    ${c.reason ? `<div class="why">${esc(c.reason)}</div>` : ""}
  </div>`;
}
function groupedGrid(items, opts) {
  const order = ["monstre", "magie", "piège", "extra"];
  return order.map((k) => {
    const list = items.filter((c) => c.kind === k);
    if (!list.length) return "";
    const n = list.reduce((s, c) => s + (opts.count ? opts.count(c) : 1), 0);
    return `<div class="grid-title"><i style="background:${KIND_COLOR[k]}"></i>${KIND_LABEL[k]} · ${n}</div>` + list.map((c) => tile(c, opts.tile ? opts.tile(c) : {})).join("");
  }).join("");
}

async function loadDeck() {
  const d = await api().deck_get();
  S.deckItems = d.items;
  $("#deck-select").innerHTML = d.names.map((n) => `<option ${n === d.name ? "selected" : ""}>${esc(n)}</option>`).join("");
  const c = d.counts, main = c.main || 0, denom = Math.max(main, 40);
  $("#deck-stats").innerHTML = `<div class="stats-top"><div class="big">${main}<small> / 40 cartes</small></div><div class="big"><small>Extra</small> ${c.extra}<small> / 15</small></div></div>
    <div class="meter"><i style="width:${c.monstre / denom * 100}%;background:var(--monstre)"></i><i style="width:${c.magie / denom * 100}%;background:var(--magie)"></i><i style="width:${c["piège"] / denom * 100}%;background:var(--piege)"></i></div>
    <div class="legend"><span style="--c:var(--monstre)">${c.monstre} monstres</span><span style="--c:var(--magie)">${c.magie} magies</span><span style="--c:var(--piege)">${c["piège"]} pièges</span></div>`;
  $("#deck-list").innerHTML = d.items.length ? groupedGrid(d.items, {
    count: (x) => x.n,
    tile: (x) => ({ tools: `<button data-dk="${x.id}" data-d="-1">−</button><button data-dk="${x.id}" data-d="1">+</button>`,
      flag: S.collection.length || x.owned ? (x.owned >= x.n ? "" : `<span class="flag no">${x.owned}/${x.n} possédée</span>`) : "" }),
  }) : `<div class="empty" style="grid-column:1/-1"><div class="big">Deck vide</div>Ajoute des cartes depuis l'onglet Carte, les suggestions à droite,<br>importe un deck trouvé sur Internet, ou génère-en un depuis ta collection.<br><br>
    <div class="row" style="justify-content:center"><button class="btn primary" data-import>Importer depuis une image</button><button class="btn" data-tab-go="build">Générer un deck</button></div></div>`;
  $("#deck-tips").innerHTML = d.tips.map(([k, t]) => `<div class="tip ${k}">${k === "warn" ? "⚠" : k === "ok" ? "✓" : "ℹ"} <span>${esc(t)}</span></div>`).join("");
  $("#deck-suggestions").innerHTML = d.suggestions.map((g) => `<div class="sugg-group"><h3>${esc(g.title)}</h3>${g.cards.map((s) => `
    <div class="sugg-item" data-open="${s.id}">${img(s)}<div class="t"><b>${esc(s.name_fr)}</b><span><i class="own-dot ${s.owned ? "yes" : ""}"></i>${s.owned ? "Possédée" : "Non possédée"} · ${esc(KIND_LABEL[s.kind])}</span></div>
    <button class="add" data-dk="${s.id}" data-d="1" title="Ajouter au deck">+</button></div>`).join("")}</div>`).join("");
}

/* ------------------------------------------------------------------ collection */
async function loadCollection() {
  S.collection = await api().collection_get();
  $("#coll-count").textContent = S.collection.length;
  renderCollection();
}
function renderCollection() {
  const f = $("#coll-filter").value.trim().toLowerCase();
  const list = S.collection.filter((c) => (!S.collKind || c.kind === S.collKind) &&
    (!f || c.name_fr.toLowerCase().includes(f) || c.name_en.toLowerCase().includes(f)));
  $("#coll-list").innerHTML = list.length ? groupedGrid(list, {
    count: (x) => x.qty,
    tile: (x) => ({ qty: x.qty, tools: `<button data-ck="${x.id}" data-d="-1">−</button><button data-ck="${x.id}" data-d="1">+</button>` }),
  }) : `<div class="empty" style="grid-column:1/-1"><svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h10"/></svg>
    <div class="big">${S.collection.length ? "Aucun résultat" : "Ta collection est vide"}</div>
    ${S.collection.length ? "" : `Ouvre ton inventaire dans le jeu et appuie sur ${kbd("collection")}<br>ou colle une liste de cartes.`}</div>`;
}
function collectedLive(d) {
  const box = $("#collect-live");
  box.classList.remove("hidden");
  box.innerHTML = `<b>+${d.session}</b> nouvelle(s) carte(s) pendant ce scan · ${d.total} au total<br><span style="color:var(--fg-2)">Dernières : ${d.cards.map((c) => esc(c.name_fr)).join(", ")}</span>`;
  $("#coll-count").textContent = d.total;
  if (S.tab === "collection") loadCollection();
}
function importDialog() {
  modal(`<h2>Coller une liste de cartes</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:4px 0 10px">Une carte par ligne, en anglais ou en français, avec la quantité si tu veux :<br>
    <code>3 Ash Blossom &amp; Joyous Spring</code> · <code>Pot de Cupidité x2</code> · ou le contenu d'un fichier .ydk.</p>
    <textarea id="import-text" placeholder="3 Blue-Eyes White Dragon&#10;2 Sage with Eyes of Blue&#10;Called by the Grave"></textarea>
    <div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn primary" id="import-go">Ajouter à ma collection</button></div>
    <div id="import-res"></div>`);
  $("#import-go").onclick = async () => {
    const r = await api().collection_import($("#import-text").value);
    $("#import-res").innerHTML = `<div class="tip ok" style="margin-top:10px">✓ ${r.added} carte(s) ajoutée(s)</div>` +
      (r.unknown.length ? `<div class="tip warn">Non reconnues : ${r.unknown.map(esc).join(", ")}</div>` : "");
    loadCollection();
  };
}

/* ------------------------------------------------------------------ générateur */
async function loadArchetypes() {
  const assume3 = $("#assume3").checked;
  const opts = await api().archetype_options(assume3);
  const box = $("#arch-options");
  if (!opts.length) {
    box.innerHTML = `<div class="tip" style="grid-column:1/-1">ℹ <span>Aucun archétype détecté pour l'instant (il faut au moins 3 cartes d'un même archétype). Ajoute des cartes dans <b>Collection</b> — le générateur utilisera sinon tes meilleures cartes génériques.</span></div>`;
    S.arch = null;
    return;
  }
  if (!opts.some((o) => o.name === S.arch)) S.arch = null;
  box.innerHTML = `<div class="arch ${S.arch ? "" : "sel"}" data-arch=""><b>✨ Meilleur choix auto</b><span>Recommandé : ${esc(opts[0].name)}</span><div class="prog"><i style="width:100%"></i></div></div>` +
    opts.map((o) => `<div class="arch ${S.arch === o.name ? "sel" : ""}" data-arch="${esc(o.name)}"><b>${esc(o.name)}</b>
      <span>${o.owned} carte(s) possédée(s) sur ${o.total}</span><div class="prog"><i style="width:${Math.min(100, o.owned / Math.max(o.total, 1) * 100 * 2.5)}%"></i></div></div>`).join("");
}
async function runBuild() {
  const btn = $("#btn-build");
  btn.disabled = true; btn.textContent = "Génération…";
  try {
    S.build = await api().build_deck(S.arch, $("#assume3").checked);
    renderBuild();
  } finally {
    btn.disabled = false; btn.textContent = "Générer le deck";
  }
}
function renderBuild() {
  const b = S.build, c = b.counts;
  $("#build-result").innerHTML = `
    <div class="result-head">
      <div><h2 style="margin:0">${esc(b.archetype ? "Deck " + b.archetype : "Deck générique")}</h2>
        <span style="color:var(--muted);font-size:13px">${c.main} cartes · ${c.monstre} monstres · ${c.magie} magies · ${c["piège"]} pièges · Extra ${c.extra}</span></div>
      <div class="row"><input class="input" id="build-name" value="${esc(b.archetype ? b.archetype : "Deck généré")}" style="min-width:180px">
        <button class="btn primary" id="build-save" ${b.main.length ? "" : "disabled"}>Enregistrer comme deck</button></div>
    </div>
    ${b.warnings.map((w) => `<div class="tip warn" style="margin-top:10px">⚠ <span>${esc(w)}</span></div>`).join("")}
    <div class="card-grid">${groupedGrid([...b.main, ...b.extra], { count: (x) => x.n })}</div>
    ${b.missing.length ? `<h3>Cartes à obtenir pour l'améliorer</h3><div class="card-grid">${b.missing.map((m) => tile(m, { qty: 0 })).join("")}</div>` : ""}`;
  $("#build-save").onclick = async () => {
    const name = await api().apply_build($("#build-name").value, b.main, b.extra);
    toast(`Deck « ${name} » enregistré`);
    goTab("deck");
  };
}

/* ------------------------------------------------------------------ import d'un deck depuis une image */
const IMP = { cards: [], res: null, art: null, waiters: [] };
const CONF_RANK = { "sûr": 0, probable: 1, incertain: 2 };
const ICONS = {
  paste: `<svg viewBox="0 0 24 24"><rect x="7" y="4" width="10" height="4" rx="1"/><path d="M7 6H5v15h14V6h-2"/></svg>`,
  file: `<svg viewBox="0 0 24 24"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/></svg>`,
  screen: `<svg viewBox="0 0 24 24"><path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/></svg>`,
  image: `<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/></svg>`,
};

async function openImport() {
  if (S.tab !== "deck") goTab("deck");
  $("#imp").classList.remove("hidden");
  impStart();
  IMP.art = await api().art_status();
  if (!IMP.art.ready && !IMP.art.building) api().art_build();
  renderArtState();
}
function closeImport() { $("#imp").classList.add("hidden"); }

function renderArtState(err) {
  const box = $("#idx-state");
  if (!box || !IMP.art) return;
  const a = IMP.art;
  if (err) box.innerHTML = `<div class="tip warn">⚠ <span>Préparation impossible : ${esc(err)}. Vérifie ta connexion puis rouvre cette fenêtre.</span></div>`;
  else if (a.ready) box.innerHTML = `<div class="tip ok">✓ <span>Reconnaissance d'images prête (${a.count.toLocaleString("fr")} illustrations).</span></div>`;
  else box.innerHTML = `<div class="tip">⏳ <span style="flex:1">Première utilisation : préparation de la reconnaissance des illustrations (~1 min, une seule fois)…
    <div class="progress"><i style="width:${a.total ? (a.done / a.total) * 100 : 0}%"></i></div></span></div>`;
}
function artReady() {
  if (IMP.art && IMP.art.ready) return Promise.resolve();
  return new Promise((r) => IMP.waiters.push(r));
}

function impStart(error) {
  $("#imp-title").textContent = "Importer un deck";
  $("#imp-sub").textContent = "Depuis une capture d'écran trouvée sur Internet (YGOPRODeck, Master Duel, TikTok…) ou une liste de cartes.";
  $("#imp-body").innerHTML = `<div class="imp-start">
    <div id="idx-state" class="idx-state"></div>
    ${error ? `<div class="tip warn idx-state">⚠ <span>${esc(error)}</span></div>` : ""}
    <div class="drop" id="drop">
      ${ICONS.image.replace("<svg", '<svg class="big-ico"')}
      <p><b>Glisse une image ici</b> ou appuie sur <kbd>Ctrl</kbd>+<kbd>V</kbd> pour coller une capture</p>
      <button class="src-btn" data-src="clipboard">${ICONS.paste}<div><b>Coller depuis le presse-papiers</b><span>Après une capture Win+Maj+S ou « Copier l'image »</span></div></button>
      <button class="src-btn" data-src="file">${ICONS.file}<div><b>Ouvrir un fichier image</b><span>PNG, JPG, WEBP…</span></div></button>
      <button class="src-btn" data-src="screen">${ICONS.screen}<div><b>Capturer une zone de l'écran</b><span>Ouvre le deck dans ton navigateur, puis encadre les cartes</span></div></button>
    </div>
    <div class="text-imp">
      <b>…ou colle une liste de cartes</b>
      <span style="color:var(--muted);font-size:12.5px">Une carte par ligne, en anglais ou en français : <code>3 Ash Blossom &amp; Joyous Spring</code>, <code>Appelé par la Tombe x2</code>, ou le contenu d'un fichier .ydk.</span>
      <textarea id="imp-text" placeholder="3 Snake-Eye Ash&#10;3 Snake-Eyes Poplar&#10;2 Called by the Grave&#10;…"></textarea>
      <button class="btn" id="imp-text-go">Analyser la liste</button>
    </div>
  </div>`;
  renderArtState();
  $$("#imp-body [data-src]").forEach((b) => (b.onclick = () => runImport(() => api().import_image(b.dataset.src), true)));
  $("#imp-text-go").onclick = () => runImport(() => api().import_text($("#imp-text").value), false);
  const drop = $("#drop");
  drop.ondragover = (e) => { e.preventDefault(); drop.classList.add("over"); };
  drop.ondragleave = () => drop.classList.remove("over");
  drop.ondrop = (e) => {
    e.preventDefault(); drop.classList.remove("over");
    const f = [...e.dataTransfer.files].find((x) => x.type.startsWith("image/"));
    if (f) importBlob(f);
  };
}

function importBlob(blob) {
  const rd = new FileReader();
  rd.onload = () => runImport(() => api().import_image_data(rd.result), true);
  rd.readAsDataURL(blob);
}
document.addEventListener("paste", (e) => {
  if ($("#imp").classList.contains("hidden")) return;
  const item = [...(e.clipboardData?.items || [])].find((i) => i.type.startsWith("image/"));
  if (!item) return;
  if ($("#at-go") || $("#at-coll-add")) { e.preventDefault(); atImportBlobs(AT.target, [item.getAsFile()]); }  // atelier : colonne active
  else if ($("#drop")) { e.preventDefault(); importBlob(item.getAsFile()); }
});

async function runImport(fn, needsArt) {
  const body = $("#imp-body");
  if (needsArt && !(IMP.art && IMP.art.ready)) {
    body.innerHTML = `<div class="busy"><div><div class="spinner"></div>Préparation de la reconnaissance des illustrations…<div id="idx-state" style="margin-top:12px;min-width:340px"></div></div></div>`;
    renderArtState();
    await artReady();
  }
  body.innerHTML = `<div class="busy"><div><div class="spinner"></div>Analyse des cartes…</div></div>`;
  let res;
  try { res = await fn(); } catch (e) { return impStart("Erreur pendant l'analyse : " + e); }
  if (!res) return impStart();
  if (res.error) return impStart(res.error);
  if (!res.cards.length) {
    return impStart(res.mode === "texte" && !res.image ? "Aucune carte reconnue dans cette liste."
      : "Aucune carte reconnue sur cette image. Essaie une capture plus grande, recadrée sur les cartes.");
  }
  IMP.res = res;
  IMP.cards = res.cards.map((c, i) => ({ ...c, uid: i }));
  impReview();
}

function impGroups() {
  const map = new Map();
  for (const c of IMP.cards) {
    if (!map.has(c.id)) map.set(c.id, { card: c, items: [] });
    map.get(c.id).items.push(c);
  }
  const order = { monstre: 0, magie: 1, "piège": 2, extra: 3 };
  return [...map.values()].map((g) => ({ ...g, conf: g.items.reduce((w, c) => (CONF_RANK[c.conf] > CONF_RANK[w] ? c.conf : w), "sûr") }))
    .sort((a, b) => order[a.card.kind] - order[b.card.kind] || CONF_RANK[b.conf] - CONF_RANK[a.conf] || a.card.name_fr.localeCompare(b.card.name_fr));
}

function impReview() {
  const r = IMP.res, groups = impGroups();
  const main = IMP.cards.filter((c) => c.kind !== "extra").length, extra = IMP.cards.length - main;
  const doubt = IMP.cards.filter((c) => c.conf !== "sûr").length;
  $("#imp-title").textContent = `${IMP.cards.length} cartes reconnues`;
  $("#imp-sub").textContent = doubt ? `${doubt} à vérifier (en jaune/rouge) : clique dessus pour corriger.` : "Tout semble correct. Vérifie quand même d'un coup d'œil.";
  const over3 = groups.filter((g) => g.items.length > 3);
  const warns = [];
  if (main < 40) warns.push(`Main Deck : ${main} cartes (minimum 40). Des cartes ont peut-être été coupées sur l'image.`);
  if (main > 60) warns.push(`Main Deck : ${main} cartes (maximum 60) — l'image contient peut-être aussi le Side Deck.`);
  if (over3.length) warns.push(`Plus de 3 exemplaires : ${over3.map((g) => g.card.name_fr).join(", ")} (limité à 3 à la création).`);
  const boxes = r.image ? IMP.cards.filter((c) => c.rect).map((c) => {
    const [x, y, w, h] = c.rect;
    return `<div class="box ${c.conf === "sûr" ? "" : c.conf}" data-uid="${c.uid}" data-gid="${c.id}" title="${esc(c.name_fr)}"
      style="left:${x / r.width * 100}%;top:${y / r.height * 100}%;width:${w / r.width * 100}%;height:${h / r.height * 100}%"><b>${c.uid + 1}</b></div>`;
  }).join("") : "";
  $("#imp-body").innerHTML = `<div class="imp-review ${r.image ? "" : "noimg"}">
    ${r.image ? `<div class="imp-img"><div class="stage"><img src="${r.image}">${boxes}</div></div>` : ""}
    <div class="imp-side">
      <div class="imp-legend"><span><i style="background:var(--ok)"></i>Sûr</span><span><i style="background:var(--gold)"></i>Probable</span><span><i style="background:var(--danger)"></i>Incertain</span></div>
      <div class="imp-list">${groups.map((g) => `<div class="imp-row ${g.conf === "sûr" ? "" : g.conf}" data-gid="${g.card.id}">
        ${img(g.card)}<div class="t"><b>${esc(g.card.name_fr)}</b><span>${esc(KIND_LABEL[g.card.kind])}${g.conf !== "sûr" ? " · à vérifier" : ""}</span>
        ${g.items.length > 3 ? `<span class="warn3"> · max 3</span>` : ""}</div><span class="n">${g.items.length}×</span></div>`).join("")}</div>
      <div class="imp-foot">
        <div class="sum">Main Deck <b>${main}</b> · Extra Deck <b>${extra}</b></div>
        ${warns.map((w) => `<div class="tip warn" style="margin:0">⚠ <span>${esc(w)}</span></div>`).join("")}
        <input class="input" id="imp-name" placeholder="Nom du deck" value="Deck importé">
        <div class="row"><button class="btn primary" id="imp-create" style="flex:1">Créer le deck</button>
          <button class="btn" id="imp-coll" title="Ajouter ces cartes à ma collection">+ Collection</button>
          <button class="btn ghost" id="imp-restart">Recommencer</button></div>
      </div>
    </div></div>`;
  const hl = (gid, on) => $$(`[data-gid="${gid}"]`).forEach((el) => el.classList.toggle("hl", on));
  $$("#imp-body [data-gid]").forEach((el) => {
    el.onmouseenter = () => hl(el.dataset.gid, true);
    el.onmouseleave = () => hl(el.dataset.gid, false);
    el.onclick = () => impFix(+el.dataset.gid, el.dataset.uid !== undefined ? +el.dataset.uid : null);
  });
  $("#imp-restart").onclick = () => impStart();
  $("#imp-coll").onclick = async () => { const n = await api().collection_add_ids(IMP.cards.map((c) => c.id)); toast(`Ajoutées à ta collection (${n} cartes différentes)`); };
  $("#imp-create").onclick = async () => {
    const name = await api().create_deck($("#imp-name").value, IMP.cards.map((c) => c.id));
    closeImport(); toast(`Deck « ${name} » créé`); loadDeck();
  };
}

/* Corriger une carte : uid = un seul exemplaire (clic sur l'image), sinon tous les exemplaires de la carte.
   holder.cards = la liste à corriger, redraw = fonction de réaffichage (import simple ou atelier). */
function impFix(gid, uid, holder = IMP, redraw = impReview) {
  const impReview = redraw, IMP = holder;
  const targets = uid === null ? IMP.cards.filter((c) => c.id === gid) : IMP.cards.filter((c) => c.uid === uid);
  const c = targets[0];
  const alts = [...new Map(targets.flatMap((t) => t.alts).map((a) => [a.id, a])).values()];
  modal(`<div class="fix">
    <h2>${esc(c.name_fr)}</h2>
    <div style="color:var(--muted);font-size:12.5px">${esc(c.name_en)} · ${targets.length > 1 ? `${targets.length} exemplaires` : "1 exemplaire"} · reconnaissance : ${esc(c.conf)}</div>
    ${alts.length ? `<h3>Ce n'est pas la bonne ? Autres possibilités</h3><div class="alts">${alts.map((a) => tile(a, { qty: 0 }).replace('data-open="', 'data-pick="')).join("")}</div>` : ""}
    <h3>Chercher la bonne carte</h3>
    <div class="search-wrap"><svg class="search-ico" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/></svg>
      <input id="fix-q" placeholder="Nom en français ou en anglais…" autocomplete="off" style="width:100%;padding:10px 12px 10px 36px;border-radius:10px;border:1px solid var(--line);background:var(--bg);color:var(--fg);font:inherit;outline:none">
      <div id="fix-res" class="dropdown hidden"></div></div>
    <div class="row" style="margin-top:14px;justify-content:space-between">
      <div class="row"><button class="btn sm" id="fix-dup">+1 exemplaire</button>
        <button class="btn sm danger" id="fix-del1">Retirer 1</button>
        ${targets.length > 1 ? `<button class="btn sm danger" id="fix-delall">Retirer les ${targets.length}</button>` : ""}</div>
      <button class="btn sm primary" id="fix-ok">C'est la bonne carte ✓</button>
    </div></div>`);
  const apply = async (newId) => {
    const n = await api().card(newId);
    for (const t of targets) Object.assign(t, n, { conf: "sûr", rect: t.rect, uid: t.uid, alts: t.alts });
    closeModal(); impReview();
  };
  $$("#modal-body [data-pick]").forEach((el) => (el.onclick = () => apply(+el.dataset.pick)));
  let timer;
  $("#fix-q").oninput = (e) => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const res = e.target.value.trim().length > 1 ? await api().search(e.target.value) : [];
      const dd = $("#fix-res");
      dd.classList.toggle("hidden", !res.length);
      dd.innerHTML = res.map((r) => `<div class="dd-item" data-pick="${r.id}">${img(r)}<div class="t"><b>${esc(r.name_fr)}</b><span>${esc(r.name_en)}</span></div></div>`).join("");
      $$("#fix-res [data-pick]").forEach((el) => (el.onclick = () => apply(+el.dataset.pick)));
    }, 140);
  };
  $("#fix-q").focus();
  $("#fix-ok").onclick = () => { targets.forEach((t) => (t.conf = "sûr")); closeModal(); impReview(); };
  $("#fix-dup").onclick = () => { IMP.cards.push({ ...c, rect: null, uid: Math.max(...IMP.cards.map((x) => x.uid)) + 1000 + Math.floor(Math.random() * 1e6), conf: "sûr" }); closeModal(); impReview(); };
  $("#fix-del1").onclick = () => { IMP.cards = IMP.cards.filter((x) => x !== targets[targets.length - 1]); closeModal(); impReview(); };
  const all = $("#fix-delall");
  if (all) all.onclick = () => { IMP.cards = IMP.cards.filter((x) => !targets.includes(x)); closeModal(); impReview(); };
}

/* ------------------------------------------------------------------ recherche de carte avec quantité
   Tu tapes → suggestions (image, nom FR/EN, type) → clic = +1 exemplaire, ou 1/2/3 = quantité exacte.
   Clavier : ↑/↓ pour choisir, Entrée = +1, Échap = fermer. */
function pickerHTML(key, placeholder) {
  return `<div class="search-wrap picker"><svg class="search-ico" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/></svg>
    <input data-picker="${key}" placeholder="${esc(placeholder)}" autocomplete="off">
    <div class="dropdown hidden" data-picker-dd="${key}"></div></div>`;
}
function cardPicker(key, { getQty, setQty, max = 3 }) {
  const input = $(`[data-picker="${key}"]`), dd = $(`[data-picker-dd="${key}"]`);
  if (!input) return;
  let res = [], sel = 0, timer;
  const render = () => {
    if (!res.length) { dd.classList.add("hidden"); return; }
    dd.innerHTML = res.map((c, i) => {
      const have = getQty(c.id);
      return `<div class="dd-item pick ${i === sel ? "sel" : ""}" data-i="${i}">${img(c)}
        <div class="t"><b>${esc(c.name_fr)}</b><span>${esc(c.name_en !== c.name_fr ? c.name_en + " · " : "")}${esc(c.type_line)}</span></div>
        <div class="qty-btns">${[1, 2, 3].slice(0, max).map((q) => `<button data-q="${q}" class="${have === q ? "on" : ""}" title="${q} exemplaire(s)">${q}</button>`).join("")}</div></div>`;
    }).join("");
    dd.classList.remove("hidden");
  };
  const pick = async (i, q) => {
    const c = res[i];
    if (!c) return;
    const n = q ?? Math.min(max, getQty(c.id) + 1);
    await setQty(c, n);
    toast(`${c.name_fr} : ${n} exemplaire${n > 1 ? "s" : ""}`);
    input.value = ""; res = []; render(); input.focus();
  };
  input.oninput = () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const q = input.value.trim();
      res = q.length > 1 ? (await api().search(q)).slice(0, 8) : [];
      sel = 0; render();
    }, 120);
  };
  input.onkeydown = (e) => {
    if (e.key === "ArrowDown") { sel = Math.min(sel + 1, res.length - 1); render(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { sel = Math.max(sel - 1, 0); render(); e.preventDefault(); }
    else if (e.key === "Enter") { e.preventDefault(); pick(sel); }
    else if (e.key === "Escape") { res = []; render(); }
  };
  input.onblur = () => setTimeout(() => { res = []; render(); }, 150);
  dd.onmousedown = (e) => {
    e.preventDefault();  // garde le focus dans le champ
    const it = e.target.closest("[data-i]");
    if (!it) return;
    const b = e.target.closest("[data-q]");
    pick(+it.dataset.i, b ? +b.dataset.q : undefined);
  };
}

/* ------------------------------------------------------------------ atelier « deck parfait » */
const AT = { deck: [], coll: [], target: "deck", useDeck: false, useColl: false, assume3: false, result: null, uid: 1 };
const AT_SIDES = {
  deck: { title: "Mon deck", sub: "Captures de ton deck (une ou plusieurs)", icon: "🃏" },
  coll: { title: "Ma collection", sub: "Captures de ton inventaire (une ou plusieurs)", icon: "📦" },
};

async function openAtelier() {
  if (S.tab !== "deck") goTab("deck");
  AT.mode = "atelier";
  $("#imp").classList.remove("hidden");
  IMP.art = await api().art_status();
  if (!IMP.art.ready && !IMP.art.building) api().art_build();
  atelierRender();
}

/* onglet Collection : plusieurs captures de l'inventaire DMO d'un coup, quantités lues sur les cartes */
async function openCollImport() {
  if (S.tab !== "collection") goTab("collection");
  AT.mode = "collection"; AT.target = "coll";
  $("#imp").classList.remove("hidden");
  IMP.art = await api().art_status();
  if (!IMP.art.ready && !IMP.art.building) api().art_build();
  atelierRender();
}

function atAdd(side, results) {
  for (const res of results) {
    if (!res) continue;
    if (res.error) { toast(res.error); continue; }
    if (!res.cards.length) { toast(`${res.name || "Image"} : aucune carte reconnue`); continue; }
    AT[side].push({ name: res.name || `Image ${AT[side].length + 1}`, thumb: res.image,
      cards: res.cards.map((c) => ({ ...c, uid: AT.uid++ })) });
  }
  atelierRender();
}

async function atImport(side, how) {
  AT.target = side;
  const status = $(`#at-${side}-busy`);
  if (status) status.classList.remove("hidden");
  if (!(IMP.art && IMP.art.ready)) await artReady();
  try {
    if (how === "files") atAdd(side, await api().import_images_files());
    else atAdd(side, [await api().import_image(how)]);
  } finally { if (status) status.classList.add("hidden"); }
}
function atImportBlobs(side, blobs) {
  blobs.forEach((blob) => {
    const rd = new FileReader();
    rd.onload = async () => {
      if (!(IMP.art && IMP.art.ready)) await artReady();
      const res = await api().import_image_data(rd.result);
      res.name = blob.name || "Image collée";
      atAdd(side, [res]);
    };
    rd.readAsDataURL(blob);
  });
}

function atSide(side, st) {
  const S_ = AT_SIDES[side], list = AT[side];
  const n = list.reduce((s, im) => s + im.cards.length, 0);
  const doubt = list.reduce((s, im) => s + im.cards.filter((c) => c.conf !== "sûr").length, 0);
  const check = AT.mode === "collection" ? "" : side === "deck"
    ? `<label class="check"><input type="checkbox" id="at-use-deck" ${AT.useDeck ? "checked" : ""}> Ajouter mon deck actuel « ${esc(st.deck_name)} »</label>`
    : `<label class="check"><input type="checkbox" id="at-use-coll" ${AT.useColl ? "checked" : ""}> Ajouter ma collection enregistrée (${st.collection_count} cartes)</label>`;
  const nDiff = new Set(list.flatMap((im) => im.cards.map((c) => c.id))).size;
  return `<div class="at-col ${AT.target === side ? "active" : ""}" data-at-side="${side}">
    <div class="at-head"><span class="at-ico">${S_.icon}</span><div><b>${S_.title}</b><span>${S_.sub}</span></div>
      <span class="count-badge" id="at-count-${side}">${n} carte${n > 1 ? "s" : ""}${nDiff && nDiff !== n ? ` · ${nDiff} différentes` : ""}</span></div>
    <div class="drop at-drop" data-at-drop="${side}">
      <p>Glisse des images ici, ou clique cette colonne puis <kbd>Ctrl</kbd>+<kbd>V</kbd></p>
      <div class="row" style="justify-content:center">
        <button class="btn sm" data-at-src="files">${ICONS.file} Fichiers…</button>
        <button class="btn sm" data-at-src="clipboard">${ICONS.paste} Coller</button>
        <button class="btn sm" data-at-src="screen">${ICONS.screen} Zone de l'écran</button>
        <button class="btn sm" data-at-write>✍ Écrire une liste</button>
      </div>
      <div id="at-${side}-busy" class="hidden" style="text-align:center;color:var(--gold);font-size:12px">Analyse en cours…</div>
    </div>
    ${pickerHTML("at-" + side, side === "deck" ? "Ajouter une carte de ton deck : tape son nom…" : "Ajouter une carte de ta collection : tape son nom…")}
    <div id="at-picked-${side}"></div>
    ${check}
    <div class="at-list">${list.map((im, i) => im.manual ? "" : `<div class="at-item">
        ${im.thumb ? `<img src="${im.thumb}">` : `<div class="at-txt">✍</div>`}<div class="t"><b>${esc(im.name)}</b>
        <span>${im.cards.length} cartes${im.cards.some((c) => c.conf !== "sûr") ? ` · <em>${im.cards.filter((c) => c.conf !== "sûr").length} à vérifier</em>` : " · ✓"}</span></div>
        ${im.text !== undefined ? `<button class="btn sm" data-at-edit="${side}:${i}">Modifier</button>` : ""}
        <button class="btn sm" data-at-check="${side}:${i}">Vérifier</button>
        <button class="icon-btn" data-at-del="${side}:${i}" title="Retirer cette image"><svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg></button>
      </div>`).join("") || (list.length ? "" : `<div class="at-empty">Aucune image ni carte pour l'instant</div>`)}</div>
    ${doubt ? `<div class="tip warn" style="margin:0">⚠ <span>${doubt} carte(s) incertaine(s) : clique « Vérifier » pour les corriger.</span></div>` : ""}
  </div>`;
}

async function atelierRender() {
  const st = await api().state();
  const collMode = AT.mode === "collection";
  if (collMode) {
    const total = AT.coll.reduce((s, im) => s + im.cards.length, 0);
    $("#imp-title").textContent = "📦 Importer ma collection";
    $("#imp-sub").textContent = "Fais des captures de ton inventaire DMO (autant que nécessaire en faisant défiler) : toutes les cartes et leurs quantités sont reconnues d'un coup.";
    $("#imp-body").innerHTML = `<div class="at-wrap">
      <div id="idx-state"></div>
      <div class="at-grid single">${atSide("coll", st)}</div>
      <div class="at-foot">
        <span style="color:var(--muted);font-size:12.5px">Quantité = chiffre en bas à droite de chaque carte. Une carte déjà dans ta collection garde la plus grande quantité.</span>
        <button class="btn primary lg" id="at-coll-add" ${total ? "" : "disabled"}>📦 Ajouter ${total} carte(s) à ma collection</button>
      </div></div>`;
  } else {
    $("#imp-title").textContent = "✨ Atelier deck parfait";
    $("#imp-sub").textContent = "Ajoute des captures de ton deck et de ta collection : l'appli les fusionne pour construire le meilleur deck possible, et t'explique pourquoi.";
    $("#imp-body").innerHTML = `<div class="at-wrap">
      <div id="idx-state"></div>
      <div class="at-grid">${atSide("deck", st)}${atSide("coll", st)}</div>
      <div class="at-foot">
        <label class="check"><input type="checkbox" id="at-assume3" ${AT.assume3 ? "checked" : ""}> Supposer 3 exemplaires des cartes de ma collection</label>
        <button class="btn primary lg" id="at-go">✨ Créer le deck parfait</button>
      </div></div>`;
  }
  renderArtState();
  const body = $("#imp-body");
  $$("[data-at-side]", body).forEach((col) => (col.onclick = () => {
    AT.target = col.dataset.atSide; $$("[data-at-side]", body).forEach((c) => c.classList.toggle("active", c === col));
  }));
  $$("[data-at-src]", body).forEach((b) => (b.onclick = (e) => {
    e.stopPropagation(); atImport(b.closest("[data-at-side]").dataset.atSide, b.dataset.atSrc);
  }));
  $$("[data-at-drop]", body).forEach((d) => {
    d.ondragover = (e) => { e.preventDefault(); d.classList.add("over"); };
    d.ondragleave = () => d.classList.remove("over");
    d.ondrop = (e) => {
      e.preventDefault(); d.classList.remove("over");
      atImportBlobs(d.dataset.atDrop, [...e.dataTransfer.files].filter((f) => f.type.startsWith("image/")));
    };
  });
  $$("[data-at-write]", body).forEach((b) => (b.onclick = (e) => {
    e.stopPropagation(); atWrite(b.closest("[data-at-side]").dataset.atSide, null);
  }));
  $$("[data-at-edit]", body).forEach((b) => (b.onclick = (e) => {
    e.stopPropagation(); const [side, i] = b.dataset.atEdit.split(":"); atWrite(side, AT[side][+i]);
  }));
  $$("[data-at-del]", body).forEach((b) => (b.onclick = (e) => {
    e.stopPropagation(); const [side, i] = b.dataset.atDel.split(":"); AT[side].splice(+i, 1); atelierRender();
  }));
  $$("[data-at-check]", body).forEach((b) => (b.onclick = (e) => {
    e.stopPropagation(); const [side, i] = b.dataset.atCheck.split(":"); atCheck(AT[side][+i]);
  }));
  for (const side of collMode ? ["coll"] : ["deck", "coll"]) {
    cardPicker("at-" + side, { getQty: (id) => atQty(side, id), setQty: (c, n) => atSetQty(side, c, n) });
    $(`[data-picker="at-${side}"]`).onfocus = () => {
      AT.target = side; $$("[data-at-side]", body).forEach((c) => c.classList.toggle("active", c.dataset.atSide === side));
    };
    atRenderPicked(side);
  }
  if (collMode) {
    $("#at-coll-add").onclick = atAddToCollection;
    return;
  }
  $("#at-use-deck").onchange = (e) => (AT.useDeck = e.target.checked);
  $("#at-use-coll").onchange = (e) => (AT.useColl = e.target.checked);
  $("#at-assume3").onchange = (e) => (AT.assume3 = e.target.checked);
  $("#at-go").onclick = atRun;
}

async function atAddToCollection() {
  // une même carte peut apparaître sur deux captures qui se chevauchent : chaque case de l'inventaire
  // indique déjà la quantité totale, donc on garde le maximum vu (pas la somme des captures)
  const counts = {};
  for (const im of AT.coll) {
    const local = {};
    for (const c of im.cards) local[c.id] = (local[c.id] || 0) + 1;
    for (const [id, n] of Object.entries(local)) counts[id] = Math.max(counts[id] || 0, n);
  }
  const doubt = AT.coll.reduce((s, im) => s + im.cards.filter((c) => c.conf !== "sûr").length, 0);
  if (doubt && !confirm(`${doubt} carte(s) restent incertaines. Les ajouter quand même ?`)) return;
  const r = await api().collection_merge(counts);
  AT.coll = [];
  closeImport();
  toast(`Collection : ${r.added} nouvelle(s) carte(s), ${r.updated} quantité(s) mise(s) à jour — ${r.total} au total`);
  loadCollection();
}

/* cartes choisies une par une avec la recherche (une entrée « manuelle » par colonne) */
function atManual(side, create = true) {
  let e = AT[side].find((x) => x.manual);
  if (!e && create) { e = { manual: true, name: "Cartes choisies", thumb: null, cards: [] }; AT[side].unshift(e); }
  return e;
}
function atQty(side, id) {
  const e = atManual(side, false);
  return e ? e.cards.filter((c) => c.id === id).length : 0;
}
function atSetQty(side, card, n) {
  const e = atManual(side);
  const at = e.cards.findIndex((c) => c.id === card.id);  // garde la carte à sa place dans la liste
  const copies = Array.from({ length: n }, () => ({ ...card, conf: "sûr", alts: [], uid: AT.uid++ }));
  e.cards = e.cards.filter((c) => c.id !== card.id);
  e.cards.splice(at < 0 ? e.cards.length : at, 0, ...copies);
  if (!e.cards.length) AT[side] = AT[side].filter((x) => x !== e);
  atRenderPicked(side);
}
function atRenderPicked(side) {
  const box = $(`#at-picked-${side}`);
  if (!box) return;
  const e = atManual(side, false);
  const groups = new Map();
  for (const c of e ? e.cards : []) groups.set(c.id, { card: c, n: (groups.get(c.id)?.n || 0) + 1 });
  box.innerHTML = groups.size ? `<div class="picked">${[...groups.values()].map(({ card, n }) => `
    <div class="picked-row">${img(card)}<div class="t">${esc(card.name_fr)}<span>${esc(KIND_LABEL[card.kind])}</span></div>
      <div class="stepper"><button data-pk="${card.id}" data-d="-1">−</button><span>${n}</span><button data-pk="${card.id}" data-d="1">+</button></div>
      <button class="icon-btn" data-pk="${card.id}" data-d="-9" title="Retirer"><svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg></button>
    </div>`).join("")}</div>` : "";
  $$("[data-pk]", box).forEach((b) => (b.onclick = (ev) => {
    ev.stopPropagation();
    const g = groups.get(+b.dataset.pk);
    atSetQty(side, g.card, Math.max(0, Math.min(3, g.n + +b.dataset.d)));
  }));
  const total = AT[side].reduce((s, im) => s + im.cards.length, 0);
  const badge = $(`#at-count-${side}`);
  if (badge) badge.textContent = `${total} carte${total > 1 ? "s" : ""}`;
  const empty = $(`[data-at-side="${side}"] .at-empty`);
  if (empty) empty.classList.toggle("hidden", total > 0);
  const addBtn = $("#at-coll-add");
  if (addBtn && side === "coll") { addBtn.textContent = `📦 Ajouter ${total} carte(s) à ma collection`; addBtn.disabled = !total; }
}

/* liste écrite à la main : une carte par ligne, quantité optionnelle, français ou anglais */
function atWrite(side, entry) {
  const label = side === "deck" ? "de ton deck" : "de ta collection";
  modal(`<h2>✍ Écrire la liste ${label}</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:2px 0 8px">Une carte par ligne, en <b>français ou en anglais</b>, avec la quantité si tu veux.
    Les fautes de frappe légères sont acceptées. Tu peux aussi coller un fichier .ydk.</p>
    <textarea id="at-text" placeholder="3 Dragon Blanc aux Yeux Bleus&#10;2x Sage with Eyes of Blue&#10;Floraison de Cendres x3&#10;Appelé par la Tombe&#10;Pot de Cupidité">${esc(entry ? entry.text : "")}</textarea>
    <div id="at-text-msg"></div>
    <div class="row" style="justify-content:space-between;margin-top:10px">
      <span id="at-text-count" style="color:var(--muted);font-size:12px"></span>
      <button class="btn primary" id="at-text-go">${entry ? "Mettre à jour" : "Ajouter à la colonne"}</button></div>`);
  const ta = $("#at-text");
  const count = () => ($("#at-text-count").textContent = `${ta.value.split(/\n|;/).filter((l) => l.trim()).length} ligne(s)`);
  ta.oninput = count; count(); ta.focus();
  let target = entry, retry = false;  // retry : on complète la liste avec les lignes corrigées
  $("#at-text-go").onclick = async () => {
    const text = ta.value;
    if (!text.trim()) return toast("Écris au moins une carte");
    const res = await api().import_text(text);
    const cards = res.cards.map((c) => ({ ...c, uid: AT.uid++ }));
    // on mémorise les lignes reconnues (pour « Modifier »), les autres restent à corriger
    const clean = (l) => l.replace(/^[\s\-•*,]+|[\s\-•*,]+$/g, "");
    const kept = text.split(/\n/).filter((l) => l.trim() && !res.unknown.includes(clean(l))).join("\n");
    if (target && retry) { target.cards.push(...cards); target.text = [target.text, kept].filter(Boolean).join("\n"); }
    else if (target) { target.cards = cards; target.text = kept; }
    else if (cards.length) { target = { thumb: null, text: kept, cards }; AT[side].push(target); }
    if (target) target.name = `Liste écrite (${target.cards.length} cartes)`;
    atelierRender();
    if (res.unknown.length) {
      retry = true;
      ta.value = res.unknown.join("\n"); count();
      $("#at-text-msg").innerHTML = `<div class="tip warn" style="margin-top:8px">⚠ <span>${cards.length} carte(s) ajoutée(s). ${res.unknown.length} ligne(s) non reconnue(s), laissée(s) ci-dessus : corrige l'orthographe puis réessaie, ou crée la carte avec « ＋ Ajouter une carte » si elle n'existe pas dans la base.</span></div>`;
      $("#at-text-go").textContent = "Réessayer ces lignes";
    } else {
      closeModal(); toast(`${cards.length} carte(s) ajoutée(s) ✓`);
    }
  };
}

/* liste des cartes d'une image, cliquables pour les corriger */
function atCheck(entry) {
  const groups = new Map();
  for (const c of entry.cards) {
    if (!groups.has(c.id)) groups.set(c.id, { card: c, n: 0, conf: "sûr" });
    const g = groups.get(c.id); g.n++;
    if (CONF_RANK[c.conf] > CONF_RANK[g.conf]) g.conf = c.conf;
  }
  const list = [...groups.values()].sort((a, b) => CONF_RANK[b.conf] - CONF_RANK[a.conf]);
  modal(`<h2>${esc(entry.name)}</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:2px 0 8px">Clique sur une carte pour la corriger. En jaune/rouge : reconnaissance incertaine.</p>
    ${entry.thumb ? `<img src="${entry.thumb}" style="max-width:100%;border-radius:8px;margin-bottom:8px">` : ""}
    <div class="imp-list" style="max-height:none;padding:0">${list.map((g) => `<div class="imp-row ${g.conf === "sûr" ? "" : g.conf}" data-at-fix="${g.card.id}">
      ${img(g.card)}<div class="t"><b>${esc(g.card.name_fr)}</b><span>${esc(KIND_LABEL[g.card.kind])}${g.conf !== "sûr" ? " · à vérifier" : ""}</span></div><span class="n">${g.n}×</span></div>`).join("")}</div>`);
  $$("[data-at-fix]").forEach((el) => (el.onclick = () =>
    impFix(+el.dataset.atFix, null, entry, () => { atelierRender(); atCheck(entry); })));
}

async function atRun() {
  const ids = (side) => AT[side].flatMap((im) => im.cards.map((c) => c.id));
  const btn = $("#at-go"); btn.disabled = true; btn.textContent = "Analyse et optimisation…";
  const r = await api().perfect_deck(ids("deck"), ids("coll"), AT.useDeck, AT.useColl, AT.assume3);
  btn.disabled = false; btn.textContent = "✨ Créer le deck parfait";
  if (r.error) return toast(r.error);
  AT.result = r;
  atResult();
}

function atResult() {
  const r = AT.result, c = r.counts, cons = r.consistency;
  const md = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
  const row = (e, sign) => `<div class="chg ${sign === "+" ? "plus" : "minus"}" data-open-at="${e.id}">${img(e)}
    <div class="t"><b>${sign} ${e.n}× ${esc(e.name_fr)}</b><span>${esc(e.why)}</span></div></div>`;
  $("#imp-title").textContent = `✨ Deck parfait${r.archetype ? " — " + r.archetype : ""}`;
  $("#imp-sub").textContent = `Construit à partir de ${r.deck_in} carte(s) de ton deck et ${r.coll_in} carte(s) différente(s) de ta collection.`;
  $("#imp-body").innerHTML = `<div class="at-wrap at-result">
    <div class="at-kpis">
      <div class="kpi"><b>${c.main}</b><span>cartes (Main Deck)</span></div>
      <div class="kpi"><b>${c.extra}</b><span>Extra Deck</span></div>
      <div class="kpi"><b>${cons.before !== null && r.archetype ? cons.before + " % → " : ""}${cons.after} %</b><span>chances d'ouvrir avec une carte ${esc(r.archetype || "clé")}</span></div>
      <div class="kpi"><b>${r.hand_traps}</b><span>interruptions depuis la main</span></div>
    </div>
    <h3>Pourquoi ce deck</h3>
    <ul class="why">${r.why.map((w) => `<li>${md(w)}</li>`).join("")}</ul>
    <div class="chg-grid">
      <div><h3>Ajoutées depuis ta collection (${r.added.reduce((s, e) => s + e.n, 0)})</h3>${r.added.map((e) => row(e, "+")).join("") || `<div class="at-empty">Aucun ajout : ton deck utilise déjà tes meilleures cartes.</div>`}</div>
      <div><h3>Retirées de ton deck (${r.removed.reduce((s, e) => s + e.n, 0)})</h3>${r.removed.map((e) => row(e, "−")).join("") || `<div class="at-empty">Rien à retirer.</div>`}</div>
    </div>
    ${r.key_cards.length ? `<h3>Cartes clés et leur rôle</h3>${r.key_cards.map((k) => `<div class="chg key" data-open-at="${k.id}">${img(k)}<div class="t"><b>${esc(k.name_fr)}</b><span>${esc(k.role)}</span></div></div>`).join("")}` : ""}
    ${r.tips.length ? `<h3>Conseils</h3><ul class="why tips">${r.tips.map((t) => `<li>${md(t)}</li>`).join("")}</ul>` : ""}
    <h3>La liste complète</h3>
    <div class="card-grid">${groupedGrid([...r.main, ...r.extra], { count: (x) => x.n })}</div>
    ${r.missing.length ? `<h3>À obtenir pour l'améliorer encore</h3><div class="card-grid">${r.missing.map((m) => tile(m, { qty: 0 })).join("")}</div>` : ""}
    <div class="at-foot sticky">
      <button class="btn ghost" id="at-back">← Modifier les images</button>
      <div class="row"><input class="input" id="at-name" value="${esc(r.archetype ? r.archetype + " (parfait)" : "Deck parfait")}" style="min-width:200px">
        <button class="btn primary" id="at-save">Enregistrer ce deck</button></div>
    </div></div>`;
  $$("#imp-body [data-open-at], #imp-body .tile[data-open]").forEach((el) => (el.onclick = async () => {
    const card = await api().card(+(el.dataset.openAt || el.dataset.open));
    modal(`<div id="modal-card"></div>`); $("#modal-card").innerHTML = cardHTML(card); bindCard($("#modal-card"), card);
  }));
  $("#at-back").onclick = atelierRender;
  $("#at-save").onclick = async () => {
    const name = await api().apply_build($("#at-name").value, r.main, r.extra);
    closeImport(); toast(`Deck « ${name} » enregistré`); loadDeck();
  };
}

/* ------------------------------------------------------------------ apprendre / ajouter une carte */
async function startLearn() {
  if (S.aim !== "illustration") {
    // la souris est sur ce bouton : on laisse 3 s pour aller pointer la carte dans le jeu
    for (let s = 3; s > 0; s--) {
      toast(`Pointe la carte dans le jeu avec la souris… ${s}`);
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  toast("Capture de la carte visée…");
  showLearn(await api().learn_capture());
}
function showLearn(res) {
  if (S.tab !== "card") goTab("card");
  if (!res || res.error) { toast(res ? res.error : "Rien à apprendre"); return; }
  S.learnHints = res.hints || {};
  modal(`<h2>Apprendre cette carte</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:2px 0">Voici ce que l'appli a capturé. Dis-lui de quelle carte il s'agit : la prochaine fois, elle la reconnaîtra.</p>
    <img class="learn-shot" src="${res.image}">
    ${res.hint_text ? `<div class="tip" style="margin-top:6px">🔎 <span>Lu sur la carte : <b>${esc(res.hint_text)}</b> — les propositions ci-dessous en tiennent compte.</span></div>` : ""}
    ${res.named ? `<h3>Nom lu près de la carte</h3><div class="card-grid">${tile(res.named, { qty: 0 }).replace('data-open="', 'data-learn="')}</div>` : ""}
    ${res.suggestions.length ? `<h3>${res.hint_text ? "Cartes qui correspondent" : "C'est l'une de celles-ci ?"}</h3><div class="card-grid">${res.suggestions.map((c) => tile(c, { qty: 0 }).replace('data-open="', 'data-learn="')).join("")}</div>` : ""}
    <h3>Sinon, cherche-la</h3>
    <div class="search-wrap"><svg class="search-ico" viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/></svg>
      <input id="learn-q" placeholder="Nom en français ou en anglais…" autocomplete="off" style="width:100%;padding:10px 12px 10px 36px;border-radius:10px;border:1px solid var(--line);background:var(--bg);color:var(--fg);font:inherit;outline:none">
      <div id="learn-res" class="dropdown hidden" style="position:static;margin-top:6px;max-height:220px"></div></div>
    <div class="row" style="justify-content:space-between;margin-top:14px">
      <span style="color:var(--muted);font-size:12px">Elle n'existe pas dans la base ?</span>
      <button class="btn sm primary" id="learn-new">＋ Créer cette carte</button></div>`);
  const confirm = async (id) => {
    await api().learn_confirm(id);
    closeModal(); toast("Illustration apprise ✓ — elle sera reconnue la prochaine fois");
    openCard(id);
  };
  $$("#modal-body [data-learn]").forEach((el) => (el.onclick = () => confirm(+el.dataset.learn)));
  let t;
  $("#learn-q").oninput = (e) => {
    clearTimeout(t);
    t = setTimeout(async () => {
      const r = e.target.value.trim().length > 1 ? await api().search(e.target.value) : [];
      const dd = $("#learn-res");
      dd.classList.toggle("hidden", !r.length);
      dd.innerHTML = r.map((c) => `<div class="dd-item" data-learn="${c.id}">${img(c)}<div class="t"><b>${esc(c.name_fr)}</b><span>${esc(c.name_en)} · ${esc(c.type_line)}</span></div></div>`).join("");
      $$("#learn-res [data-learn]").forEach((el) => (el.onclick = () => confirm(+el.dataset.learn)));
    }, 140);
  };
  $("#learn-new").onclick = () => newCardForm(res.image, $("#learn-q").value);
  $("#learn-q").focus();
}

const TYPES = [
  ["Normal Monster", "Monstre Normal"], ["Effect Monster", "Monstre à Effet"], ["Ritual Effect Monster", "Monstre Rituel"],
  ["Fusion Monster", "Monstre Fusion"], ["Synchro Monster", "Monstre Synchro"], ["XYZ Monster", "Monstre Xyz"],
  ["Link Monster", "Monstre Lien"], ["Spell Card", "Carte Magie"], ["Trap Card", "Carte Piège"],
];
const ATTRS = [["", "—"], ["DARK", "TÉNÈBRES"], ["LIGHT", "LUMIÈRE"], ["EARTH", "TERRE"], ["WATER", "EAU"], ["FIRE", "FEU"], ["WIND", "VENT"], ["DIVINE", "DIVIN"]];
function newCardForm(image, name = "") {
  const opt = (list) => list.map(([v, l]) => `<option value="${v}">${l}</option>`).join("");
  modal(`<h2>Ajouter une carte manquante</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:2px 0">Pour les cartes absentes de la base (cartes de l'anime, cartes propres au jeu…).
    ${image ? "L'illustration capturée lui sera associée : elle sera reconnue en jeu." : ""}</p>
    ${image ? `<img class="learn-shot" src="${image}" style="max-width:150px">` : ""}
    <div class="form-grid">
      <label class="full">Nom (tel qu'affiché dans le jeu) *<input id="f-name" value="${esc(name)}" autocomplete="off"></label>
      <div class="full" id="f-exists"></div>
      <label>Type<select id="f-type">${opt(TYPES)}</select></label>
      <label>Attribut<select id="f-attr">${opt(ATTRS)}</select></label>
      <label>Type de monstre / icône<input id="f-race" placeholder="Dragon, Magicien, Continue…"></label>
      <label>Niveau / Rang<input id="f-level" inputmode="numeric"></label>
      <label>ATK<input id="f-atk" inputmode="numeric"></label>
      <label>DEF<input id="f-def" inputmode="numeric"></label>
      <label class="full">Effet<textarea id="f-desc" placeholder="Colle l'effet tel qu'écrit dans le jeu (anglais ou français)"></textarea></label>
      <label class="full" style="flex-direction:row;align-items:center;gap:8px;color:var(--fg-2)"><input type="checkbox" id="f-en" checked style="width:auto"> L'effet est en anglais (il sera traduit automatiquement)</label>
    </div>
    <div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn primary" id="f-save">Ajouter la carte</button></div>`);
  $("#f-name").focus();
  $("#f-type").value = "Effect Monster";
  // pré-remplissage avec ce qui a été lu sur la carte capturée (type, ATK/DEF)
  const h = image ? S.learnHints || {} : {};
  const TYPE_OF = { magie: "Spell Card", "piège": "Trap Card", monstre: "Effect Monster", extra: "Fusion Monster" };
  if (h.kind) $("#f-type").value = TYPE_OF[h.kind];
  if (h.atk !== undefined) { $("#f-atk").value = h.atk; $("#f-def").value = h.def; }
  // la carte existe peut-être déjà : mieux vaut lui associer l'illustration que créer un doublon
  let t;
  const exists = async () => {
    const q = $("#f-name").value.trim();
    const box = $("#f-exists");
    if (q.length < 3) { box.innerHTML = ""; return; }
    const r = (await api().search(q)).slice(0, 4);
    box.innerHTML = r.length ? `<div class="tip" style="margin:0;flex-direction:column;gap:6px">
      <span>Elle existe peut-être déjà ${image ? "— clique pour lui associer l'illustration au lieu de créer un doublon" : ""} :</span>
      <div class="chips">${r.map((c) => `<span class="chip" data-exist="${c.id}">${esc(c.name_fr)}${c.name_en !== c.name_fr ? ` (${esc(c.name_en)})` : ""}</span>`).join("")}</div></div>` : "";
    $$("[data-exist]", box).forEach((el) => (el.onclick = async () => {
      const id = +el.dataset.exist;
      if (image) { await api().learn_confirm(id); toast("Illustration associée ✓"); }
      closeModal(); openCard(id);
    }));
  };
  $("#f-name").oninput = () => { clearTimeout(t); t = setTimeout(exists, 160); };
  if (name) exists();
  $("#f-save").onclick = async () => {
    const name = $("#f-name").value.trim();
    if (!name) return toast("Indique au moins le nom de la carte");
    const en = $("#f-en").checked, desc = $("#f-desc").value.trim();
    $("#f-save").disabled = true; $("#f-save").textContent = en && desc ? "Traduction…" : "Ajout…";
    const c = await api().create_card({
      name_fr: name, name_en: name, type: $("#f-type").value, attribute: $("#f-attr").value, race: $("#f-race").value.trim(),
      level: $("#f-level").value, atk: $("#f-atk").value, def: $("#f-def").value,
      desc_en: en ? desc : "", desc_fr: en ? "" : desc,
    });
    closeModal(); toast(`« ${c.name_fr} » ajoutée ✓`);
    if (S.tab !== "card") goTab("card");
    showCard(c);
  };
}

/* ------------------------------------------------------------------ illustrations apprises (vérifier / supprimer) */
async function openLearned() {
  const list = await api().learned_list();
  modal(`<h2>🎓 Illustrations apprises</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:2px 0 10px">Si l'appli confond une carte avec une autre, c'est souvent qu'une illustration a été associée à la mauvaise carte : supprime-la ici (✕), puis réapprends-la avec Maj+F8.</p>
    ${list.length ? `<div class="picked" style="max-height:52vh">${list.map((c) => `<div class="picked-row">${img(c)}
      <div class="t">${esc(c.name_fr)}<span>${c.views} vue(s) · ${c.auto === c.views ? "apprise automatiquement" : c.auto ? "auto + à la main" : "apprise à la main"}</span></div>
      <button class="icon-btn" data-forget="${c.id}" title="Oublier cette illustration"><svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg></button></div>`).join("")}</div>
      <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn sm danger" id="forget-auto">Effacer tout ce qui a été appris automatiquement</button></div>`
      : `<div class="empty">Aucune illustration apprise pour l'instant.</div>`}`);
  $$("[data-forget]").forEach((b) => (b.onclick = async () => { await api().forget_art(+b.dataset.forget); openLearned(); }));
  const fa = $("#forget-auto");
  if (fa) fa.onclick = async () => { const left = await api().forget_auto_learned(); toast(`Apprentissages automatiques effacés (${left} vue(s) apprises à la main gardées)`); openLearned(); };
}

/* ------------------------------------------------------------------ réglages de l'overlay en jeu */
async function openSettings() {
  const s = await api().hud_settings();
  const toggle = (key, title, sub) => `<div class="set-row"><div class="lab"><b>${title}</b>${sub ? `<span>${sub}</span>` : ""}</div>
    <label class="tgl"><input type="checkbox" data-hud="${key}" ${s[key] ? "checked" : ""}><i></i></label></div>`;
  const range = (key, title, min, max, step, fmt) => `<div class="set-row"><div class="lab"><b>${title}</b></div>
    <div><input type="range" data-hud="${key}" min="${min}" max="${max}" step="${step}" value="${s[key]}"> <output data-out="${key}">${fmt(s[key])}</output></div></div>`;
  const FMT = { opacity: (v) => Math.round(v * 100) + " %", font: (v) => v + " px", width: (v) => v + " px", hide_after: (v) => v + " s" };
  modal(`<h2>Overlay en jeu</h2>
    <p style="color:var(--fg-2);font-size:13px;margin:2px 0 6px">La traduction s'affiche directement sur le jeu, à côté du nom de la carte. Tes clics passent à travers. Touche ${kbd("hud")} pour l'activer ou la couper.</p>
    ${toggle("enabled", "Afficher l'overlay sur le jeu", "")}
    <div class="set-group ${s.enabled ? "" : "off"}" id="set-group">
      <div class="set-row"><div class="lab"><b>Position</b><span>${s.anchor === "zone" ? "Suit la zone du nom de carte (" + kbd("zone") + ")" : "Position libre enregistrée"}</span></div>
        <div class="row"><div class="seg"><button data-anchor="zone" class="${s.anchor === "zone" ? "on" : ""}">À côté du nom</button><button data-anchor="libre" class="${s.anchor === "libre" ? "on" : ""}">Position libre</button></div>
        <button class="btn sm" id="hud-move">Déplacer…</button></div></div>
      ${range("opacity", "Opacité du fond", 0.4, 1, 0.05, FMT.opacity)}
      ${range("font", "Taille du texte", 11, 20, 1, FMT.font)}
      ${range("width", "Largeur", 300, 620, 10, FMT.width)}
      ${range("hide_after", "Masquer quand la carte disparaît après", 1, 10, 1, FMT.hide_after)}
      ${toggle("image", "Afficher l'image de la carte", "")}
      ${toggle("record_visible", "Visible sur mes enregistrements", "Pour montrer la traduction dans tes vidéos TikTok / OBS. Désactivé = toi seul la vois.")}
    </div>
    <div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" id="hud-demo">Afficher un exemple</button></div>`);
  const body = $("#modal-body");
  $$("[data-hud]", body).forEach((el) => {
    const key = el.dataset.hud;
    if (el.type === "checkbox") {
      el.onchange = async () => {
        await api().set_hud(key, el.checked);
        if (key === "enabled") $("#set-group").classList.toggle("off", !el.checked);
      };
    } else {
      let t;
      el.oninput = () => {
        $(`[data-out="${key}"]`, body).textContent = FMT[key](+el.value);
        clearTimeout(t); t = setTimeout(() => api().set_hud(key, +el.value), 120);
      };
    }
  });
  $$("[data-anchor]", body).forEach((b) => (b.onclick = async () => {
    if (b.dataset.anchor === "libre" && !s.pos) { closeModal(); return startMove(); }
    await api().set_hud("anchor", b.dataset.anchor);
    openSettings();
  }));
  $("#hud-move").onclick = () => { closeModal(); startMove(); };
  $("#hud-demo").onclick = () => api().hud_demo();
}
function startMove() {
  api().hud_edit(true);
  toast("Glisse l'overlay où tu veux, puis clique « Valider la position »");
}

/* ------------------------------------------------------------------ tutoriel */
const TUTO = [
  { art: `<svg viewBox="0 0 24 24"><rect x="6" y="3" width="12" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h3"/></svg>`,
    title: "Bienvenue dans DMO Assistant", text: "Cet overlay lit le nom des cartes affichées dans Yu-Gi-Oh! DMO et te donne leur effet <b>en français</b>. Il gère aussi ta collection et génère des decks à partir de tes cartes." },
  { art: `<svg viewBox="0 0 24 24"><path d="M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3"/></svg>`,
    title: "Place la fenêtre", text: "Déplace l'overlay en le tenant par sa barre du haut et pose-le à côté du jeu. Il reste au premier plan, et il est <b>invisible sur tes enregistrements</b> (TikTok, OBS…).", hk: ["toggle"] },
  { art: `<div class="keys"><kbd data-k="scan"></kbd></div>`,
    title: "Pointe une carte", text: "Dans le jeu, mets ta souris sur une carte et appuie sur la touche ci-dessus. La carte est reconnue <b>grâce à son illustration</b> (pas besoin que le nom soit écrit) et sa traduction s'affiche juste à côté, <b>sur le jeu</b>." },
  { art: `<div class="keys"><kbd data-k="auto"></kbd><kbd data-k="hud"></kbd></div>`,
    title: "Mode automatique", text: "La 1re touche active le <b>mode auto</b> : la traduction suit ta souris de carte en carte, sans rien appuyer. La 2e affiche ou coupe l'overlay sur le jeu. Si le jeu affiche une grande illustration de la carte sélectionnée, choisis « Viser : Illustration » et encadre-la avec " + "<kbd data-k=\"zone\"></kbd>." },
  { art: `<div class="keys"><kbd data-k="collection"></kbd></div>`,
    title: "Enregistre ta collection", text: "Ouvre ton inventaire dans le jeu, appuie sur la touche ci-dessus, puis fais défiler tes cartes : elles sont ajoutées automatiquement. Ajuste les quantités dans l'onglet <b>Collection</b>." },
  { art: `<svg viewBox="0 0 24 24"><path d="M12 3l2.4 5.3L20 9l-4.2 3.9L17 19l-5-3-5 3 1.2-6.1L4 9l5.6-.7z"/></svg>`,
    title: "Crée tes decks", text: "L'onglet <b>Générer</b> construit le meilleur deck possible avec tes cartes. Dans <b>Deck</b>, « Importer depuis une image » recrée un deck à partir d'une capture trouvée sur Internet. Les raccourcis restent affichés en bas de la fenêtre." },
];
let tutoI = 0;
function showTuto(i = 0) {
  tutoI = i;
  const s = TUTO[i];
  $("#tuto").classList.remove("hidden");
  $("#tuto-art").innerHTML = s.art;
  $$("#tuto-art kbd[data-k], #tuto-text kbd[data-k]").forEach((k) => (k.textContent = (S.hk[k.dataset.k] || "").toUpperCase()));
  $("#tuto-step").textContent = `Étape ${i + 1} sur ${TUTO.length}`;
  $("#tuto-title").textContent = s.title;
  $("#tuto-text").innerHTML = s.text + (s.hk ? ` Touche ${s.hk.map(kbd).join(" ")} pour masquer / afficher.` : "");
  $$("#tuto-text kbd[data-k]").forEach((k) => (k.textContent = (S.hk[k.dataset.k] || "").toUpperCase()));
  $("#tuto-extra").innerHTML = s.extra || "";
  $("#tuto-dots").innerHTML = TUTO.map((_, j) => `<i class="${j === i ? "on" : ""}"></i>`).join("");
  $("#tuto-prev").style.visibility = i ? "visible" : "hidden";
  $("#tuto-next").textContent = i === TUTO.length - 1 ? "C'est parti !" : "Suivant";
  const z = $("#tuto-zone");
  if (z) z.onclick = async () => { z.disabled = true; z.textContent = "Sélection en cours…"; await api().select_zone(); z.disabled = false; z.textContent = "Redéfinir la zone"; };
}
function endTuto() { $("#tuto").classList.add("hidden"); api().complete_tutorial(); }

/* ------------------------------------------------------------------ modes / zone */
function setModes({ auto, collecting }) {
  $("#btn-auto").classList.toggle("on", auto);
  const bc = $("#btn-collect");
  bc.classList.toggle("on", collecting);
  $(".lbl", bc).textContent = collecting ? "Arrêter le scan" : "Scanner ma collection";
  const pill = $("#mode-pill");
  pill.classList.toggle("hidden", !auto && !collecting);
  pill.textContent = collecting ? "Scan de collection…" : "Scan auto actif";
  if (!collecting) $("#collect-live").classList.toggle("hidden", true);
}
function setAim({ aim, zone, art_zone }) {
  S.aim = aim;
  $$("#aim button").forEach((b) => b.classList.toggle("on", b.dataset.aim === aim));
  let html;
  if (aim === "souris") {
    html = `<span class="ok">●</span> Pointe une carte dans le jeu avec la souris puis ${kbd("scan")} — ou ${kbd("auto")} pour suivre la souris en continu.`;
  } else if (aim === "illustration") {
    html = art_zone
      ? `<span class="ok">●</span> Zone d'illustration définie (${art_zone[2]}×${art_zone[3]} px). ${kbd("zone")} pour la refaire.`
      : `<span class="warn">●</span> Ouvre le détail d'une carte dans le jeu, puis ${kbd("zone")} et encadre la <b>carte entière</b> (illustration + barre ATK/DEF) : l'appli lit aussi le type et l'ATK/DEF.`;
    const titleZone = zone && zone[3] <= 120 && zone[2] >= zone[3] * 2;
    html += !zone
      ? `<br><span class="warn">●</span> Si le jeu écrit le nom de la carte sur une ligne, <a href="#" data-namezone>encadre cette ligne</a> : l'appli apprendra seule chaque illustration inconnue.`
      : titleZone
        ? `<br><span class="ok">●</span> Zone du nom définie : les cartes inconnues dont le nom est lu sans ambiguïté sont <b>apprises automatiquement</b>. <a href="#" data-namezone>Refaire</a> · <a href="#" data-clearname>Supprimer</a>`
        : `<br><span class="warn">⚠</span> <b>Zone du nom trop grande</b> (${zone[2]}×${zone[3]} px) : elle doit encadrer <b>seulement la ligne du nom</b>, pas toute la carte. Elle est ignorée pour l'apprentissage. <a href="#" data-namezone>Refaire</a> · <a href="#" data-clearname>Supprimer</a>`;
  } else {
    html = zone
      ? `<span class="ok">●</span> Zone du nom définie (${zone[2]}×${zone[3]} px). ${kbd("zone")} pour la refaire.`
      : `<span class="warn">●</span> Pas de zone : lit tout l'écran sous la souris. ${kbd("zone")} et encadre le <b>nom</b> pour plus de fiabilité.`;
  }
  $("#zone-info").innerHTML = html;
}

/* ------------------------------------------------------------------ événements backend */
window.onBackend = ([type, data]) => {
  if (type === "status") setStatus(data);
  else if (type === "ready") onReady(data);
  else if (type === "error") setStatus("Erreur : " + data);
  else if (type === "card") { if (S.tab !== "card") goTab("card"); closeModal(); showCard(data.card, data.others); }
  else if (type === "image") imageReady(data);
  else if (type === "modes") setModes(data);
  else if (type === "aim") setAim(data);
  else if (type === "learn") showLearn(data);
  else if (type === "learned") toast(`🎓 Illustration apprise automatiquement : ${data.name}`);
  else if (type === "collected") collectedLive(data);
  else if (type === "art_progress") { IMP.art = { ...(IMP.art || {}), ...data, building: true, ready: false }; renderArtState(); }
  else if (type === "art_ready") { IMP.art = data; renderArtState(); IMP.waiters.splice(0).forEach((r) => r()); }
  else if (type === "art_error") renderArtState(data);
  else if (type === "update") onUpdate(data);
};

function onReady(st) {
  if (S.ready) return;
  S.ready = true;
  S.hk = st.hotkeys; S.showEn = st.show_english;
  fillKbds(); setAim(st); setModes(st); setStatus(st.status);
  $("#coll-count").textContent = st.collection_count;
  if (!S.current) emptyCard();
  (S.introP || Promise.resolve()).then(async () => {
    const news = st.tutorial_done ? await api().whats_new(false) : null;
    if (window.showHome) await showHome();
    if (!st.tutorial_done) showTuto(0);
    else showNews(news);
    const up = await api().pending_update();
    if (up) onUpdate({ state: "ready", version: up.version });
  });
}

/* ------------------------------------------------------------------ nouveautés et mises à jour */
function newsHTML(info, title) {
  return `<div class="news-head"><span class="news-badge">v${esc(info.version)}</span><h2>${esc(title)}</h2></div>` +
    (info.entries.length ? info.entries.map((e) => `<div class="news-entry"><h3>Version ${esc(e.version)}<small>${esc(e.date || "")}</small></h3>
      <ul>${(e.notes || []).map((n) => `<li>${esc(n)}</li>`).join("")}</ul></div>`).join("")
      : `<p class="muted">Aucune note de version pour l'instant.</p>`);
}
function showNews(info, force = false) {
  if (!info || (!force && !info.entries.length)) return;
  modal(newsHTML(info, force ? "Historique des mises à jour" : "Quoi de neuf ?") +
    `<div class="row" style="justify-content:flex-end;margin-top:14px"><button class="btn" onclick="closeModal()">C'est parti !</button></div>`);
}
function onUpdate(d) {
  let t = $("#update-toast");
  if (!t) { t = document.createElement("div"); t.id = "update-toast"; t.className = "update-toast"; document.body.appendChild(t); }
  if (d.state === "downloading") t.innerHTML = `<span class="grow">Téléchargement de la mise à jour <b>v${esc(d.version)}</b>…</span>`;
  else if (d.state === "ready") {
    t.innerHTML = `<span class="grow">Mise à jour <b>v${esc(d.version)}</b> installée.</span>
      ${d.entries && d.entries.length ? `<button class="btn ghost" id="up-notes">Voir</button>` : ""}
      <button class="btn" id="up-restart">Redémarrer</button>`;
    const n = $("#up-notes"); if (n) n.onclick = () => showNews({ version: d.version, entries: d.entries }, false);
    $("#up-restart").onclick = () => api().restart_app();
  } else if (d.state === "manual") {
    t.innerHTML = `<span class="grow">${esc(d.message)}</span>${d.url ? `<button class="btn" id="up-dl">Télécharger</button>` : ""}<button class="btn ghost" id="up-x">✕</button>`;
    if (d.url) $("#up-dl").onclick = () => api().open_url(d.url);
    $("#up-x").onclick = () => t.remove();
  }
}
async function renderIntroOpts() {
  const o = await api().intro_settings();
  $("#app-version").textContent = "v" + o.version;
  $("#opt-intro").checked = o.intro;
}

async function init() {
  const io = await api().intro_settings();
  api().set_layout("wide");  // l'animation et l'écran d'accueil partagent la même taille de fenêtre
  if (io.intro && window.playIntro) S.introP = window.playIntro({ version: io.version });
  renderIntroOpts();
  const st = await api().state();
  S.hk = st.hotkeys; fillKbds();
  setStatus(st.status);
  if (st.ready) onReady(st);
  else $("#card-view").innerHTML = `<div class="empty"><div class="big">Chargement de la base de cartes…</div>Le premier lancement télécharge ~45 Mo, ça peut prendre une minute.</div>`;
}

/* ------------------------------------------------------------------ câblage */
document.addEventListener("click", async (e) => {
  const cp = e.target.closest("[data-copy]");
  if (cp) {
    try { await navigator.clipboard.writeText(cp.dataset.copy); } catch (err) {
      const t = document.createElement("textarea"); t.value = cp.dataset.copy; document.body.appendChild(t); t.select(); document.execCommand("copy"); t.remove();
    }
    const old = cp.textContent; cp.textContent = "Copié ✓"; setTimeout(() => (cp.textContent = old), 1400);
    return;
  }
  const go = e.target.closest("[data-tab-go]");
  if (go) { closeModal(); return goTab(go.dataset.tabGo); }
  if (e.target.closest("[data-import]")) return openImport();
  if (e.target.closest("[data-namezone]")) { e.preventDefault(); return api().select_name_zone(); }
  if (e.target.closest("[data-clearname]")) { e.preventDefault(); await api().clear_name_zone(); return toast("Zone du nom supprimée"); }
  if (e.target.closest("[data-learned]")) { e.preventDefault(); return openLearned(); }
  const dk = e.target.closest("[data-dk]");
  if (dk) { e.stopPropagation(); await api().deck_add(+dk.dataset.dk, +dk.dataset.d); return loadDeck(); }
  const ck = e.target.closest("[data-ck]");
  if (ck) {
    e.stopPropagation();
    const c = S.collection.find((x) => x.id === +ck.dataset.ck);
    c.qty = await api().collection_set(c.id, c.qty + +ck.dataset.d);
    if (!c.qty) S.collection = S.collection.filter((x) => x !== c);
    $("#coll-count").textContent = S.collection.length;
    return renderCollection();
  }
  const op = e.target.closest(".panel:not(#tab-card) [data-open]");
  if (op) return openCard(+op.dataset.open);
  const ar = e.target.closest("[data-arch]");
  if (ar) { S.arch = ar.dataset.arch || null; $$(".arch").forEach((a) => a.classList.toggle("sel", a === ar)); }
  if (!e.target.closest(".search-wrap")) { searchRes = []; renderSearch(); }
});

$$(".tab").forEach((b) => (b.onclick = () => goTab(b.dataset.tab)));
$("#btn-min").onclick = () => api().minimize();
$("#btn-close").onclick = () => api().close();
$("#btn-scan").onclick = () => api().scan();
$("#btn-learn").onclick = startLearn;
$("#btn-newcard").onclick = () => newCardForm(null, "");
$$("#aim button").forEach((b) => (b.onclick = async () => {
  await api().set_aim(b.dataset.aim);
  if (b.dataset.aim === "souris") toast("Mode souris : pointe une carte dans le jeu et appuie sur " + (S.hk.scan || "").toUpperCase());
}));
$("#btn-auto").onclick = () => api().toggle_auto();
$("#btn-zone").onclick = () => api().select_zone();
$("#btn-collect").onclick = () => api().toggle_collection_scan();
$("#btn-import").onclick = importDialog;
$("#btn-coll-capture").onclick = openCollImport;
$("#btn-coll-clear").onclick = async () => {
  if (!S.collection.length) return;
  modal(`<h2>Effacer la collection ?</h2><p style="color:var(--fg-2)">Les ${S.collection.length} cartes enregistrées seront retirées. Tes decks ne sont pas touchés.</p>
    <div class="row" style="justify-content:flex-end"><button class="btn" id="cc-no">Annuler</button><button class="btn danger" id="cc-yes">Tout effacer</button></div>`);
  $("#cc-no").onclick = closeModal;
  $("#cc-yes").onclick = async () => { await api().collection_clear(); closeModal(); loadCollection(); };
};
$("#coll-filter").oninput = renderCollection;
$$("#coll-kind button").forEach((b) => (b.onclick = () => {
  S.collKind = b.dataset.k; $$("#coll-kind button").forEach((x) => x.classList.toggle("on", x === b)); renderCollection();
}));
$("#assume3").onchange = loadArchetypes;
$("#btn-build").onclick = runBuild;

$("#deck-select").onchange = async (e) => { await api().deck_switch(e.target.value); loadDeck(); };
function askName(title, value, cb) {
  modal(`<h2>${esc(title)}</h2><input class="input" id="name-in" value="${esc(value)}" style="width:100%;margin:10px 0">
    <div class="row" style="justify-content:flex-end"><button class="btn primary" id="name-ok">Valider</button></div>`);
  const inp = $("#name-in"); inp.focus(); inp.select();
  const ok = async () => { if (inp.value.trim()) { await cb(inp.value.trim()); closeModal(); loadDeck(); } };
  $("#name-ok").onclick = ok; inp.onkeydown = (e) => e.key === "Enter" && ok();
}
$("#deck-new").onclick = () => askName("Nouveau deck", "", (n) => api().deck_switch(n));
$("#deck-rename").onclick = () => askName("Renommer le deck", $("#deck-select").value, async (n) => {
  if (!(await api().deck_rename(n))) toast("Ce nom existe déjà");
});
$("#deck-delete").onclick = () => {
  modal(`<h2>Supprimer « ${esc($("#deck-select").value)} » ?</h2><div class="row" style="justify-content:flex-end;margin-top:12px"><button class="btn" id="dd-no">Annuler</button><button class="btn danger" id="dd-yes">Supprimer</button></div>`);
  $("#dd-no").onclick = closeModal;
  $("#dd-yes").onclick = async () => { await api().deck_delete(); closeModal(); loadDeck(); };
};
// recherche avec quantité dans les onglets Deck et Collection
$("#deck-picker").innerHTML = pickerHTML("deck", "Ajouter une carte au deck : tape son nom (français ou anglais)…");
cardPicker("deck", {
  getQty: (id) => (S.deckItems || []).find((x) => x.id === id)?.n || 0,
  setQty: async (c, n) => {
    const cur = (S.deckItems || []).find((x) => x.id === c.id)?.n || 0;
    if (n !== cur) await api().deck_add(c.id, n - cur);
    await loadDeck();
  },
});
$("#coll-picker").innerHTML = pickerHTML("coll", "Ajouter une carte à ma collection : tape son nom (français ou anglais)…");
cardPicker("coll", {
  getQty: (id) => S.collection.find((x) => x.id === id)?.qty || 0,
  setQty: async (c, n) => { await api().collection_set(c.id, n); await loadCollection(); },
});
$("#deck-import").onclick = openImport;
$("#deck-perfect").onclick = openAtelier;
$("#btn-settings").onclick = openSettings;
$("#imp-x").onclick = closeImport;
$("#deck-export").onclick =async () => toast("Exporté : " + (await api().deck_export()));

$("#search").oninput = (e) => {
  clearTimeout(searchTimer);
  const q = e.target.value;
  searchTimer = setTimeout(async () => { searchRes = q.trim().length > 1 ? await api().search(q) : []; searchSel = 0; renderSearch(); }, 140);
};
$("#search").onkeydown = (e) => {
  if (e.key === "ArrowDown") { searchSel = Math.min(searchSel + 1, searchRes.length - 1); renderSearch(); e.preventDefault(); }
  else if (e.key === "ArrowUp") { searchSel = Math.max(searchSel - 1, 0); renderSearch(); e.preventDefault(); }
  else if (e.key === "Enter") pickSearch(Math.max(searchSel, 0));
  else if (e.key === "Escape") { searchRes = []; renderSearch(); }
};
$("#search-results").onclick = (e) => { const it = e.target.closest(".dd-item"); if (it) pickSearch(+it.dataset.i); };

$("#modal-x").onclick = closeModal;
$("#modal").onclick = (e) => e.target.id === "modal" && closeModal();
document.addEventListener("keydown", (e) => e.key === "Escape" && closeModal());
$("#tuto-next").onclick = () => (tutoI === TUTO.length - 1 ? endTuto() : showTuto(tutoI + 1));
$("#tuto-prev").onclick = () => showTuto(Math.max(0, tutoI - 1));
$("#tuto-skip").onclick = endTuto;
$("#btn-tuto").onclick = () => showTuto(0);
$("#btn-home").onclick = () => window.showHome && showHome();
$("#btn-news").onclick = async () => showNews(await api().whats_new(true), true);
$("#btn-intro").onclick = async () => {
  const o = await api().intro_settings();
  api().set_layout("wide");
  await window.playIntro({ version: o.version });
  goTab(S.tab);  // retour à la taille de l'onglet en cours
};
$("#opt-intro").onchange = (e) => api().set_intro(e.target.checked);

window.addEventListener("pywebviewready", init);
