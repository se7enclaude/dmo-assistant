/* Animation d'ouverture (sans son) : sceau, éclair, cartes en éventail, titre Se7en. */
(function () {
  const TOTAL = 7.0;
  const RUNES = "𓂀 ☥ 𓋹 ✶ ◬ 𓆣 ✧ ☥ 𓂀 ✶ ◬ ✧ 𓋹 𓆣".split(" ");

  function cardBack(i) {
    return `<div class="ib-card" style="--i:${i}"><div class="ib-card-in"><div class="ib-swirl"></div><div class="ib-eye-mini">◬</div></div></div>`;
  }
  function build() {
    const el = document.createElement("div");
    el.id = "intro";
    el.innerHTML = `
      <div class="ib-bg"></div>
      <div class="ib-rays"></div>
      <div class="ib-ring">${RUNES.map((r, i) => `<span style="--a:${i * (360 / RUNES.length)}deg">${r}</span>`).join("")}</div>
      <svg class="ib-sigil" viewBox="0 0 200 180">
        <defs><linearGradient id="ibg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff3c4"/><stop offset=".45" stop-color="#f5c451"/><stop offset="1" stop-color="#9a6416"/></linearGradient></defs>
        <path d="M100 8 L192 172 L8 172 Z" fill="none" stroke="url(#ibg)" stroke-width="7" stroke-linejoin="round"/>
        <path d="M100 30 L174 162 L26 162 Z" fill="rgba(245,196,81,.08)" stroke="url(#ibg)" stroke-width="2"/>
        <path d="M58 112 Q100 70 142 112 Q100 150 58 112 Z" fill="none" stroke="url(#ibg)" stroke-width="5"/>
        <circle cx="100" cy="112" r="13" fill="url(#ibg)"/>
        <path d="M100 125 L100 150 M86 124 L78 146 M114 124 L122 146" stroke="url(#ibg)" stroke-width="4" stroke-linecap="round"/>
      </svg>
      <div class="ib-flash"></div>
      <div class="ib-cards">${[0, 1, 2, 3, 4].map(cardBack).join("")}</div>
      <svg class="ib-bolt" viewBox="0 0 100 300" preserveAspectRatio="none"><path d="M60 0 L35 120 L58 125 L28 300 L75 140 L50 135 L80 0 Z"/></svg>
      <div class="ib-title">
        <div class="ib-main">${"SE7EN".split("").map((c, i) => `<span class="${c === "7" ? "seven" : ""}" style="--d:${i}">${c}</span>`).join("")}</div>
        <div class="ib-assistant">DMO ASSISTANT</div>
        <div class="ib-sub">C'est l'heure du duel !</div>
      </div>
      <div class="ib-skip">Clique pour passer</div>`;
    return el;
  }

  window.playIntro = function () {
    return new Promise((resolve) => {
      const el = build();
      document.body.appendChild(el);
      let done = false;
      requestAnimationFrame(() => el.classList.add("play"));
      const finish = () => {
        if (done) return; done = true;
        el.classList.add("out");
        setTimeout(() => { el.remove(); resolve(); }, 650);
        document.removeEventListener("keydown", finish, true);
      };
      el.addEventListener("click", finish);
      document.addEventListener("keydown", finish, true);
      setTimeout(finish, (TOTAL - 0.4) * 1000);
    });
  };
})();
