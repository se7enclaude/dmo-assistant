/* Animation d'ouverture façon écran-titre de Master Duel, avec les vraies cartes (sans son). */
(function () {
  const TOTAL = 6.6;
  const CARDS = ["img/carte-magicien-sombre.webp", "img/carte-dragon-blanc.webp", "img/carte-dragon-noir.webp"];

  function build(version) {
    const el = document.createElement("div");
    el.id = "intro";
    const dots = Array.from({ length: 46 }, (_, i) => {
      const x = (i * 37) % 100, y = (i * 61) % 100, d = (i % 7) * .45, s = 1 + (i % 3);
      return `<i style="left:${x}%;top:${y}%;width:${s}px;height:${s}px;animation-delay:-${d}s"></i>`;
    }).join("");
    el.innerHTML = `
      <div class="md-bg"></div>
      <div class="md-band b1"></div><div class="md-band b2"></div><div class="md-band b3"></div>
      <div class="md-lines"></div>
      <div class="md-dots">${dots}</div>
      <div class="md-cards">${CARDS.map((src, i) => `<div class="md-card" style="--i:${i};--dy:${i === 1 ? 0 : 18}px"><img src="${src}" alt=""></div>`).join("")}</div>
      <div class="md-flash"></div>
      <div class="md-title">
        <svg class="md-tri" viewBox="0 0 300 150" aria-hidden="true"><path d="M8 6 H292 L150 146 Z" fill="none" stroke="rgba(190,215,255,.8)" stroke-width="2"/></svg>
        <img class="md-logo" src="img/yugioh-logo.webp" alt="Yu-Gi-Oh!">
        <div class="md-name">SE<span>7</span>EN</div>
        <div class="md-sub">DMO ASSISTANT</div>
      </div>
      <div class="md-ring"></div>
      <div class="md-ver">Ver : ${version}<br>Créé par : Se7en</div>
      <div class="md-copy">Projet de fan gratuit, non affilié à Konami<br>Yu-Gi-Oh! © Studio Dice / SHUEISHA, TV TOKYO, KONAMI</div>
      <button class="md-skip">Passer</button>`;
    return el;
  }

  window.playIntro = function (opts = {}) {
    return new Promise((resolve) => {
      const el = build(opts.version || "");
      document.body.appendChild(el);
      let done = false;
      requestAnimationFrame(() => el.classList.add("play"));
      const finish = () => {
        if (done) return; done = true;
        el.classList.add("out");
        setTimeout(() => { el.remove(); resolve(); }, 600);
        document.removeEventListener("keydown", finish, true);
      };
      el.addEventListener("click", finish);
      document.addEventListener("keydown", finish, true);
      setTimeout(finish, TOTAL * 1000);
    });
  };
})();
