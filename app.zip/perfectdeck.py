"""« Deck parfait » : fusionne le deck du joueur avec sa collection pour en tirer la meilleure version,
puis explique les choix (ajouts, retraits, régularité, cartes clés, conseils).

Les explications sont générées par règles à partir des données des cartes (archétype, popularité
sur YGOPRODeck, staples, interruptions connues) : ce sont des repères, pas une vérité de tournoi.
"""
import re
from math import comb

import deckbuilder
from carddb import kind

# cartes « interruption depuis la main » (hand traps) courantes
HAND_TRAPS = {
    "Ash Blossom & Joyous Spring", "Effect Veiler", "Infinite Impermanence", "Ghost Ogre & Snow Rabbit",
    "Ghost Belle & Haunted Mansion", "Ghost Mourner & Moonlit Chill", "Droll & Lock Bird", 'Maxx "C"',
    "Nibiru, the Primal Being", "D.D. Crow", "PSY-Framegear Gamma", "Mulcharmy Fuwalos", "Mulcharmy Purulia",
    "Mulcharmy Meowls", "Dimension Shifter", "Artifact Lancea", "Ghost Sister & Spooky Dogwood",
    "Bystial Druiswurm", "Bystial Magnamhut", "Kuriboh", "Battle Fader", "Swift Scarecrow", "Gorz the Emissary of Darkness",
}
REASON_IN = {
    "Archétype": "carte de l'archétype {a} que tu possèdes",
    "Soutien d'archétype": "soutien direct de l'archétype {a}",
    "Staple": "staple très jouée (interruption ou pioche) que tu possèdes",
    "Carte générique populaire": "bonne carte générique pour compléter le deck",
    "Hors archétype": "complète le deck faute de mieux dans ta collection",
    "Remplissage": "remplissage : il manquait des cartes jouables",
}


def p_at_least(k, n=40, hand=5, need=1):
    """Probabilité d'avoir au moins `need` des k cartes utiles dans une main de `hand` cartes (deck de n)."""
    if n <= 0 or k <= 0:
        return 0.0
    hand = min(hand, n)
    miss = sum(comb(k, i) * comb(n - k, hand - i) for i in range(need)) / comb(n, hand)
    return 1 - miss


def first_sentence(text, limit=170):
    text = re.sub(r"\s+", " ", (text or "").replace("\n", " ")).strip()
    s = re.split(r"(?<=[.])\s", text)[0] if text else ""
    return (s[:limit - 1] + "…") if len(s) > limit else s


def _main_archetype(db, deck):
    """Archétype dominant du deck (pondéré par le nombre d'exemplaires)."""
    score = {}
    for cid, n in deck.items():
        c = db.get(int(cid))
        if c and c["archetype"]:
            score[c["archetype"]] = score.get(c["archetype"], 0) + n
    return max(score, key=score.get) if score else None


def _arch_count(db, counts, arch):
    if not arch:
        return 0
    return sum(n for cid, n in counts.items()
               if db.get(int(cid)) and kind(db.get(int(cid))) != "extra" and deckbuilder._in_archetype(db.get(int(cid)), arch))


def _main_size(db, counts):
    return sum(n for cid, n in counts.items() if db.get(int(cid)) and kind(db.get(int(cid))) != "extra")


def optimize(db, deck, collection, assume3=False):
    """deck, collection : {id: quantité}. Renvoie le deck optimisé et ses explications."""
    deck = {int(k): v for k, v in deck.items() if db.get(int(k))}
    collection = {int(k): v for k, v in collection.items() if db.get(int(k))}
    owned_ids = set(deck) | set(collection)
    pool = dict(collection)
    for cid, n in deck.items():  # les cartes du deck sont possédées
        pool[cid] = max(pool.get(cid, 0), n)

    arch = _main_archetype(db, deck)
    if arch is None:
        opts = deckbuilder.archetype_options(db, pool, assume3, limit=1)
        arch = opts[0]["name"] if opts else None
    res = deckbuilder.build(db, pool, arch, assume3, prefer=deck.keys())
    final = {}
    for e in res["main"] + res["extra"]:
        final[e["id"]] = final.get(e["id"], 0) + e["n"]
    reasons = {e["id"]: e["reason"] for e in res["main"] + res["extra"]}

    # ---- changements
    added, removed = [], []
    for cid, n in final.items():
        before = deck.get(cid, 0)
        if n > before:
            added.append({"id": cid, "n": n - before,
                          "why": ("passe de %d à %d exemplaires : " % (before, n) if before else "")
                          + REASON_IN.get(reasons[cid], "").format(a=arch or "")})
    best_kept = sorted((db.get(c) for c in final), key=lambda c: -c["views"])
    for cid, n in deck.items():
        after = final.get(cid, 0)
        if after >= n:
            continue
        c = db.get(cid)
        if c["ban_tcg"] == "Banned":
            why = "interdite dans la banlist TCG"
        elif after:
            why = f"réduite de {n} à {after} exemplaire(s) pour faire de la place à des cartes plus utiles"
        elif kind(c) == "extra" and len(res["extra"]) >= deckbuilder.MAX_EXTRA:
            why = "l'Extra Deck est limité à 15 cartes : d'autres sont plus utiles"
        elif arch and c["archetype"] and c["archetype"] != arch:
            why = f"carte de l'archétype {c['archetype']}, sans synergie avec {arch}"
        elif c["type"] == "Normal Monster":
            why = "monstre sans effet, peu d'impact"
        else:
            why = "moins jouée / moins efficace que les cartes choisies"
        removed.append({"id": cid, "n": n - after, "why": why})

    # ---- régularité (probabilité d'ouvrir avec une carte de l'archétype)
    main_before, main_after = _main_size(db, deck), res["counts"]["main"]
    k_before, k_after = _arch_count(db, deck, arch), _arch_count(db, final, arch)
    cons = {
        "before": round(p_at_least(k_before, max(main_before, 1)) * 100) if deck else None,
        "after": round(p_at_least(k_after, max(main_after, 1)) * 100),
        "two_after": round(p_at_least(k_after, max(main_after, 1), need=2) * 100),
        "k_after": k_after,
    }
    hts = [cid for cid in final if db.get(cid)["name_en"] in HAND_TRAPS]
    ht_count = sum(final[c] for c in hts)
    ht_p = round(p_at_least(ht_count, max(main_after, 1)) * 100)

    # ---- cartes clés (les plus jouées de l'archétype dans le deck final)
    key = [c for c in best_kept if kind(c) != "extra" and arch and deckbuilder._in_archetype(c, arch)][:4]
    key_cards = [{"id": c["id"], "role": first_sentence(c["desc_fr"] or c["desc_en"])} for c in key]

    # ---- pourquoi ce deck
    c = res["counts"]
    why = []
    if arch:
        why.append(f"Construit autour de l'archétype **{arch}** : {k_after} cartes sur {main_after} jouent ensemble "
                   f"(cartes de l'archétype et soutiens qui le mentionnent).")
    else:
        why.append("Aucun archétype assez fourni : le deck réunit tes meilleures cartes génériques.")
    if cons["before"] is not None and arch:
        delta = cons["after"] - cons["before"]
        if delta > 0:
            why.append(f"Plus régulier : {cons['after']} % de chances d'avoir une carte {arch} en main de départ "
                       f"(contre {cons['before']} % avant), car les cartes hors-thème ont été remplacées.")
        else:
            why.append(f"Régularité conservée : {cons['after']} % de chances d'ouvrir avec une carte {arch}.")
    elif arch:
        why.append(f"{cons['after']} % de chances d'ouvrir avec au moins une carte {arch}, {cons['two_after']} % d'en avoir deux.")
    if main_after <= 42:
        why.append(f"{main_after} cartes : rester proche du minimum de 40 maximise les chances de piocher tes meilleures cartes.")
    if ht_count:
        why.append(f"{ht_count} interruption(s) depuis la main ({', '.join(db.get(h)['name_fr'] for h in hts[:4])}) : "
                   f"{ht_p} % de chances d'en avoir une pour gêner l'adversaire pendant son tour.")
    why.append(f"Répartition : {c['monstre']} monstres, {c['magie']} magies, {c['piège']} pièges, Extra Deck de {c['extra']}.")

    # ---- conseils
    tips = []
    if main_after < 40:
        tips.append(f"Il manque {40 - main_after} carte(s) jouable(s) pour atteindre 40 : scanne plus de cartes de ta collection "
                    "ou procure-toi celles de la liste « à obtenir ».")
    if arch and k_after < 15:
        tips.append(f"Seulement {k_after} cartes {arch} : vise 15 à 20 cartes de l'archétype pour un deck vraiment régulier.")
    if ht_count < 3:
        tips.append("Peu d'interruptions depuis la main (Ash Blossom, Effect Veiler, Infinite Impermanence…) : "
                    "elles protègent contre les decks qui enchaînent les combos.")
    if c["monstre"] < 13:
        tips.append("Moins de 13 monstres : risque de mains sans monstre à poser. Privilégie les monstres de l'archétype.")
    if c["piège"] > 10:
        tips.append("Beaucoup de pièges : ils sont lents (posés un tour à l'avance). Garde surtout ceux qui interrompent.")
    if c["extra"] < 10 and arch:
        tips.append("Extra Deck peu rempli : des monstres Fusion/Synchro/Xyz/Lien génériques donnent beaucoup d'options.")
    wanted = [m for m in res["missing"] if m.get("reason") in ("Archétype", "Soutien")]
    if wanted:
        names = ", ".join(db.get(m["id"])["name_fr"] for m in wanted[:3])
        tips.append(f"À te procurer en priorité pour {arch} : {names} (les plus jouées de l'archétype que tu n'as pas).")
    tips += [w for w in res["warnings"] if "vide" not in w]

    return {
        "archetype": arch, "main": res["main"], "extra": res["extra"], "counts": c,
        "added": added, "removed": removed, "consistency": cons, "hand_traps": ht_count,
        "key_cards": key_cards, "why": why, "tips": tips,
        "missing": [m for m in res["missing"] if m["id"] not in owned_ids],
        "deck_size_before": main_before,
    }
