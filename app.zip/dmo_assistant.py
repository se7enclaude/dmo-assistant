"""DMO Assistant — overlay de traduction FR des cartes Yu-Gi-Oh! + collection + générateur de deck.

L'interface est en HTML (dossier ui/) affichée par pywebview ; ce fichier fournit l'API Python
(OCR, base de cartes, deck, collection) et les raccourcis clavier globaux.
"""
import ctypes
import ctypes.wintypes
import json
import math
import os
import subprocess
import tempfile
import sys
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import webview

import carddb
import deckbuilder
import updater
from carddb import kind, stats_line, type_line

ROOT = carddb.ROOT
UI_DIR = os.path.join(carddb.APP_DIR, "ui")
IMG_DIR = os.path.join(UI_DIR, "cache", "img")
CONFIG_PATH = os.path.join(ROOT, "config.json")
DECKS_PATH = os.path.join(ROOT, "decks.json")
COLLECTION_PATH = os.path.join(ROOT, "collection.json")
TITLE = "DMO Assistant"
HUD_TITLE = "DMO HUD"
SIZES = {"compact": (470, 780), "wide": (1120, 780)}

DEFAULT_HUD = {
    "enabled": True,          # overlay affiché directement sur le jeu
    "anchor": "zone",         # "zone" : à côté du nom de la carte ; "libre" : position choisie
    "pos": None,              # [x, y] en mode libre
    "opacity": 0.9,
    "font": 14,
    "width": 400,
    "max_height": 420,
    "hide_after": 3,          # secondes sans carte reconnue avant de masquer (mode auto)
    "image": True,
    "record_visible": False,  # visible sur les enregistrements (OBS, TikTok…)
}
DEFAULT_CONFIG = {
    "hotkeys": {"scan": "f8", "zone": "f9", "auto": "f10", "toggle": "f7", "collection": "f6", "hud": "f11",
                "learn": "shift+f8"},
    "aim": "souris",          # comment viser la carte : "souris", "nom" (zone du nom), "illustration" (zone)
    "zone": None,             # zone du nom de carte
    "art_zone": None,         # zone où le jeu affiche l'illustration de la carte sélectionnée
    "auto_interval": 0.35,    # la reconnaissance prend ~60 ms : le mode auto peut suivre la souris de près
    "window": [40, 60],
    "tutorial_done": False,
    "show_english": False,
    "intro": True,            # animation d'ouverture
    "seen_version": None,     # dernière version dont on a montré les nouveautés
    "hud": DEFAULT_HUD,
}
WS_EX_TRANSPARENT, WS_EX_LAYERED, WS_EX_TOOLWINDOW, WS_EX_NOACTIVATE = 0x20, 0x80000, 0x80, 0x08000000
BAN_FR = {"Banned": "Interdite", "Limited": "Limitée", "Semi-Limited": "Semi-limitée"}

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


_user32 = ctypes.windll.user32
_user32.GetWindowLongPtrW.restype = ctypes.c_ssize_t
_user32.GetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int]
_user32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
_user32.SetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]


def find_hwnd(title):
    return _user32.FindWindowW(None, title)


def set_capture_visible(title, visible):
    """visible=False : la fenêtre n'apparaît pas dans les captures (OCR, OBS, TikTok…)."""
    if os.environ.get("DMO_VISIBLE_IN_CAPTURE"):
        visible = True
    hwnd = find_hwnd(title)
    if hwnd:
        _user32.SetWindowDisplayAffinity(hwnd, 0 if visible else 0x11)


def make_form_transparent(window, on=True):
    """Fond de fenêtre WinForms en couleur-clé (magenta) : seules les zones dessinées par la page restent visibles.
    La couleur-clé rend aussi toute la fenêtre insensible à la souris : on la coupe pendant le placement."""
    try:
        from System import Action
        from System.Drawing import Color
        from webview.platforms.winforms import BrowserView
        form = BrowserView.instances[window.uid]

        def apply():
            key = Color.FromArgb(255, 255, 0, 255)
            form.BackColor = key if on else Color.FromArgb(255, 13, 15, 20)
            form.TransparencyKey = key if on else Color.Empty
        form.Invoke(Action(apply))
    except Exception:
        pass


def set_click_through(title, on):
    """on=True : les clics traversent la fenêtre et vont au jeu en dessous."""
    hwnd = find_hwnd(title)
    if not hwnd:
        return
    style = _user32.GetWindowLongPtrW(hwnd, -20)
    style |= WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
    style = style | WS_EX_TRANSPARENT if on else style & ~WS_EX_TRANSPARENT
    _user32.SetWindowLongPtrW(hwnd, -20, style)


class Api:
    def __init__(self):
        self._window = None
        self._db = None
        self._error = None
        self._status = "Chargement de la base de cartes…"
        self._cfg = {**DEFAULT_CONFIG, **load_json(CONFIG_PATH, {})}
        self._cfg["hotkeys"] = {**DEFAULT_CONFIG["hotkeys"], **self._cfg.get("hotkeys", {})}
        self._cfg["hud"] = {**DEFAULT_HUD, **self._cfg.get("hud", {})}
        if self._cfg.get("auto_interval") == 0.7:  # ancienne valeur par défaut (reconnaissance alors 20× plus lente)
            self._cfg["auto_interval"] = 0.35
        self._hud = None
        self._hud_visible = False
        self._hud_edit = False
        self._hud_card = None
        self._hud_seen = 0.0
        self._hud_manual = False
        self._hud_h = 220
        self._hud_anchor = None   # rectangle écran de la carte reconnue (le HUD se met à côté)
        self._last_cursor = None
        self._last_miss = None
        self._auto_learned = set()
        self._decks = load_json(DECKS_PATH, None) or self._migrate_old_deck()
        self._collection = load_json(COLLECTION_PATH, {})
        self._scan_lock = threading.Lock()
        self._auto = False
        self._collect = False
        self._collect_found = []
        self._last_auto_id = None
        self._img_pool = ThreadPoolExecutor(4)
        self._art = None
        self._update = None       # mise à jour installée en attente de redémarrage
        threading.Thread(target=self._load_db, daemon=True).start()
        threading.Thread(target=self._check_update, daemon=True).start()

    # ------------------------------------------------------------------ interne
    def _migrate_old_deck(self):
        old = load_json(os.path.join(ROOT, "deck.json"), {}).get("cards", {})
        return {"current": "Mon deck", "decks": {"Mon deck": old}}

    def _emit(self, kind_, data=None):
        if self._window:
            try:
                self._window.evaluate_js(f"window.onBackend && window.onBackend({json.dumps([kind_, data])})")
            except Exception:
                pass

    def _set_status(self, msg):
        self._status = msg
        self._emit("status", msg)

    def _save_cfg(self):
        save_json(CONFIG_PATH, self._cfg)

    def _load_db(self):
        try:
            carddb.ensure_data(log=self._set_status)
            self._db = carddb.CardDB()
            self._set_status(f"{len(self._db)} cartes chargées")
            self._register_hotkeys()
            self._emit("ready", self.state())
            if self._cfg["aim"] != "nom":
                self._art_ready()  # prépare l'index des illustrations dès le démarrage si besoin
            threading.Thread(target=self._translate_missing, daemon=True).start()
        except Exception as e:
            self._error = str(e)
            self._emit("error", self._error)

    def _translate_missing(self):
        """Traduit automatiquement (une fois) les cartes qui n'ont pas de texte français officiel."""
        try:
            import translate
            if not translate.available():
                return
            todo = sum(1 for c in self._db.cards.values() if not c["desc_fr"] and c["desc_en"])
            if todo:
                translate.translate_missing(self._db, on_progress=lambda i, n: self._set_status(
                    f"Traduction des cartes sans texte français officiel : {i}/{n}…") if i % 200 == 0 else None)
                n = self._db.load_translations()
                self._set_status(f"{n} cartes traduites automatiquement ✓")
        except Exception as e:
            self._set_status(f"Traduction automatique indisponible ({e})")

    def _register_hotkeys(self):
        try:
            import keyboard
            actions = {"scan": self.scan, "zone": self.select_zone, "auto": self.toggle_auto,
                       "toggle": self.toggle_visibility, "collection": self.toggle_collection_scan,
                       "hud": self.hud_toggle, "learn": self.learn_hotkey}
            for action, key in self._cfg["hotkeys"].items():
                if action in actions and key:
                    keyboard.add_hotkey(key, lambda f=actions[action]: threading.Thread(target=f, daemon=True).start())
        except Exception as e:
            self._set_status(f"Raccourcis clavier indisponibles ({e})")

    def _summary(self, c, **extra):
        return {
            "id": c["id"], "name_fr": c["name_fr"], "name_en": c["name_en"], "kind": kind(c),
            "type_line": type_line(c), "stats": stats_line(c), "ban": BAN_FR.get(c["ban_tcg"]),
            "img": f"cache/img/{c['id']}.jpg" if os.path.exists(os.path.join(IMG_DIR, f"{c['id']}.jpg")) else None,
            **extra,
        }

    def _deck(self):
        return self._decks["decks"].setdefault(self._decks["current"], {})

    def _save_decks(self):
        save_json(DECKS_PATH, self._decks)

    def _save_collection(self):
        save_json(COLLECTION_PATH, self._collection)

    def _window_rect(self):
        rects = []
        for w, visible in ((self._window, not getattr(self, "_hidden", False)), (self._hud, self._hud_visible)):
            try:
                if w and visible:
                    rects.append((w.x, w.y, w.width, w.height))
            except Exception:
                pass
        return rects

    def _capture_masks(self):
        """Nos fenêtres qui apparaissent quand même dans les captures (à noircir pour ne pas les lire).
        Normalement aucune : elles sont exclues des captures, et le jeu en dessous reste lisible."""
        if os.environ.get("DMO_VISIBLE_IN_CAPTURE"):
            return self._window_rect()
        if self._cfg["hud"]["record_visible"] and self._hud_visible:
            try:
                return [(self._hud.x, self._hud.y, self._hud.width, self._hud.height)]
            except Exception:
                pass
        return []

    # ------------------------------------------------------------------ état général
    def state(self):
        return {
            "ready": self._db is not None, "error": self._error, "status": self._status,
            "hotkeys": self._cfg["hotkeys"], "tutorial_done": self._cfg["tutorial_done"],
            "zone": self._cfg["zone"], "art_zone": self._cfg["art_zone"], "aim": self._cfg["aim"],
            "auto": self._auto, "collecting": self._collect,
            "show_english": self._cfg["show_english"],
            "deck_name": self._decks["current"], "deck_names": list(self._decks["decks"]),
            "collection_count": len(self._collection), "hud": self._cfg["hud"],
        }

    # ------------------------------------------------------------------ ouverture, nouveautés, mises à jour
    def intro_settings(self):
        return {"intro": self._cfg["intro"], "version": updater.local()["version"]}

    def set_intro(self, intro):
        self._cfg["intro"] = bool(intro)
        self._save_cfg()
        return self.intro_settings()

    def whats_new(self, show_all=False):
        """Nouveautés depuis la dernière version vue (toutes avec show_all)."""
        info = updater.local()
        seen = self._cfg["seen_version"]
        if show_all:
            entries = updater.notes_between(info.get("history", []), "0", info["version"])
        elif seen is None or not self._cfg["tutorial_done"]:
            entries = []          # première installation : le tutoriel suffit
        else:
            entries = updater.notes_between(info.get("history", []), seen, info["version"])
        if self._cfg["seen_version"] != info["version"]:
            self._cfg["seen_version"] = info["version"]
            self._save_cfg()
        return {"version": info["version"], "entries": entries}

    def _check_update(self):
        time.sleep(4)
        try:
            remote = updater.check()
            if not remote:
                return
            old = updater.local()["version"]
            self._emit("update", {"state": "downloading", "version": remote["version"]})
            updater.apply(remote)
            self._update = remote
            self._emit("update", {"state": "ready", "version": remote["version"],
                                  "entries": updater.notes_between(remote.get("history", []), old, remote["version"])})
        except Exception as e:
            print("mise à jour :", e)
            if "retélécharger" in str(e):
                self._emit("update", {"state": "manual", "message": str(e), "url": (remote or {}).get("download")})

    def pending_update(self):
        return {"version": self._update["version"]} if self._update else None

    def check_update_now(self):
        threading.Thread(target=self._check_update, daemon=True).start()
        return True

    def restart_app(self):
        """Relance l'application (après une mise à jour)."""
        subprocess.Popen([sys.executable] + ([] if getattr(sys, "frozen", False) else [os.path.abspath(__file__)]),
                         cwd=ROOT, creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))
        self.close()

    def open_url(self, url):
        if isinstance(url, str) and url.startswith("https://"):
            os.startfile(url)

    def complete_tutorial(self):
        self._cfg["tutorial_done"] = True
        self._save_cfg()

    def set_show_english(self, value):
        self._cfg["show_english"] = bool(value)
        self._save_cfg()
        self._hud_apply_settings()

    # ------------------------------------------------------------------ fenêtre
    def minimize(self):
        self._window.minimize()

    def close(self):
        try:
            self._cfg["window"] = [self._window.x, self._window.y]
            self._save_cfg()
        except Exception:
            pass
        if self._hud:
            self._hud.destroy()
        self._window.destroy()

    def set_layout(self, mode):
        """Passe en fenêtre étroite ou large, avec une courte animation (plus de saut brusque)."""
        w, h = SIZES.get(mode, SIZES["compact"])
        win = self._window
        try:
            cw, ch = int(win.width), int(win.height)
        except Exception:
            cw, ch = w, h
        self._layout_gen = getattr(self, "_layout_gen", 0) + 1
        gen = self._layout_gen
        if (cw, ch) == (w, h):
            return

        def animate():
            steps = 7
            for i in range(1, steps + 1):
                if gen != self._layout_gen:  # un autre changement a pris le relais
                    return
                e = 1 - (1 - i / steps) ** 3
                try:
                    win.resize(round(cw + (w - cw) * e), round(ch + (h - ch) * e))
                except Exception:
                    return
                time.sleep(0.014)
        threading.Thread(target=animate, daemon=True).start()

    def toggle_visibility(self):
        if getattr(self, "_hidden", False):
            self._window.show()
            self._hidden = False
            exclude_from_capture()
        else:
            self._window.hide()
            self._hidden = True

    # ------------------------------------------------------------------ cartes
    def search(self, query):
        if not self._db:
            return []
        return [self._summary(c) for c in self._db.search(query, limit=30)]

    def card(self, cid):
        c = self._db.get(int(cid))
        if not c:
            return None
        return self._summary(
            c, desc_fr=c["desc_fr"], desc_en=c["desc_en"], archetype=c["archetype"],
            fr_auto=bool(c.get("fr_auto")), custom=bool(c.get("custom")), unofficial=bool(c.get("unofficial")),
            attribute=c.get("attribute"), level=c.get("level"), linkval=c.get("linkval"), atk=c.get("atk"), def_=c.get("def"),
            ctype=c.get("type"), race_fr=carddb.RACES_FR.get(c.get("race"), c.get("race") or ""),
            in_deck=self._deck().get(str(c["id"]), 0), owned=self._collection.get(str(c["id"]), 0))

    def related(self, cid):
        c = self._db.get(int(cid))
        return [self._summary(r) for r in self._db.related(c, limit=40)] if c else []

    def _fetch_image(self, cid):
        """Télécharge la vignette d'une carte si besoin. Renvoie True si elle est disponible."""
        c = self._db.get(int(cid))
        path = os.path.join(IMG_DIR, f"{cid}.jpg")
        if os.path.exists(path):
            return True
        if not c or not c["image"]:
            return False
        try:
            os.makedirs(IMG_DIR, exist_ok=True)
            req = urllib.request.Request(c["image"], headers={"User-Agent": "DMO-Assistant/2.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = r.read()
            with open(path + ".part", "wb") as f:
                f.write(data)
            os.replace(path + ".part", path)
            self._emit("image", {"id": int(cid), "src": f"cache/img/{cid}.jpg"})
            return True
        except Exception:
            return False

    def ensure_images(self, ids):
        """Télécharge (une fois) les vignettes manquantes, puis prévient l'interface."""
        for cid in ids:
            self._img_pool.submit(self._fetch_image, cid)

    # ------------------------------------------------------------------ overlay sur le jeu (HUD)
    def _hud_js(self, code):
        if self._hud:
            try:
                self._hud.evaluate_js(code)
            except Exception:
                pass

    def _hud_apply_settings(self):
        s = self._cfg["hud"]
        self._hud_js(f"window.hudSettings && window.hudSettings({json.dumps({**s, 'show_english': self._cfg['show_english']})})")
        set_capture_visible(HUD_TITLE, s["record_visible"])
        set_click_through(HUD_TITLE, not self._hud_edit)

    def _hud_geometry(self):
        """Position du HUD : à côté de la carte reconnue (sans la cacher) ou position libre."""
        import mss
        s = self._cfg["hud"]
        w, h = int(s["width"] * s["font"] / 14), self._hud_h
        with mss.mss() as sct:
            mons = sct.monitors[1:]
        zone = self._hud_anchor or self._cfg["zone"]
        if s["anchor"] == "libre" and s["pos"]:
            x, y = s["pos"]
        elif zone:
            zx, zy, zw, zh = zone
            mon = next((m for m in mons if m["left"] <= zx < m["left"] + m["width"]
                        and m["top"] <= zy < m["top"] + m["height"]), mons[0])
            right = mon["left"] + mon["width"]
            if zx + zw + 14 + w <= right:          # à droite du nom
                x, y = zx + zw + 14, zy
            elif zx - 14 - w >= mon["left"]:       # à gauche
                x, y = zx - 14 - w, zy
            else:                                  # en dessous
                x, y = zx, zy + zh + 10
            y = min(y, mon["top"] + mon["height"] - h - 10)
        else:
            m = mons[0]
            x, y = m["left"] + m["width"] - w - 30, m["top"] + 120
        return int(x), int(y), w, h

    def _hud_place(self):
        if not self._hud:
            return
        x, y, w, h = self._hud_geometry()
        self._hud.resize(w, h)
        if not self._hud_edit:
            self._hud.move(x, y)

    def _hud_show(self, card, manual=False, anchor=None):
        s = self._cfg["hud"]
        if anchor:
            self._hud_anchor = anchor
        if not self._hud or not s["enabled"]:
            return
        if s["image"] and self._fetch_image(card["id"]):
            card = {**card, "img": f"cache/img/{card['id']}.jpg"}
        self._hud_card = card
        self._hud_seen = time.time()
        self._hud_manual = manual
        self._hud_js(f"window.hudShow({json.dumps(card)})")
        self._hud_place()
        if not self._hud_visible:
            self._hud.show()
            self._hud_visible = True
            self._hud_apply_settings()

    def _hud_hide(self):
        if self._hud and self._hud_visible and not self._hud_edit:
            self._hud_js("window.hudHide()")
            time.sleep(0.2)
            self._hud.hide()
            self._hud_visible = False

    def _hud_watch(self):
        """Masque le HUD quand la carte n'est plus reconnue depuis quelques secondes."""
        while True:
            time.sleep(0.4)
            if not self._hud_visible or self._hud_edit:
                continue
            limit = 20 if self._hud_manual and not self._auto else self._cfg["hud"]["hide_after"]
            if time.time() - self._hud_seen > limit:
                self._hud_hide()

    def hud_resize(self, h):
        self._hud_h = max(60, min(int(h), 900))
        self._hud_place()

    def hud_settings(self):
        return self._cfg["hud"]

    def set_hud(self, key, value):
        if key not in DEFAULT_HUD:
            return self._cfg["hud"]
        self._cfg["hud"][key] = value
        self._save_cfg()
        if key == "enabled" and not value:
            self._hud_hide()
        self._hud_apply_settings()
        if self._hud_visible:
            self._hud_place()
        return self._cfg["hud"]

    def hud_toggle(self):
        on = not self._cfg["hud"]["enabled"]
        self.set_hud("enabled", on)
        self._emit("hud", self._cfg["hud"])
        self._set_status("Overlay en jeu activé" if on else "Overlay en jeu désactivé")
        if on and self._hud_card:
            self._hud_show(self._hud_card, manual=True)

    def hud_demo(self):
        """Affiche un exemple pour régler l'apparence."""
        if not self._cfg["hud"]["enabled"]:
            self.set_hud("enabled", True)
            self._emit("hud", self._cfg["hud"])
        self._hud_show(self.card(self._hud_card["id"] if self._hud_card else 14558127), manual=True)

    def hud_edit(self, on):
        """Mode placement : le HUD devient cliquable et déplaçable, puis on mémorise sa position."""
        on = bool(on)
        if on:
            self.hud_demo()
            self._hud_edit = True
            make_form_transparent(self._hud, False)
            set_click_through(HUD_TITLE, False)
            self._hud_js("window.hudEdit(true)")
        else:
            self._hud_edit = False
            try:
                self._cfg["hud"]["pos"] = [self._hud.x, self._hud.y]
                self._cfg["hud"]["anchor"] = "libre"
                self._save_cfg()
            except Exception:
                pass
            self._hud_js("window.hudEdit(false)")
            make_form_transparent(self._hud, True)
            set_click_through(HUD_TITLE, True)
            self._hud_seen = time.time()
            self._emit("hud", self._cfg["hud"])
            self._set_status("Position de l'overlay enregistrée ✓")
        return on

    # ------------------------------------------------------------------ scan
    def _ocr_cards(self, use_zone, cutoff_full=86):
        import screen_ocr
        zone = self._cfg["zone"] if use_zone else None
        img = screen_ocr.grab(zone, self._capture_masks())
        found = {}
        self._name_score = 0
        if zone:
            # Zone de titre (une ligne) : tolérance aux fautes d'OCR. Grande zone (carte entière, texte d'effet…) :
            # n'importe quel bout de texte ressemblerait à un nom de carte -> ligne par ligne, correspondance stricte.
            title = self._name_zone_ok()
            cutoff = 80 if title else 92
            scale = 3.0 if img.height < 40 else 2.0 if img.height < 90 else 1.0
            nlines = 0
            for lines in screen_ocr.ocr_variants(img, scale):
                nlines = max(nlines, len(lines))
                texts = [l["text"] for l in lines if len(l["text"].strip()) >= 4]
                for t in ([" ".join(texts)] if title else []) + texts:
                    c, score = self._db.match(t, cutoff)
                    if c and score > found.get(c["id"], (0, None))[0]:
                        found[c["id"]] = (score, c)
                if found and max(s for s, _ in found.values()) >= 95:
                    break
            if found:
                self._name_score = max(s for s, _ in found.values())
            return [c for s, c in sorted(found.values(), key=lambda x: -x[0])], nlines
        lines = screen_ocr.ocr_image(img)
        texts = [l["text"] for l in lines] + [a["text"] + " " + b["text"] for a, b in zip(lines, lines[1:])]
        for t in texts:
            c, score = self._db.match(t, cutoff_full)
            if c and score > found.get(c["id"], (0, None))[0]:
                found[c["id"]] = (score, c)
        return [c for s, c in sorted(found.values(), key=lambda x: -x[0])], len(lines)

    def _art_ready(self):
        idx = self._art_index()
        if len(idx) >= 1000:  # index partiel utilisable (cartes populaires d'abord)
            return idx
        if not idx.building:
            self.art_build()
        return None

    def _cursor(self):
        pt = ctypes.wintypes.POINT()
        _user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y

    def _recognize(self, silent):
        """Selon le mode de visée. Renvoie (cartes trouvées, rectangle écran où se trouve la carte, message)."""
        import screen_ocr
        mode = self._cfg["aim"]
        art_zone, name_zone = self._cfg["art_zone"], self._cfg["zone"]
        if mode == "nom":
            ranked, nlines = self._ocr_cards(use_zone=True)
            if ranked and art_zone and self._name_zone_ok() and self._name_score >= 92 and self._art_ready():
                # zones du nom ET de l'illustration : une carte lue sans ambiguïté apprend son illustration
                self._auto_learn(ranked[0]["id"], screen_ocr.grab(art_zone, self._capture_masks()))
            hint = "" if name_zone else " Définis la zone du nom (F9) pour plus de fiabilité."
            return ranked, name_zone, f"Aucun nom de carte lu ({nlines} lignes).{hint}"
        idx = self._art_ready()
        if idx is None:
            return [], None, "Préparation de la reconnaissance des illustrations (~1 min, une seule fois)…"
        import ingame
        if mode == "illustration":
            if not art_zone:
                return [], None, "Aucune zone d'illustration : appuie sur F9 et encadre l'illustration de la carte."
            zimg = screen_ocr.grab(art_zone, self._capture_masks())
            hints = {}
            if zimg.height > zimg.width * 1.12:
                # zone = carte entière (illustration + barre) : on lit aussi le type et l'ATK/DEF
                art = ingame.art_of(zimg)
                hints = ingame.card_hints(zimg)
                if not hints.get("kind") and not any(k in hints for k in ("atk", "stat")):
                    # pas de barre de carte dans la zone (détail fermé : décor, ciel…) -> seulement si quasi identique
                    r = ingame.recognize_zone(art, idx)
                    r = r if r and r["dist"] < 16 else None
                else:
                    r = ingame.identify(art, hints, self._db, idx)
            else:
                art = zimg
                r = ingame.recognize_zone(art, idx)
                if r and r["dist"] >= 22:
                    r = None  # trop éloigné pour une zone fixe : sans doute pas de carte affichée
            if r and r["conf"] == "sûr":
                if self._strong_stats(r, hints):
                    self._auto_learn(r["id"], art)  # identifiée par ATK ET DEF sans ambiguïté : on retient l'illustration
                return [self._db.get(r["id"])], art_zone, ""
            if name_zone and self._name_zone_ok():  # illustration inconnue mais titre lisible sans ambiguïté
                ranked, _ = self._ocr_cards(use_zone=True)
                if ranked and self._name_score >= 92 and self._consistent(ranked[0], hints):
                    self._auto_learn(ranked[0]["id"], art)
                    return ranked[:1], art_zone, ""
            if r and not silent and self._consistent(self._db.get(r["id"]), hints):
                return [self._db.get(r["id"])], art_zone, ""  # « probable » : seulement sur demande (F8), sans apprendre
            return [], art_zone, "" if silent else "Aucune carte reconnue dans la zone. Maj+F8 pour l'apprendre."
        # souris : la carte sous le pointeur
        cx, cy = self._cursor()
        for (x, y, w, h) in self._window_rect()[:1]:  # pointeur sur l'appli elle-même
            if x <= cx < x + w and y <= cy < y + h:
                return [], None, "Pointe une carte dans le jeu (pas dans cette fenêtre)."
        hit = self._last_cursor  # (x, y, id, rect) de la dernière carte trouvée sous la souris
        if silent and hit and abs(cx - hit[0]) + abs(cy - hit[1]) < 6:
            return [self._db.get(hit[2])], hit[3], ""  # souris immobile sur la même carte : rien à refaire
        miss = self._last_miss
        if silent and miss and abs(cx - miss[0]) + abs(cy - miss[1]) < 6:
            return [], None, ""  # souris immobile sur une carte inconnue : inutile de réessayer
        R = ingame.HOVER_RADIUS
        mon = screen_ocr.monitor_at(cx, cy)
        x0, y0 = max(mon["left"], cx - R), max(mon["top"], cy - R)
        x1, y1 = min(mon["left"] + mon["width"], cx + R), min(mon["top"] + mon["height"], cy + R)
        img = screen_ocr.grab([x0, y0, x1 - x0, y1 - y0], self._capture_masks())
        r = ingame.recognize_at(img, cx - x0, cy - y0, idx)
        if not r or r["conf"] != "sûr":
            # illustration inconnue ou incertaine : type + ATK/DEF lus sur la carte
            whole = ingame.card_at(img, cx - x0, cy - y0)
            hints = ingame.card_hints(whole[0]) if whole else {}
            if whole:
                art = ingame.art_of(whole[0])
                ident = ingame.identify(art, hints, self._db, idx)
                if ident and ident["conf"] == "sûr":
                    if self._strong_stats(ident, hints):
                        self._auto_learn(ident["id"], art)
                    r = {**ident, "rect": whole[1], "crop": art}
            if r and not self._consistent(self._db.get(r["id"]), hints):
                r = None  # l'illustration ressemble, mais l'ATK/DEF lue sur la carte dit le contraire
        if r and r["conf"] != "sûr" and silent:
            r = None  # mode auto : on n'affiche que les cartes sûres (pas de fausse carte sur le décor)
        if not r:
            # illustration inconnue : le nom est-il écrit près de la carte ? Si oui, on apprend l'illustration.
            found = ingame.card_art_at(img, cx - x0, cy - y0)
            c = self._name_near(img, found[1]) if found else None
            if c:
                self._auto_learn(c["id"], found[0])
                rx, ry, rw, rh = found[1]
                rect = [x0 + rx, y0 + ry, rw, rh]
                self._last_cursor = (cx, cy, c["id"], rect)
                return [c], rect, ""
            self._last_cursor = None
            self._last_miss = (cx, cy)
            return [], None, "Aucune carte reconnue sous la souris. Maj+F8 pour l'apprendre (ou l'ajouter si elle manque)."
        self._last_miss = None
        if 8 <= r["dist"] < 14 and r.get("crop") is not None and r["conf"] == "sûr":
            idx.reinforce(r["id"], r["crop"])  # vue très sûre mais un peu différente : on la retient aussi
        rx, ry, rw, rh = r["rect"]
        rect = [x0 + rx, y0 + ry, rw, rh]
        self._last_cursor = (cx, cy, r["id"], rect)
        return [self._db.get(r["id"])], rect, ""

    def _name_near(self, img, rect):
        """Nom de carte écrit sur ou autour d'une carte (au-dessus, en dessous, à côté) : carte ou None."""
        import screen_ocr
        x, y, w, h = rect
        mx, my = int(w * 0.6), int(h * 0.5)
        region = img.crop((max(0, x - mx), max(0, y - my), min(img.width, x + w + mx), min(img.height, y + h + my)))
        best = (None, 0)
        for lines in screen_ocr.ocr_variants(region, 2.0 if region.height < 400 else 1.0)[:3]:
            texts = [l["text"] for l in lines] + [a["text"] + " " + b["text"] for a, b in zip(lines, lines[1:])]
            for t in texts:
                if len(t.strip()) < 6:  # mots courts (« Draw », « ATK »…) : trop de faux noms
                    continue
                c, score = self._db.match(t, 93)
                if c and score > best[1]:
                    best = (c, score)
            if best[1] >= 97:
                break
        return best[0]

    def _name_zone_ok(self):
        """La zone du nom est-elle une vraie ligne de titre (et pas toute la carte) ?"""
        z = self._cfg.get("zone")
        return bool(z) and z[3] <= 120 and z[2] >= z[3] * 2

    @staticmethod
    def _strong_stats(ident, hints):
        """Assez sûr pour apprendre l'illustration : ATK ET DEF exactes lues sur la carte, et soit c'est la seule
        carte possible, soit son illustration ressemble aussi (deux preuves qui concordent)."""
        if "atk" not in hints or ident["conf"] != "sûr":
            return False
        return ident.get("how") == "stats" or ident["dist"] >= 12  # (< 12 : déjà reconnue, rien à apprendre)

    @staticmethod
    def _consistent(card, hints):
        """La carte proposée a-t-elle le type et l'ATK/DEF lus sur l'image ? (indices absents = pas de contre-indication)"""
        if not card or not hints:
            return True
        if "atk" in hints and (card["atk"], card["def"]) != (hints["atk"], hints["def"]):
            return False
        if "stat" in hints and hints["stat"] not in (card["atk"], card["def"]):
            return False
        if hints.get("kind") in ("magie", "piège") and kind(card) != hints["kind"]:
            return False
        return True

    def _auto_learn(self, cid, art_img):
        """Mémorise l'illustration affichée par le jeu pour une carte identifiée sans ambiguïté (une fois par carte)."""
        idx = self._art_index()
        if cid in self._auto_learned:
            return
        r = idx.best(art_img, insets=(0.0, 0.04))
        if r and r[0] == cid and r[1] < 20:
            self._auto_learned.add(cid)  # déjà reconnue par son illustration
            return
        if r and r[0] != cid and r[1] < 16:
            return  # l'illustration ressemble nettement à une AUTRE carte : on n'apprend rien (doute)
        idx.learn(cid, art_img, src="auto")
        self._auto_learned.add(cid)
        c = self._db.get(cid)
        self._set_status(f"Illustration apprise automatiquement : {c['name_fr']} ✓")
        self._emit("learned", {"id": cid, "name": c["name_fr"]})

    def scan(self, silent=False):
        if not self._db or not self._scan_lock.acquire(blocking=False):
            return
        try:
            if not silent:
                self._set_status("Scan en cours…")
            ranked, anchor, msg = self._recognize(silent)
            if not ranked:
                if not silent or "Préparation" in msg:
                    self._set_status(msg)
                return
            if silent and ranked[0]["id"] == self._last_auto_id:
                self._hud_seen = time.time()  # toujours la même carte à l'écran
                if anchor != self._hud_anchor:
                    self._hud_anchor = anchor
                    self._hud_place()
                if not self._hud_visible and self._hud_card:
                    self._hud_show(self._hud_card, anchor=anchor)
                return
            self._last_auto_id = ranked[0]["id"]
            full = self.card(ranked[0]["id"])
            self._emit("card", {"card": full, "others": [self._summary(c) for c in ranked[1:8]]})
            self._hud_show(full, manual=not silent, anchor=anchor)
            self._set_status(f"Reconnu : {ranked[0]['name_en']}")
        except Exception as e:
            self._set_status(f"Erreur de scan : {e}")
        finally:
            self._scan_lock.release()

    # ------------------------------------------------------------------ apprendre une carte / ajouter une carte
    def learn_capture(self):
        """Capture l'illustration visée (souris ou zone d'illustration) pour l'associer à une carte.
        Renvoie {image, suggestions} ; appelé par le bouton « Apprendre » ou le raccourci (Maj+F8)."""
        import base64
        import io
        import ingame
        import screen_ocr
        idx = self._art_ready()
        if idx is None:
            self._set_status("Préparation de la reconnaissance des illustrations (~1 min)…")
            return {"error": "La reconnaissance des illustrations se prépare encore (~1 min). Réessaie dans un instant."}
        hints, name_hint = {}, None
        if self._cfg["aim"] == "illustration" and self._cfg["art_zone"]:
            crop = screen_ocr.grab(self._cfg["art_zone"], self._capture_masks())
        else:
            cx, cy = self._cursor()
            R = ingame.HOVER_RADIUS
            mon = screen_ocr.monitor_at(cx, cy)
            x0, y0 = max(mon["left"], cx - R), max(mon["top"], cy - R)
            x1, y1 = min(mon["left"] + mon["width"], cx + R), min(mon["top"] + mon["height"], cy + R)
            img = screen_ocr.grab([x0, y0, x1 - x0, y1 - y0], self._capture_masks())
            # carte entière redressée (perspective) : sa barre donne le type et l'ATK/DEF
            whole = ingame.card_at(img, cx - x0, cy - y0)
            if whole:
                hints = ingame.card_hints(whole[0])
            found = ingame.card_art_at(img, cx - x0, cy - y0)
            if found is None:
                best = ingame.analyze_at(img, cx - x0, cy - y0, idx)
                if not best:
                    return {"error": "Aucune carte trouvée sous la souris. Pointe bien l'illustration de la carte."}
                x, y, w, h = best["rect"]
                found = (img.crop((x, y, x + w, y + h)), best["rect"])
            crop = found[0]
            name_hint = self._name_near(img, found[1])
        self._learn_img = crop
        self._learn_hints = hints
        prev = crop.copy()
        prev.thumbnail((360, 360))
        buf = io.BytesIO()
        prev.save(buf, "PNG")
        return {"image": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode(),
                "hints": hints, "hint_text": self._hints_text(hints),
                "named": self._summary(name_hint) if name_hint else None,
                "suggestions": [self._summary(c) for c in self._learn_candidates(crop, hints, idx)]}

    @staticmethod
    def _hints_text(h):
        bits = [{"magie": "Carte Magie", "piège": "Carte Piège", "monstre": "Monstre", "extra": "Monstre d'Extra Deck"}.get(h.get("kind"), "")]
        if "atk" in h:
            bits.append(f"ATK {h['atk']} / DEF {h['def']}")
        elif "stat" in h:
            bits.append(f"ATK ou DEF {h['stat']}")
        return " · ".join(b for b in bits if b)

    def _learn_candidates(self, crop, hints, idx, k=12):
        """Cartes proposées pour une illustration inconnue : celles qui ont le bon type et la bonne ATK/DEF
        (lus sur la carte), classées par ressemblance d'illustration ; sinon les illustrations les plus proches."""
        import ingame
        pool = list(self._db.cards.values())
        if hints.get("kind"):
            pool = [c for c in pool if kind(c) == hints["kind"] or (hints["kind"] == "monstre" and kind(c) == "extra")]
        if "atk" in hints:
            exact = [c for c in pool if c["atk"] == hints["atk"] and c["def"] == hints["def"]]
            pool = exact or [c for c in pool if hints["atk"] in (c["atk"], c["def"]) or hints["def"] in (c["atk"], c["def"])]
        elif "stat" in hints:
            pool = [c for c in pool if hints["stat"] in (c["atk"], c["def"])]
        if hints and pool:
            dist = idx.distances(crop, [c["id"] for c in pool])
            pool.sort(key=lambda c: dist.get(c["id"], 99) - 2 * math.log10(c["views"] + 10))
            return pool[:k]
        return [self._db.get(i) for i in ingame.suggestions(crop, idx, k) if self._db.get(i)]

    def learn_hotkey(self):
        """Maj+F8 : capture puis ouvre la fenêtre d'apprentissage dans l'appli."""
        res = self.learn_capture()
        if getattr(self, "_hidden", False):
            self.toggle_visibility()
        self._emit("learn", res)

    def learn_confirm(self, cid):
        """Associe l'illustration capturée à la carte cid : elle sera reconnue la prochaine fois."""
        img = getattr(self, "_learn_img", None)
        c = self._db.get(int(cid))
        if img is None or not c:
            return False
        self._art_index().learn(c["id"], img)
        if c.get("custom") and not os.path.exists(os.path.join(IMG_DIR, f"{c['id']}.jpg")):
            os.makedirs(IMG_DIR, exist_ok=True)
            img.convert("RGB").save(os.path.join(IMG_DIR, f"{c['id']}.jpg"), quality=90)
        self._learn_img = None
        self._last_auto_id = None
        self._last_cursor = None
        self._set_status(f"Illustration apprise : {c['name_fr']} ✓")
        return True

    def create_card(self, fields):
        """Ajoute une carte absente de la base. Si l'effet est en anglais, il est traduit automatiquement."""
        fields = dict(fields)
        for k in ("atk", "def", "level"):
            v = str(fields.get(k) or "").strip()
            fields[k] = int(v) if v.isdigit() else None
        if fields.get("desc_en") and not fields.get("desc_fr"):
            try:
                import translate
                if translate.available():
                    fields["desc_fr"] = translate.translate_card_text(fields["desc_en"])
            except Exception:
                pass
        card = self._db.add_custom(fields)
        if getattr(self, "_learn_img", None) is not None:
            self.learn_confirm(card["id"])
        return self.card(card["id"])

    def custom_cards(self):
        return [self._summary(c) for c in self._db.cards.values() if c.get("custom")]

    def delete_card(self, cid):
        c = self._db.get(int(cid))
        if c and c.get("custom"):
            self._art_index().forget(c["id"])
            self._db.delete_custom(c["id"])
            return True
        return False

    def forget_art(self, cid):
        self._art_index().forget(int(cid))
        self._auto_learned.discard(int(cid))
        self._last_cursor = self._last_auto_id = None
        return True

    def learned_list(self):
        """Illustrations apprises (manuellement ou automatiquement), pour les vérifier / supprimer."""
        out = []
        for cid, s in self._art_index().learned_summary().items():
            c = self._db.get(cid)
            if c:
                out.append(self._summary(c, views=s["n"], auto=s["auto"]))
        return sorted(out, key=lambda c: c["name_fr"])

    def forget_auto_learned(self):
        """Efface toutes les illustrations apprises automatiquement (garde celles apprises à la main)."""
        self._art_index().forget(src="auto")
        self._auto_learned.clear()
        self._last_cursor = self._last_auto_id = None
        return len(self._art_index().learned)

    def set_aim(self, mode):
        if mode not in ("souris", "nom", "illustration"):
            return self._cfg["aim"]
        self._cfg["aim"] = mode
        self._save_cfg()
        self._last_auto_id = None
        self._emit("aim", {"aim": mode, "zone": self._cfg["zone"], "art_zone": self._cfg["art_zone"]})
        if mode != "nom":
            self._art_ready()
        return mode

    def toggle_auto(self):
        self._auto = not self._auto
        if self._auto and self._collect:
            self._collect = False
        self._emit("modes", {"auto": self._auto, "collecting": self._collect})
        self._set_status("Scan automatique activé" if self._auto else "Scan automatique désactivé")
        if self._auto:
            threading.Thread(target=self._auto_loop, daemon=True).start()
        return self._auto

    def _auto_loop(self):
        while self._auto:
            self.scan(silent=True)
            time.sleep(self._cfg["auto_interval"])

    def _pick_region(self, purpose="name"):
        """Lance le sélecteur de zone ; renvoie 'x y w h', 'reset' ou ''."""
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if not getattr(sys, "frozen", False):
            return subprocess.run([sys.executable.replace("pythonw", "python"), os.path.join(carddb.APP_DIR, "zone_select.py"), purpose],
                                  capture_output=True, text=True, timeout=300, creationflags=flags).stdout.strip()
        # version .exe : le même exécutable fait le sélecteur, résultat écrit dans un fichier
        out = os.path.join(tempfile.gettempdir(), f"dmo_zone_{os.getpid()}.txt")
        try:
            subprocess.run([sys.executable, "--zone-select", purpose, out], timeout=300, creationflags=flags)
            with open(out, encoding="utf-8") as f:
                return f.read().strip()
        except Exception:
            return ""
        finally:
            if os.path.exists(out):
                os.remove(out)

    def clear_name_zone(self):
        self._cfg["zone"] = None
        self._save_cfg()
        self._emit("aim", {"aim": self._cfg["aim"], "zone": None, "art_zone": self._cfg["art_zone"]})
        return True

    def select_name_zone(self):
        """Zone du nom, utilisable dans tous les modes : avec une zone d'illustration, chaque nom lu
        apprend automatiquement l'illustration affichée par le jeu."""
        return self.select_zone("zone")

    def select_zone(self, key=None):
        """F9 : zone du nom en mode « nom », sinon zone d'illustration (et passage en mode illustration)."""
        key = key or ("zone" if self._cfg["aim"] == "nom" else "art_zone")
        try:
            out = self._pick_region("name" if key == "zone" else "art")
        except Exception as e:
            self._set_status(f"Sélection de zone impossible : {e}")
            return None
        if out == "reset":
            self._cfg[key] = None
            if key == "art_zone":
                self._cfg["aim"] = "souris"
            self._set_status("Zone supprimée." + (" Retour au mode souris." if key == "art_zone" else ""))
        elif out:
            self._cfg[key] = [int(v) for v in out.split()]
            if key == "art_zone":
                self._cfg["aim"] = "illustration"
            self._set_status("Zone enregistrée ✓")
        else:
            return self._cfg[key]
        self._save_cfg()
        self._emit("aim", {"aim": self._cfg["aim"], "zone": self._cfg["zone"], "art_zone": self._cfg["art_zone"]})
        if self._cfg[key]:
            self.scan()
        return self._cfg[key]

    # ------------------------------------------------------------------ collection
    def toggle_collection_scan(self):
        self._collect = not self._collect
        if self._collect:
            self._auto = False
            self._collect_found = []
            threading.Thread(target=self._collect_loop, daemon=True).start()
            self._set_status("Scan de collection : fais défiler ton inventaire dans le jeu…")
        else:
            self._set_status(f"Scan de collection terminé : {len(self._collect_found)} nouvelle(s) carte(s).")
        self._emit("modes", {"auto": self._auto, "collecting": self._collect})
        return self._collect

    def _collect_loop(self):
        seen = set()
        while self._collect:
            if self._scan_lock.acquire(blocking=False):
                try:
                    ranked = self._collection_frame()
                    new = []
                    for c in ranked:
                        if c["id"] in seen:
                            continue
                        seen.add(c["id"])
                        key = str(c["id"])
                        if key not in self._collection:
                            self._collection[key] = 1
                            self._collect_found.append(c["id"])
                            new.append(self._summary(c))
                    if new:
                        self._save_collection()
                        self._emit("collected", {"cards": new, "total": len(self._collection),
                                                 "session": len(self._collect_found)})
                except Exception as e:
                    self._set_status(f"Erreur de scan : {e}")
                finally:
                    self._scan_lock.release()
            time.sleep(0.8)

    def _collection_frame(self):
        """Une image de l'inventaire : cartes reconnues par leur nom écrit ET par leur illustration.
        Quand un nom est écrit près d'une illustration inconnue, l'illustration est apprise au passage."""
        import deckimage
        import screen_ocr
        img = screen_ocr.grab(None, self._capture_masks())
        lines = screen_ocr.ocr_image(img)
        named = []  # (carte, centre du texte)
        for l in lines:
            if len(l["text"].strip()) < 6:  # mots courts : trop de faux noms
                continue
            c, score = self._db.match(l["text"], 92)
            if c:
                named.append((c, (l["x"] + l["w"] / 2, l["y"] + l["h"] / 2)))
        for a, b in zip(lines, lines[1:]):  # noms sur deux lignes
            c, score = self._db.match(a["text"] + " " + b["text"], 90)
            if c and all(c["id"] != n[0]["id"] for n in named):
                named.append((c, (a["x"] + a["w"] / 2, (a["y"] + b["y"] + b["h"]) / 2)))
        found = {c["id"]: c for c, _ in named}
        idx = self._art_ready()
        if idx is not None:
            import ingame
            rects = deckimage.detect_cards(img)
            for (x, y, w, h) in rects:
                crop = img.crop((x, y, x + w, y + h))
                # carte officielle entière, ou carte façon DMO (illustration en haut + barre)
                cands = [r for r in (idx.best(crop, insets=(0.0, 0.04)),
                                     idx.best(ingame.art_of(crop), modes=("art",), insets=(0.0, 0.04))) if r]
                r = min(cands, key=lambda r: r[1]) if cands else None
                if r and r[1] < 24:
                    found.setdefault(r[0], self._db.get(r[0]))
                    continue
                # carte façon DMO : type + ATK/DEF lus dans sa barre
                hints = ingame.card_hints(crop)
                ident = ingame.identify(ingame.art_of(crop), hints, self._db, idx)
                if ident and ident["conf"] == "sûr" and self._consistent(self._db.get(ident["id"]), hints):
                    found.setdefault(ident["id"], self._db.get(ident["id"]))
                    if self._strong_stats(ident, hints):
                        self._auto_learn(ident["id"], ingame.art_of(crop))
                    continue
                # illustration inconnue : un nom lu juste au-dessus / en dessous / à côté ?
                cx, cy = x + w / 2, y + h / 2
                near = [(abs(p[0] - cx) / w + abs(p[1] - cy) / h, c) for c, p in named]
                near = [n for n in near if n[0] < 1.3]
                if near:
                    c = min(near, key=lambda n: n[0])[1]
                    if self._consistent(c, hints):
                        self._auto_learn(c["id"], ingame.art_of(crop))
        return [c for c in found.values() if c]

    def collection_get(self):
        items = []
        for cid, q in self._collection.items():
            c = self._db.get(int(cid))
            if c:
                items.append(self._summary(c, qty=q))
        order = {"monstre": 0, "magie": 1, "piège": 2, "extra": 3}
        items.sort(key=lambda s: (order[s["kind"]], s["name_fr"]))
        return items

    def collection_set(self, cid, qty):
        qty = max(0, min(99, int(qty)))
        if qty:
            self._collection[str(cid)] = qty
        else:
            self._collection.pop(str(cid), None)
        self._save_collection()
        return qty

    def collection_import(self, text):
        """Une carte par ligne, quantité optionnelle : « 3 Ash Blossom », « Pot of Greed x2 », ou fichier .ydk."""
        import re
        added, unknown = 0, []
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith(("#", "!")):
                continue
            if line.isdigit() and self._db.get(int(line)):
                key = line
                self._collection[key] = self._collection.get(key, 0) + 1
                added += 1
                continue
            qty = 1
            m = re.match(r"^(\d+)\s*[x×]?\s+(.+)$", line) or re.match(r"^(.+?)\s+[x×]\s*(\d+)$", line)
            if m:
                a, b = m.groups()
                qty, line = (int(a), b) if a.isdigit() else (int(b), a)
            c, _ = self._db.match(line, 82)
            if c:
                key = str(c["id"])
                self._collection[key] = max(self._collection.get(key, 0), min(qty, 99))
                added += 1
            else:
                unknown.append(raw.strip())
        self._save_collection()
        return {"added": added, "unknown": unknown[:20]}

    def collection_clear(self):
        self._collection = {}
        self._save_collection()

    # ------------------------------------------------------------------ deck
    def deck_get(self):
        deck = self._deck()
        items, counts = [], {"monstre": 0, "magie": 0, "piège": 0, "extra": 0}
        for cid, n in deck.items():
            c = self._db.get(int(cid))
            if c and n > 0:
                items.append(self._summary(c, n=n, owned=self._collection.get(cid, 0)))
                counts[kind(c)] += n
        order = {"monstre": 0, "magie": 1, "piège": 2, "extra": 3}
        items.sort(key=lambda s: (order[s["kind"]], s["name_fr"]))
        main = counts["monstre"] + counts["magie"] + counts["piège"]
        return {"name": self._decks["current"], "names": list(self._decks["decks"]),
                "items": items, "counts": {**counts, "main": main},
                "tips": self._deck_tips(items, counts, main), "suggestions": self._deck_suggestions(items)}

    def _deck_tips(self, items, counts, main):
        tips = []
        if not items:
            return [("info", "Deck vide : ajoute des cartes, ou génère un deck depuis ta collection.")]
        if main < 40:
            tips.append(("warn", f"Il manque {40 - main} carte(s) pour atteindre 40 (minimum)."))
        elif main > 60:
            tips.append(("warn", f"{main - 60} carte(s) de trop (maximum 60)."))
        elif main > 42:
            tips.append(("info", "Rester proche de 40 cartes rend tes pioches plus régulières."))
        if counts["extra"] > 15:
            tips.append(("warn", "L'Extra Deck est limité à 15 cartes."))
        if main and counts["monstre"] / main < 0.3:
            tips.append(("info", "Peu de monstres : risque de mains sans monstre à invoquer."))
        for s in items:
            if s["ban"] == "Interdite":
                tips.append(("warn", f"{s['name_fr']} est interdite en TCG."))
            if self._collection and s["owned"] < s["n"]:
                tips.append(("info", f"Tu ne possèdes que {s['owned']}× {s['name_fr']}."))
        if not tips:
            tips.append(("ok", "Deck valide ✓"))
        return tips

    def _deck_suggestions(self, items):
        owned = {s["id"] for s in items}
        archetypes = {}
        for s in items:
            a = self._db.get(s["id"])["archetype"]
            if a:
                archetypes[a] = archetypes.get(a, 0) + s["n"]
        groups = []
        for arch, n in sorted(archetypes.items(), key=lambda x: -x[1])[:2]:
            members, support = self._db.archetype_cards(arch)
            cards = [c for c in members + support if c["id"] not in owned and c["ban_tcg"] != "Banned"]
            cards.sort(key=lambda c: -c["views"])
            groups.append({"title": f"Archétype « {arch} »", "cards": [
                self._summary(c, owned=self._collection.get(str(c["id"]), 0)) for c in cards[:12]]})
        staples = sorted((self._db.get(i) for i in self._db.staples), key=lambda c: -c["views"])
        groups.append({"title": "Staples les plus jouées", "cards": [
            self._summary(c, owned=self._collection.get(str(c["id"]), 0))
            for c in staples if c["id"] not in owned and c["ban_tcg"] != "Banned"][:12]})
        return groups

    def deck_add(self, cid, delta=1):
        deck = self._deck()
        key = str(cid)
        n = max(0, min(3, deck.get(key, 0) + int(delta)))
        if n:
            deck[key] = n
        else:
            deck.pop(key, None)
        self._save_decks()
        return n

    def deck_clear(self):
        self._decks["decks"][self._decks["current"]] = {}
        self._save_decks()

    def deck_switch(self, name):
        self._decks["current"] = name
        self._decks["decks"].setdefault(name, {})
        self._save_decks()

    def deck_rename(self, name):
        name = name.strip()
        if not name or name in self._decks["decks"]:
            return False
        self._decks["decks"][name] = self._decks["decks"].pop(self._decks["current"])
        self._decks["current"] = name
        self._save_decks()
        return True

    def deck_delete(self):
        self._decks["decks"].pop(self._decks["current"], None)
        if not self._decks["decks"]:
            self._decks["decks"]["Mon deck"] = {}
        self._decks["current"] = next(iter(self._decks["decks"]))
        self._save_decks()

    def deck_export(self):
        main, extra = [], []
        for cid, n in self._deck().items():
            c = self._db.get(int(cid))
            if c:
                (extra if kind(c) == "extra" else main).extend([cid] * n)
        safe = "".join(ch for ch in self._decks["current"] if ch.isalnum() or ch in " -_") or "deck"
        path = os.path.join(ROOT, f"{safe}.ydk")
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(["#created by DMO Assistant", "#main", *main, "#extra", *extra, "!side"]) + "\n")
        return path

    # ------------------------------------------------------------------ import d'un deck (image / texte)
    def _art_index(self):
        if self._art is None:
            import artindex
            self._art = artindex.ArtIndex()
        return self._art

    def art_status(self):
        idx = self._art_index()
        done, total = idx.progress if idx.building else (len(idx), len(idx) + len(idx.missing(self._db)))
        return {"count": len(idx), "total": total, "done": done, "building": idx.building,
                "ready": len(idx) >= 0.97 * total}

    def art_build(self):
        idx = self._art_index()
        if idx.building:
            return
        idx.building = True

        def run():
            try:
                idx.build(self._db, on_progress=lambda d, t: self._emit("art_progress", {"done": d, "total": t}))
                self._emit("art_ready", self.art_status())
            except Exception as e:
                idx.building = False
                self._emit("art_error", str(e))
        threading.Thread(target=run, daemon=True).start()

    def _import_result(self, img=None, cards=None, mode="image"):
        import base64
        import io
        out = {"mode": mode, "image": None, "width": 0, "height": 0, "cards": []}
        if img is not None:
            img = img.convert("RGB")
            out["width"], out["height"] = img.size
            prev = img.copy()
            prev.thumbnail((1400, 1400))
            buf = io.BytesIO()
            prev.save(buf, "JPEG", quality=85)
            out["image"] = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
            if cards is None:
                import deckimage
                import screen_ocr
                res = deckimage.recognize(img, self._db, self._art_index(), screen_ocr.ocr_image)
                cards, out["mode"] = res["cards"], res["mode"]
        for r in cards or []:
            c = self._db.get(r["id"])
            if c:
                out["cards"].append(self._summary(
                    c, rect=r["rect"], conf=r["conf"],
                    alts=[self._summary(self._db.get(a)) for a in r["alts"] if self._db.get(a)]))
        return out

    def import_image(self, source):
        """source : 'clipboard', 'file' ou 'screen'."""
        from PIL import Image, ImageGrab
        img = None
        if source == "clipboard":
            data = ImageGrab.grabclipboard()
            if isinstance(data, list) and data:  # fichier copié dans l'explorateur
                data = Image.open(data[0])
            if not isinstance(data, Image.Image):
                return {"error": "Aucune image dans le presse-papiers. Copie une capture (Win+Maj+S) ou une image, puis réessaie."}
            img = data
        elif source == "file":
            paths = self._window.create_file_dialog(
                webview.OPEN_DIALOG, file_types=("Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "Tous les fichiers (*.*)"))
            if not paths:
                return None
            img = Image.open(paths[0])
        elif source == "screen":
            self._window.hide()
            try:
                time.sleep(0.25)
                out = self._pick_region("deck")
            finally:
                self._window.show()
                exclude_from_capture()
            if not out or out == "reset":
                return None
            import screen_ocr
            img = screen_ocr.grab([int(v) for v in out.split()])
        return self._import_result(img)

    def import_images_files(self):
        """Plusieurs captures d'un coup (sélection multiple) : une analyse par image."""
        from PIL import Image
        paths = self._window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=True,
            file_types=("Images (*.png;*.jpg;*.jpeg;*.webp;*.bmp)", "Tous les fichiers (*.*)"))
        if not paths:
            return []
        out = []
        for p in paths:
            try:
                res = self._import_result(Image.open(p))
                res["name"] = os.path.basename(p)
                out.append(res)
            except Exception as e:
                out.append({"error": f"{os.path.basename(p)} : {e}"})
        return out

    def perfect_deck(self, deck_ids, coll_ids, use_current_deck=False, use_saved_collection=False, assume3=False):
        """Fusionne le deck (captures et/ou deck actuel) avec la collection (captures et/ou enregistrée)."""
        import perfectdeck
        deck, coll = {}, {}
        for cid in deck_ids:
            deck[int(cid)] = min(3, deck.get(int(cid), 0) + 1)
        if use_current_deck:
            for cid, n in self._deck().items():
                deck[int(cid)] = max(deck.get(int(cid), 0), n)
        for cid in coll_ids:
            coll[int(cid)] = min(3, coll.get(int(cid), 0) + 1)
        if use_saved_collection:
            for cid, n in self._collection.items():
                coll[int(cid)] = max(coll.get(int(cid), 0), min(n, 3))
        if not deck and not coll:
            return {"error": "Ajoute au moins une image de ton deck ou de ta collection."}
        r = perfectdeck.optimize(self._db, deck, coll, assume3)
        S = lambda e, **kw: self._summary(self._db.get(e["id"]), **{**{k: v for k, v in e.items() if k != "id"}, **kw})
        for part in ("main", "extra", "added", "removed", "key_cards", "missing"):
            r[part] = [S(e) for e in r[part] if self._db.get(e["id"])]
        r["deck_in"] = sum(n for cid, n in deck.items())
        r["coll_in"] = len(coll)
        return r

    def import_image_data(self, data_url):
        """Image collée (Ctrl+V) ou glissée dans la fenêtre, reçue en data URL."""
        import base64
        import io
        from PIL import Image
        raw = base64.b64decode(data_url.split(",", 1)[1])
        return self._import_result(Image.open(io.BytesIO(raw)))

    def import_text(self, text):
        import deckimage
        unknown = []
        cards = deckimage.parse_text_list(text.splitlines(), self._db, unknown)
        res = self._import_result(None, cards, mode="texte")
        res["unknown"] = unknown
        return res

    def create_deck(self, name, ids):
        deck = {}
        for cid in ids:
            key = str(int(cid))
            deck[key] = min(3, deck.get(key, 0) + 1)
        base, i = (name or "").strip() or "Deck importé", 2
        name = base
        while name in self._decks["decks"]:
            name, i = f"{base} ({i})", i + 1
        self._decks["decks"][name] = deck
        self._decks["current"] = name
        self._save_decks()
        return name

    def collection_merge(self, counts):
        """Ajoute des cartes lues sur des captures d'inventaire : quantité = max(déjà enregistrée, lue)."""
        added = updated = 0
        for cid, n in counts.items():
            key = str(int(cid))
            if not self._db.get(int(cid)) or int(n) <= 0:
                continue
            old = self._collection.get(key, 0)
            if old == 0:
                added += 1
            elif int(n) > old:
                updated += 1
            self._collection[key] = max(old, min(int(n), 99))
        self._save_collection()
        return {"added": added, "updated": updated, "total": len(self._collection)}

    def collection_add_ids(self, ids):
        for cid in ids:
            key = str(int(cid))
            self._collection[key] = self._collection.get(key, 0) + 1
        self._save_collection()
        return len(self._collection)

    # ------------------------------------------------------------------ générateur
    def archetype_options(self, assume3=False):
        return deckbuilder.archetype_options(self._db, self._collection, assume3)

    def build_deck(self, archetype=None, assume3=False):
        res = deckbuilder.build(self._db, self._collection, archetype or None, assume3)
        for part in ("main", "extra", "missing"):
            res[part] = [self._summary(self._db.get(e["id"]), **{k: v for k, v in e.items() if k != "id"})
                         for e in res[part]]
        return res

    def apply_build(self, name, main, extra):
        base, i = name.strip() or "Deck généré", 2
        name = base
        while name in self._decks["decks"]:
            name, i = f"{base} ({i})", i + 1
        self._decks["decks"][name] = {str(e["id"]): e["n"] for e in main + extra}
        self._decks["current"] = name
        self._save_decks()
        return name


api = Api()


def exclude_from_capture():
    """Rend la fenêtre principale invisible aux captures d'écran (OCR, OBS, TikTok…)."""
    try:
        set_capture_visible(TITLE, False)
    except Exception:
        pass


def main(on_start=None):
    x, y = api._cfg["window"]
    w, h = SIZES["wide"]  # même taille que l'écran d'accueil : l'animation d'ouverture s'affiche en grand dès le départ
    window = webview.create_window(TITLE, os.path.join(UI_DIR, "index.html"), js_api=api,
                                   width=w, height=h, x=x, y=y, frameless=True, on_top=True,
                                   easy_drag=False, background_color="#05060c", min_size=(420, 560))
    api._window = window
    window.events.shown += lambda: threading.Timer(0.5, exclude_from_capture).start()
    # overlay transparent posé sur le jeu, traversé par les clics. Il doit être créé visible
    # (hors écran) : pywebview n'active la transparence que dans ce cas. On le cache une fois chargé.
    hud = webview.create_window(HUD_TITLE, os.path.join(UI_DIR, "hud.html"), js_api=api,
                                width=api._cfg["hud"]["width"], height=220, x=-6000, y=-6000,
                                frameless=True, transparent=True, on_top=True, focus=False,
                                easy_drag=False, shadow=False)
    api._hud = hud

    def hud_loaded():
        make_form_transparent(hud)
        if not api._hud_visible:
            hud.hide()
        api._hud_apply_settings()
    hud.events.loaded += lambda: threading.Timer(0.3, hud_loaded).start()
    threading.Thread(target=api._hud_watch, daemon=True).start()
    webview.start(on_start, http_server=True, debug="--debug" in sys.argv)


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "--zone-select":  # sélecteur de zone de la version .exe
        out, sys.argv = sys.argv[3], [sys.argv[0], sys.argv[2]]
        with open(out, "w", encoding="utf-8") as sys.stdout:
            import zone_select  # noqa: F401
    else:
        main()
