"""Index d'empreintes visuelles des illustrations de cartes, pour reconnaître des cartes sur une image.

Pour chaque illustration (artworks alternatifs compris), on calcule à partir de la vignette YGOPRODeck :
- un pHash 64 bits et un dHash 64 bits de la zone centrale de l'illustration,
- une petite signature couleur 4×4.
L'index est construit une seule fois (téléchargement des vignettes, ~150 Mo non conservés) et
peut être utilisé partiellement pendant sa construction (cartes les plus populaires d'abord).
"""
import io
import json
import os
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import numpy as np
from PIL import Image

import carddb

INDEX_PATH = os.path.join(carddb.DATA, "artindex.npz")
# illustrations apprises par l'utilisateur (cartes du jeu non reconnues) : données personnelles, hors de data/
LEARNED_PATH = os.path.join(carddb.ROOT, "learned_arts.json")
LEARNED_BONUS = 0  # pas de priorité : une illustration apprise doit ressembler autant qu'une officielle
IMG_CACHE = os.path.join(carddb.APP_DIR, "ui", "cache", "img")
# zone de l'illustration sûre pour tous les cadres (normal, pendule, lien…), en fraction de la carte
ART_BOX = (0.20, 0.24, 0.80, 0.58)
# la même zone exprimée dans une illustration seule (sans cadre de carte), comme dans DMO.
# Sur une carte, l'illustration occupe x 0.119→0.881 et y 0.181→0.704.
_AX0, _AY0, _AW, _AH = 0.119, 0.181, 0.762, 0.523
ART_BOX_IN_ART = ((ART_BOX[0] - _AX0) / _AW, (ART_BOX[1] - _AY0) / _AH,
                  (ART_BOX[2] - _AX0) / _AW, (ART_BOX[3] - _AY0) / _AH)
_DCT = None


def _dct_matrix(n=32):
    global _DCT
    if _DCT is None:
        k = np.arange(n)
        m = np.cos(np.pi * (2 * k[None, :] + 1) * k[:, None] / (2 * n))
        m[0] *= 1 / np.sqrt(2)
        _DCT = m * np.sqrt(2 / n)
    return _DCT


def _bits(arr):
    v = 0
    for b in arr.flatten():
        v = (v << 1) | int(b)
    return v


def art_crop(card_img, box=ART_BOX):
    w, h = card_img.size
    x0, y0, x1, y1 = box
    return card_img.crop((int(x0 * w), int(y0 * h), int(x1 * w), int(y1 * h)))


def signature(card_img, box=ART_BOX):
    """(phash, dhash, couleurs[48]) de l'illustration. box = ART_BOX pour une carte entière,
    ART_BOX_IN_ART pour une illustration seule."""
    art = art_crop(card_img.convert("RGB"), box)
    g = np.asarray(art.convert("L").resize((32, 32), Image.LANCZOS), dtype=np.float64)
    d = _dct_matrix()
    coef = d @ g @ d.T
    low = coef[:8, :8].flatten()[1:]
    ph = _bits(np.append(low > np.median(low), coef[0, 0] > 0)[:64])
    s = np.asarray(art.convert("L").resize((9, 8), Image.LANCZOS), dtype=np.int16)
    dh = _bits(s[:, 1:] > s[:, :-1])
    col = np.asarray(art.resize((4, 4), Image.BOX), dtype=np.uint8).flatten()
    return ph, dh, col


def _popcount64(x):
    x = x - ((x >> np.uint64(1)) & np.uint64(0x5555555555555555))
    x = (x & np.uint64(0x3333333333333333)) + ((x >> np.uint64(2)) & np.uint64(0x3333333333333333))
    x = (x + (x >> np.uint64(4))) & np.uint64(0x0F0F0F0F0F0F0F0F)
    return ((x * np.uint64(0x0101010101010101)) >> np.uint64(56)).astype(np.int32)


class ArtIndex:
    def __init__(self):
        self.lock = threading.Lock()
        self.card_ids = np.zeros(0, np.int64)
        self.img_ids = np.zeros(0, np.int64)
        self.ph = np.zeros(0, np.uint64)
        self.dh = np.zeros(0, np.uint64)
        self.col = np.zeros((0, 48), np.uint8)
        self.building = False
        self.progress = (0, 0)
        if os.path.exists(INDEX_PATH):
            z = np.load(INDEX_PATH)
            self.card_ids, self.img_ids = z["card_ids"], z["img_ids"]
            self.ph, self.dh, self.col = z["ph"], z["dh"], z["col"]
        self.learned = []  # [{"id", "ph", "dh", "col"}]
        if os.path.exists(LEARNED_PATH):
            with open(LEARNED_PATH, encoding="utf-8") as f:
                self.learned = json.load(f)

    def learn(self, card_id, img, src="manuel"):
        """Mémorise l'illustration capturée dans le jeu pour cette carte (plusieurs recadrages)."""
        w, h = img.size
        for inset in (0.0, 0.04, 0.08):
            dx, dy = int(w * inset), int(h * inset)
            crop = img.crop((dx, dy, w - dx, h - dy)) if inset else img
            ph, dh, col = signature(crop, ART_BOX_IN_ART)
            self.learned.append({"id": int(card_id), "ph": str(ph), "dh": str(dh), "col": col.tolist(), "src": src})
        with open(LEARNED_PATH + ".tmp", "w", encoding="utf-8") as f:
            json.dump(self.learned, f)
        os.replace(LEARNED_PATH + ".tmp", LEARNED_PATH)

    def reinforce(self, card_id, img, max_per_card=36):
        """Carte reconnue avec certitude sous un angle un peu nouveau : on mémorise aussi cette vue,
        pour la reconnaître ensuite sous des angles encore plus éloignés (nombre limité par carte)."""
        if sum(1 for e in self.learned if e["id"] == int(card_id)) >= max_per_card:
            return False
        self.learn(card_id, img, src="auto")
        return True

    def forget(self, card_id=None, src=None):
        """Oublie les illustrations apprises d'une carte, ou toutes celles d'une source (« auto »), ou tout."""
        self.learned = [e for e in self.learned
                        if not ((card_id is None or e["id"] == int(card_id)) and (src is None or e.get("src", "auto") == src))]
        with open(LEARNED_PATH, "w", encoding="utf-8") as f:
            json.dump(self.learned, f)

    def learned_summary(self):
        """{id: {"n": nombre de vues, "auto": vues apprises automatiquement}}"""
        out = {}
        for e in self.learned:
            s = out.setdefault(e["id"], {"n": 0, "auto": 0})
            s["n"] += 1
            s["auto"] += e.get("src", "auto") == "auto"
        return out

    def __len__(self):
        return len(self.img_ids)

    def _save(self):
        with self.lock:
            np.savez(INDEX_PATH + ".tmp.npz", card_ids=self.card_ids, img_ids=self.img_ids,
                     ph=self.ph, dh=self.dh, col=self.col)
        os.replace(INDEX_PATH + ".tmp.npz", INDEX_PATH)

    @staticmethod
    def all_images(db):
        """[(card_id, img_id, url)] triés par popularité."""
        out = []
        for c in sorted(db.cards.values(), key=lambda c: -c["views"]):
            for img_id, url in c["images"]:
                out.append((c["id"], img_id, url))
        return out

    def missing(self, db):
        done = set(self.img_ids.tolist())
        return [t for t in self.all_images(db) if t[1] not in done]

    def build(self, db, on_progress=None, workers=8):
        """Télécharge et indexe les illustrations manquantes (reprend là où il s'est arrêté)."""
        todo = self.missing(db)
        total = len(self.img_ids) + len(todo)
        self.building = True
        self.progress = (len(self.img_ids), total)
        buf = []

        def work(item):
            cid, img_id, url = item
            cached = os.path.join(IMG_CACHE, f"{img_id}.jpg")
            for attempt in range(3):
                try:
                    if os.path.exists(cached):
                        with open(cached, "rb") as f:
                            data = f.read()
                    else:
                        req = urllib.request.Request(url, headers={"User-Agent": "DMO-Assistant/2.0"})
                        with urllib.request.urlopen(req, timeout=20) as r:
                            data = r.read()
                    return (cid, img_id, *signature(Image.open(io.BytesIO(data))))
                except Exception:
                    time.sleep(1 + attempt * 2)
            return None

        def flush():
            if not buf:
                return
            with self.lock:
                self.card_ids = np.concatenate([self.card_ids, np.array([b[0] for b in buf], np.int64)])
                self.img_ids = np.concatenate([self.img_ids, np.array([b[1] for b in buf], np.int64)])
                self.ph = np.concatenate([self.ph, np.array([b[2] for b in buf], np.uint64)])
                self.dh = np.concatenate([self.dh, np.array([b[3] for b in buf], np.uint64)])
                self.col = np.concatenate([self.col, np.array([b[4] for b in buf], np.uint8).reshape(-1, 48)])
            buf.clear()
            self._save()

        try:
            with ThreadPoolExecutor(workers) as pool:
                for i, res in enumerate(pool.map(work, todo), 1):
                    if res:
                        buf.append(res)
                    if len(buf) >= 300:
                        flush()
                    if on_progress and (i % 25 == 0 or i == len(todo)):
                        self.progress = (len(self.img_ids) + len(buf), total)
                        on_progress(*self.progress)
            flush()
        finally:
            self.building = False
        return len(self.img_ids)

    def best(self, img, modes=("art", "card"), insets=(0.0, 0.03, 0.06)):
        """Image dont le cadrage est approximatif (capture du jeu) : on essaie illustration seule /
        carte entière et quelques recadrages. Renvoie (card_id, distance, mode) ou None."""
        best = None
        w, h = img.size
        for inset in insets:
            dx, dy = int(w * inset), int(h * inset)
            crop = img.crop((dx, dy, w - dx, h - dy)) if inset else img
            for mode in modes:
                m = self.match(crop, k=1, box=ART_BOX_IN_ART if mode == "art" else ART_BOX)
                if m and (best is None or m[0][1] < best[1]):
                    best = (m[0][0], m[0][1], mode)
        return best

    def distances(self, img, ids, box=ART_BOX_IN_ART):
        """Distance d'illustration de l'image à chacune des cartes `ids` (pour classer des candidats)."""
        ids = set(int(i) for i in ids)
        out = {}
        for cid, d in self.match(img, k=len(self.card_ids) + len(self.learned), box=box):
            if cid in ids and cid not in out:
                out[cid] = d
        return out

    def match(self, card_img, k=5, box=ART_BOX):
        """Meilleures correspondances : [(card_id, distance)]."""
        if not len(self) and not self.learned:
            return []
        ph, dh, col = signature(card_img, box)
        with self.lock:
            ph_all, dh_all, col_all, cids = self.ph, self.dh, self.col, self.card_ids
        bonus = np.zeros(len(cids))
        if self.learned:
            ph_all = np.concatenate([ph_all, np.array([int(e["ph"]) for e in self.learned], np.uint64)])
            dh_all = np.concatenate([dh_all, np.array([int(e["dh"]) for e in self.learned], np.uint64)])
            col_all = np.concatenate([col_all, np.array([e["col"] for e in self.learned], np.uint8).reshape(-1, 48)])
            cids = np.concatenate([cids, np.array([e["id"] for e in self.learned], np.int64)])
            bonus = np.concatenate([bonus, np.full(len(self.learned), LEARNED_BONUS)])
        dp = _popcount64(ph_all ^ np.uint64(ph))
        dd = _popcount64(dh_all ^ np.uint64(dh))
        dc = np.abs(col_all.astype(np.int16) - col.astype(np.int16)).mean(axis=1) / 255 * 64
        dist = np.maximum(0, dp + dd + dc - bonus)
        order = np.argsort(dist)
        out, seen = [], set()
        for i in order[: k * 4]:
            cid = int(cids[i])
            if cid not in seen:
                seen.add(cid)
                out.append((cid, float(dist[i])))
            if len(out) >= k:
                break
        return out
