"""Index d'empreintes visuelles des illustrations de cartes, pour reconnaître des cartes sur une image.

Pour chaque illustration (artworks alternatifs compris), on calcule à partir de la vignette YGOPRODeck :
- un pHash 64 bits et un dHash 64 bits de la zone centrale de l'illustration,
- une petite signature couleur 4×4,
- une miniature 16×16 en niveaux de gris, qui sert à départager les meilleurs candidats par corrélation
  (résiste au flou, à la compression, aux écarts de luminosité et de cadrage).
L'index est construit une seule fois (téléchargement des vignettes, ~150 Mo non conservés) et
peut être utilisé partiellement pendant sa construction (cartes les plus populaires d'abord).
"""
import io
import json
import os
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import cv2
import numpy as np
from PIL import Image

import carddb

INDEX_PATH = os.path.join(carddb.DATA, "artindex.npz")
# index complet (avec miniatures) livré avec l'appli et ses mises à jour : préféré s'il est plus complet
SHIPPED_PATH = os.path.join(carddb.APP_DIR, "artindex_complet.npz")
THUMB = 16
RERANK = 600         # nombre de candidats départagés par corrélation des miniatures
# corrélation des miniatures : bonus si elle dépasse THUMB_T (illustration vraiment semblable), pénalité sinon.
# Un décor quelconque n'atteint pas une forte corrélation : sa distance reste celle des empreintes (pas de faux positif).
THUMB_T = 0.75
THUMB_K = 90
# illustrations apprises par l'utilisateur (cartes du jeu non reconnues) : données personnelles, hors de data/
LEARNED_PATH = os.path.join(carddb.ROOT, "learned_arts.json")
LEARNED_BONUS = 0  # pas de priorité : une illustration apprise doit ressembler autant qu'une officielle
IMG_CACHE = os.path.join(carddb.APP_DIR, "ui", "cache", "img")
# zone de l'illustration sûre pour tous les cadres (normal, pendule, lien…), en fraction de la carte
ART_BOX = (0.20, 0.24, 0.80, 0.58)
# la même zone exprimée dans une illustration seule (sans cadre de carte), comme dans DMO.
# Sur une carte, l'illustration occupe x 0.119→0.881 et y 0.181→0.704.
_AX0, _AY0, _AW, _AH = 0.119, 0.181, 0.762, 0.523
ART_BOX_IN_ART = ((ART_BOX[0] - _AX0) / _AW, (ART_BOX[1] - _AY0) / _AH,
                  (ART_BOX[2] - _AX0) / _AW, (ART_BOX[3] - _AY0) / _AH)
_DCT = None


def _dct_matrix(n=32):
    global _DCT
    if _DCT is None:
        k = np.arange(n)
        m = np.cos(np.pi * (2 * k[None, :] + 1) * k[:, None] / (2 * n))
        m[0] *= 1 / np.sqrt(2)
        _DCT = m * np.sqrt(2 / n)
    return _DCT


def _bits(arr):
    v = 0
    for b in arr.flatten():
        v = (v << 1) | int(b)
    return v


def art_crop(card_img, box=ART_BOX):
    w, h = card_img.size
    x0, y0, x1, y1 = box
    return card_img.crop((int(x0 * w), int(y0 * h), int(x1 * w), int(y1 * h)))


def signature(card_img, box=ART_BOX):
    """(phash, dhash, couleurs[48]) de l'illustration. box = ART_BOX pour une carte entière,
    ART_BOX_IN_ART pour une illustration seule."""
    art = art_crop(card_img.convert("RGB"), box)
    g = np.asarray(art.convert("L").resize((32, 32), Image.LANCZOS), dtype=np.float64)
    d = _dct_matrix()
    coef = d @ g @ d.T
    low = coef[:8, :8].flatten()[1:]
    ph = _bits(np.append(low > np.median(low), coef[0, 0] > 0)[:64])
    s = np.asarray(art.convert("L").resize((9, 8), Image.LANCZOS), dtype=np.int16)
    dh = _bits(s[:, 1:] > s[:, :-1])
    col = np.asarray(art.resize((4, 4), Image.BOX), dtype=np.uint8).flatten()
    return ph, dh, col


def thumb(card_img, box=ART_BOX):
    """Miniature 16×16 en niveaux de gris de l'illustration (uint8)."""
    art = art_crop(card_img.convert("RGB"), box)
    return np.asarray(art.convert("L").resize((THUMB, THUMB), Image.BOX), dtype=np.uint8).flatten()


def _unit(t):
    """Miniatures centrées-réduites (lignes de norme 1) : la corrélation devient un produit scalaire."""
    t = np.asarray(t, np.float32).reshape(-1, THUMB * THUMB)
    t = t - t.mean(axis=1, keepdims=True)
    return t / (np.linalg.norm(t, axis=1, keepdims=True) + 1e-6)


def _query_thumbs(card_img, box):
    """Miniatures de la requête sous plusieurs petits décalages et un zoom (cadrage approximatif).
    Un seul recadrage agrandi de 1/16 de chaque côté, réduit en 18×18 : les 9 fenêtres 16×16 décalées d'un
    pixel s'obtiennent par découpage (rapide)."""
    x0, y0, x1, y1 = box
    w, h = x1 - x0, y1 - y0
    mx, my = w / THUMB, h / THUMB
    big = (x0 - mx, y0 - my, x1 + mx, y1 + my)
    img = card_img.convert("RGB")
    out = []
    if big[0] >= 0 and big[1] >= 0 and big[2] <= 1 and big[3] <= 1:
        g = np.asarray(art_crop(img, big).convert("L").resize((THUMB + 2, THUMB + 2), Image.BOX), dtype=np.uint8)
        out = [g[i:i + THUMB, j:j + THUMB].flatten() for i in range(3) for j in range(3)]
    else:
        out = [thumb(img, box)]
    z = 0.06
    out.append(thumb(img, (x0 + z / 2 * w, y0 + z / 2 * h, x1 - z / 2 * w, y1 - z / 2 * h)))
    return _unit(out)


def _popcount64(x):
    x = x - ((x >> np.uint64(1)) & np.uint64(0x5555555555555555))
    x = (x & np.uint64(0x3333333333333333)) + ((x >> np.uint64(2)) & np.uint64(0x3333333333333333))
    x = (x + (x >> np.uint64(4))) & np.uint64(0x0F0F0F0F0F0F0F0F)
    return ((x * np.uint64(0x0101010101010101)) >> np.uint64(56)).astype(np.int32)


class ArtIndex:
    def __init__(self):
        self.lock = threading.Lock()
        self.card_ids = np.zeros(0, np.int64)
        self.img_ids = np.zeros(0, np.int64)
        self.ph = np.zeros(0, np.uint64)
        self.dh = np.zeros(0, np.uint64)
        self.col = np.zeros((0, 48), np.uint8)
        self.th = np.zeros((0, THUMB * THUMB), np.uint8)  # ligne de zéros = miniature inconnue
        self.building = False
        self.progress = (0, 0)
        best = None
        for path in (SHIPPED_PATH, INDEX_PATH):
            if os.path.exists(path):
                try:
                    z = np.load(path)
                    if best is None or len(z["img_ids"]) > len(best["img_ids"]):
                        best = {k: z[k] for k in z.files}
                except Exception:
                    pass
        if best is not None:
            self.card_ids, self.img_ids = best["card_ids"], best["img_ids"]
            self.ph, self.dh, self.col = best["ph"], best["dh"], best["col"]
            self.th = best["th"] if "th" in best else np.zeros((len(self.img_ids), THUMB * THUMB), np.uint8)
        # illustrations volontairement absentes (doublons d'une carte officielle) : à ne pas reconstruire
        self.skip = set(best["skip"].tolist()) if best is not None and "skip" in best else set()
        self._cache = None  # tableaux prêts au calcul (voir _arrays)
        self.learned = []  # [{"id", "ph", "dh", "col"}]
        if os.path.exists(LEARNED_PATH):
            with open(LEARNED_PATH, encoding="utf-8") as f:
                self.learned = json.load(f)

    def learn(self, card_id, img, src="manuel"):
        """Mémorise l'illustration capturée dans le jeu pour cette carte (plusieurs recadrages)."""
        w, h = img.size
        for inset in (0.0, 0.04, 0.08):
            dx, dy = int(w * inset), int(h * inset)
            crop = img.crop((dx, dy, w - dx, h - dy)) if inset else img
            ph, dh, col = signature(crop, ART_BOX_IN_ART)
            self.learned.append({"id": int(card_id), "ph": str(ph), "dh": str(dh), "col": col.tolist(), "src": src,
                                 "th": thumb(crop, ART_BOX_IN_ART).tolist()})
        with open(LEARNED_PATH + ".tmp", "w", encoding="utf-8") as f:
            json.dump(self.learned, f)
        os.replace(LEARNED_PATH + ".tmp", LEARNED_PATH)

    def reinforce(self, card_id, img, max_per_card=36):
        """Carte reconnue avec certitude sous un angle un peu nouveau : on mémorise aussi cette vue,
        pour la reconnaître ensuite sous des angles encore plus éloignés (nombre limité par carte)."""
        if sum(1 for e in self.learned if e["id"] == int(card_id)) >= max_per_card:
            return False
        self.learn(card_id, img, src="auto")
        return True

    def forget(self, card_id=None, src=None):
        """Oublie les illustrations apprises d'une carte, ou toutes celles d'une source (« auto »), ou tout."""
        self.learned = [e for e in self.learned
                        if not ((card_id is None or e["id"] == int(card_id)) and (src is None or e.get("src", "auto") == src))]
        with open(LEARNED_PATH, "w", encoding="utf-8") as f:
            json.dump(self.learned, f)

    def learned_summary(self):
        """{id: {"n": nombre de vues, "auto": vues apprises automatiquement}}"""
        out = {}
        for e in self.learned:
            s = out.setdefault(e["id"], {"n": 0, "auto": 0})
            s["n"] += 1
            s["auto"] += e.get("src", "auto") == "auto"
        return out

    def __len__(self):
        return len(self.img_ids)

    def _save(self):
        with self.lock:
            np.savez(INDEX_PATH + ".tmp.npz", card_ids=self.card_ids, img_ids=self.img_ids,
                     ph=self.ph, dh=self.dh, col=self.col, th=self.th, skip=np.array(sorted(self.skip), np.int64))
        os.replace(INDEX_PATH + ".tmp.npz", INDEX_PATH)

    @staticmethod
    def all_images(db):
        """[(card_id, img_id, url)] triés par popularité."""
        out = []
        for c in sorted(db.cards.values(), key=lambda c: -c["views"]):
            for img_id, url in c["images"]:
                out.append((c["id"], img_id, url))
        return out

    def missing(self, db):
        done = set(self.img_ids.tolist()) | self.skip
        return [t for t in self.all_images(db) if t[1] not in done]

    def build(self, db, on_progress=None, workers=8):
        """Télécharge et indexe les illustrations manquantes (reprend là où il s'est arrêté)."""
        todo = self.missing(db)
        total = len(self.img_ids) + len(todo)
        self.building = True
        self.progress = (len(self.img_ids), total)
        buf = []

        def work(item):
            cid, img_id, url = item
            cached = os.path.join(IMG_CACHE, f"{img_id}.jpg")
            for attempt in range(3):
                try:
                    if os.path.exists(cached):
                        with open(cached, "rb") as f:
                            data = f.read()
                    else:
                        req = urllib.request.Request(url, headers={"User-Agent": "DMO-Assistant/2.0"})
                        with urllib.request.urlopen(req, timeout=20) as r:
                            data = r.read()
                    im = Image.open(io.BytesIO(data))
                    return (cid, img_id, *signature(im), thumb(im))
                except Exception:
                    time.sleep(1 + attempt * 2)
            return None

        def flush():
            if not buf:
                return
            with self.lock:
                self.card_ids = np.concatenate([self.card_ids, np.array([b[0] for b in buf], np.int64)])
                self.img_ids = np.concatenate([self.img_ids, np.array([b[1] for b in buf], np.int64)])
                self.ph = np.concatenate([self.ph, np.array([b[2] for b in buf], np.uint64)])
                self.dh = np.concatenate([self.dh, np.array([b[3] for b in buf], np.uint64)])
                self.col = np.concatenate([self.col, np.array([b[4] for b in buf], np.uint8).reshape(-1, 48)])
                self.th = np.concatenate([self.th, np.array([b[5] for b in buf], np.uint8).reshape(-1, THUMB * THUMB)])
            buf.clear()
            self._save()

        try:
            with ThreadPoolExecutor(workers) as pool:
                for i, res in enumerate(pool.map(work, todo), 1):
                    if res:
                        buf.append(res)
                    if len(buf) >= 300:
                        flush()
                    if on_progress and (i % 25 == 0 or i == len(todo)):
                        self.progress = (len(self.img_ids) + len(buf), total)
                        on_progress(*self.progress)
            flush()
        finally:
            self.building = False
        return len(self.img_ids)

    def best(self, img, modes=("art", "card"), insets=(0.0, 0.03, 0.06)):
        """Image dont le cadrage est approximatif (capture du jeu) : on essaie illustration seule /
        carte entière et quelques recadrages. Renvoie (card_id, distance, mode) ou None."""
        best = None
        w, h = img.size
        for inset in insets:
            dx, dy = int(w * inset), int(h * inset)
            crop = img.crop((dx, dy, w - dx, h - dy)) if inset else img
            for mode in modes:
                m = self.match(crop, k=1, box=ART_BOX_IN_ART if mode == "art" else ART_BOX)
                if m and (best is None or m[0][1] < best[1]):
                    best = (m[0][0], m[0][1], mode)
        return best

    def distances(self, img, ids, box=ART_BOX_IN_ART):
        """Distance d'illustration de l'image à chacune des cartes `ids` (pour classer des candidats)."""
        ids = set(int(i) for i in ids)
        out = {}
        for cid, d in self.match(img, k=len(self.card_ids) + len(self.learned), box=box):
            if cid in ids and cid not in out:
                out[cid] = d
        return out

    def _arrays(self):
        """Index + illustrations apprises, sous une forme prête au calcul (mise en cache)."""
        key = (len(self.img_ids), len(self.learned), id(self.learned),
               self.learned[-1].get("ph") if self.learned else None)
        c = self._cache
        if c is not None and c["key"] == key:
            return c
        with self.lock:
            ph, dh, col, cids, th = self.ph, self.dh, self.col, self.card_ids, self.th
        L = self.learned
        c = {"key": key,
             "ph": np.concatenate([ph, np.array([int(e["ph"]) for e in L], np.uint64)]),
             "dh": np.concatenate([dh, np.array([int(e["dh"]) for e in L], np.uint64)]),
             "col": np.ascontiguousarray(np.concatenate([col, np.array([e["col"] for e in L], np.uint8).reshape(-1, 48)])),
             "cids": np.concatenate([cids, np.array([e["id"] for e in L], np.int64)]),
             "bonus": np.concatenate([np.zeros(len(cids)), np.full(len(L), float(LEARNED_BONUS))]),
             "thok": np.concatenate([th.any(axis=1) if len(th) else np.zeros(0, bool),
                                     np.array([bool(e.get("th")) for e in L], bool)])}
        lt = np.array([e.get("th") or [0] * (THUMB * THUMB) for e in L], np.uint8).reshape(-1, THUMB * THUMB)
        c["thu"] = _unit(np.concatenate([th, lt])) if len(th) + len(lt) else np.zeros((0, THUMB * THUMB), np.float32)
        self._cache = c
        return c

    def match(self, card_img, k=5, box=ART_BOX):
        """Meilleures correspondances : [(card_id, distance)]."""
        if not len(self) and not self.learned:
            return []
        ph, dh, col = signature(card_img, box)
        a = self._arrays()
        cids, n = a["cids"], len(a["cids"])
        dp = _popcount64(a["ph"] ^ np.uint64(ph))
        dd = _popcount64(a["dh"] ^ np.uint64(dh))
        if a.get("qcol") is None or len(a["qcol"]) != n:
            a["qcol"] = np.empty((n, 48), np.uint8)
        a["qcol"][:] = col  # écart de couleur L1, vectorisé par OpenCV (4× plus rapide que numpy)
        dc = cv2.reduce(cv2.absdiff(a["col"], a["qcol"]), 1, cv2.REDUCE_SUM, dtype=cv2.CV_32S).ravel() * (64 / 255 / 48)
        dist = np.maximum(0, dp + dd + dc - a["bonus"])
        # seuls les meilleurs comptent : tri partiel (bien plus rapide que de trier les 18 000 entrées)
        m = min(n, RERANK + k * 4)
        top = np.argpartition(dist, m - 1)[:m] if m < n else np.arange(n)
        top = top[np.argsort(dist[top])]
        # départage des meilleurs candidats par corrélation des miniatures (si elles sont connues)
        cand = top[:RERANK]
        cand = cand[a["thok"][cand]]
        if len(cand):
            ncc = (a["thu"][cand] @ _query_thumbs(card_img, box).T).max(axis=1)
            dist = dist.astype(np.float64)
            dist[cand] = np.maximum(0, dist[cand] - THUMB_K * (ncc - THUMB_T))
            top = top[np.argsort(dist[top])]
        order = top
        out, seen = [], set()
        for i in order[: k * 4]:
            cid = int(cids[i])
            if cid not in seen:
                seen.add(cid)
                out.append((cid, float(dist[i])))
            if len(out) >= k:
                break
        return out
