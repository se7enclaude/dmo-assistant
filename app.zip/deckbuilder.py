"""Construction automatique d'un deck à partir des cartes possédées.

Heuristique : on choisit l'archétype le mieux couvert par la collection (pondéré par la popularité
des cartes sur YGOPRODeck, qui reflète bien ce qui se joue en compétition), puis on complète
avec les staples possédées et les meilleures cartes génériques, en visant 40 cartes.
"""
import math

from carddb import kind

BAN_LIMIT = {"Banned": 0, "Limited": 1, "Semi-Limited": 2}
TARGET_MAIN = 40
MAX_EXTRA = 15


def value(card):
    return math.log10(card["views"] + 10)


def copies_allowed(card, owned_qty, assume3):
    n = 3 if assume3 else owned_qty
    return max(0, min(n, 3, BAN_LIMIT.get(card["ban_tcg"], 3)))


def _in_archetype(card, arch):
    return card["archetype"] == arch or f'"{arch}"'.lower() in card["desc_en"].lower()


def archetype_options(db, owned, assume3=False, limit=6):
    """Archétypes présents dans la collection, classés par potentiel."""
    cards = [(db.get(int(cid)), q) for cid, q in owned.items()]
    cards = [(c, copies_allowed(c, q, assume3)) for c, q in cards if c]
    names = {c["archetype"] for c, _ in cards if c["archetype"]}
    out = []
    for arch in names:
        mine = [(c, n) for c, n in cards if n and _in_archetype(c, arch)]
        copies = sum(n for _, n in mine)
        if len(mine) < 3:
            continue
        members, support = db.archetype_cards(arch)
        out.append({
            "name": arch,
            "owned": len(mine),
            "copies": copies,
            "total": len(members) + len(support),
            "score": sum(n * value(c) for c, n in mine),
        })
    return sorted(out, key=lambda a: -a["score"])[:limit]


def build(db, owned, archetype=None, assume3=False, prefer=()):
    """prefer : cartes déjà présentes dans le deck du joueur, gardées à force à peu près égale."""
    staples = set(db.staples)
    prefer = {int(i) for i in prefer}
    pool = []
    for cid, q in owned.items():
        c = db.get(int(cid))
        if c and c["type"] not in ("Skill Card", "Token"):
            n = copies_allowed(c, q, assume3)
            if n:
                pool.append((c, n))

    if archetype is None:
        opts = archetype_options(db, owned, assume3, limit=1)
        archetype = opts[0]["name"] if opts else None

    def classify(c):
        if archetype and c["archetype"] == archetype:
            return 30, "Archétype"
        if archetype and _in_archetype(c, archetype):
            return 25, "Soutien d'archétype"
        if c["id"] in staples:
            return 15, "Staple"
        if c["archetype"]:  # carte d'un autre archétype : souvent inutile seule
            return -5, "Hors archétype"
        if c["type"] == "Normal Monster":
            return -3, "Remplissage"
        return 0, "Carte générique populaire"

    ranked = []
    for c, n in pool:
        bonus, reason = classify(c)
        if c["id"] in prefer:
            bonus += 2.5
        ranked.append((bonus + value(c), c, n, reason))
    ranked.sort(key=lambda x: -x[0])

    main, extra = [], []
    main_count = 0
    for score, c, n, reason in ranked:
        if kind(c) == "extra":
            if len(extra) < MAX_EXTRA and (reason != "Hors archétype" or len(extra) < 8):
                extra.append({"id": c["id"], "n": 1, "reason": reason})
            continue
        if main_count >= TARGET_MAIN:
            continue
        if reason in ("Carte générique populaire", "Remplissage", "Hors archétype"):
            n = min(n, 2 if reason == "Carte générique populaire" else 1)
        n = min(n, TARGET_MAIN - main_count)
        main.append({"id": c["id"], "n": n, "reason": reason, "score": score})
        main_count += n

    # 2e passe : si on n'atteint pas 40, on complète avec les exemplaires restants les mieux classés
    if main_count < TARGET_MAIN:
        in_main = {e["id"]: e for e in main}
        for score, c, n, reason in ranked:
            if main_count >= TARGET_MAIN or kind(c) == "extra":
                continue
            have = in_main[c["id"]]["n"] if c["id"] in in_main else 0
            extra_copies = min(n - have, TARGET_MAIN - main_count)
            if extra_copies <= 0:
                continue
            if c["id"] in in_main:
                in_main[c["id"]]["n"] += extra_copies
            else:
                e = {"id": c["id"], "n": extra_copies, "reason": reason, "score": score}
                main.append(e)
                in_main[c["id"]] = e
            main_count += extra_copies

    # équilibre : au moins ~13 monstres si la collection le permet
    def monsters():
        return sum(e["n"] for e in main if kind(db.get(e["id"])) == "monstre")
    used = {e["id"] for e in main}
    spare_monsters = [(s, c, n, r) for s, c, n, r in ranked
                      if kind(c) == "monstre" and c["id"] not in used]
    while monsters() < 13 and spare_monsters:
        weakest = min((e for e in main if kind(db.get(e["id"])) != "monstre"
                       and e["reason"] not in ("Archétype", "Soutien d'archétype", "Staple")),
                      key=lambda e: e["score"], default=None)
        if not weakest:
            break
        s, c, n, r = spare_monsters.pop(0)
        weakest["n"] -= 1
        if weakest["n"] == 0:
            main.remove(weakest)
        main.append({"id": c["id"], "n": 1, "reason": r, "score": s})

    counts = {"monstre": 0, "magie": 0, "piège": 0}
    for e in main:
        counts[kind(db.get(e["id"]))] += e["n"]
    total = sum(counts.values())

    warnings = []
    if not pool:
        warnings.append("Ta collection est vide : scanne ou ajoute tes cartes d'abord.")
    elif total < TARGET_MAIN:
        warnings.append(f"Pas assez de cartes jouables : {total}/40. Ajoute des cartes à ta collection.")
    if archetype is None and pool:
        warnings.append("Aucun archétype assez fourni : deck construit avec les meilleures cartes génériques.")
    if not assume3 and pool and all(q == 1 for q in owned.values()):
        warnings.append("Toutes tes cartes sont à 1 exemplaire : vérifie les quantités dans Collection, "
                        "ou coche « Supposer 3 exemplaires ».")

    owned_ids = {int(k) for k in owned}
    missing = []
    if archetype:
        members, support = db.archetype_cards(archetype)
        missing += [{"id": c["id"], "reason": "Archétype"} for c in members
                    if c["id"] not in owned_ids and c["ban_tcg"] != "Banned"][:10]
        missing += [{"id": c["id"], "reason": "Soutien"} for c in support
                    if c["id"] not in owned_ids and c["ban_tcg"] != "Banned"][:4]
    staple_cards = sorted((db.get(i) for i in staples), key=lambda c: -c["views"])
    missing += [{"id": c["id"], "reason": "Staple"} for c in staple_cards
                if c["id"] not in owned_ids and c["ban_tcg"] != "Banned"][:8]

    order = {"monstre": 0, "magie": 1, "piège": 2}
    main.sort(key=lambda e: (order[kind(db.get(e["id"]))], -e["score"]))
    for e in main:
        e.pop("score", None)
    return {
        "archetype": archetype,
        "main": main,
        "extra": extra,
        "counts": {**counts, "extra": len(extra), "main": total},
        "warnings": warnings,
        "missing": missing,
    }
