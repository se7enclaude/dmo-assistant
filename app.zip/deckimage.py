"""Reconnaissance d'un deck à partir d'une image (capture d'un deck trouvé sur Internet).

1. On détecte les cartes (rectangles au format 59×86) avec OpenCV, puis on complète la grille.
2. Chaque carte est identifiée par son nom (OCR, si lisible) ou par l'empreinte de son illustration.
3. Si aucune carte n'est détectée, on tente de lire une liste texte (« 3x Ash Blossom… »).
"""
import re
import statistics

import cv2
import numpy as np
from PIL import Image

CARD_RATIO = 59 / 86
ART_OK, ART_MAYBE = 34, 48  # seuils de distance d'empreinte


def _iou(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix = max(0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0, min(ay + ah, by + bh) - max(ay, by))
    inter = ix * iy
    return inter / float(aw * ah + bw * bh - inter)


def _contains(outer, inner, tol=4):
    ox, oy, ow, oh = outer
    ix, iy, iw, ih = inner
    return ix >= ox - tol and iy >= oy - tol and ix + iw <= ox + ow + tol and iy + ih <= oy + oh + tol


def detect_cards(img):
    """Rectangles (x, y, w, h) des cartes trouvées, dans l'ordre de lecture."""
    rgb = np.asarray(img.convert("RGB"))
    up = 2 if rgb.shape[1] < 1000 else 1
    if up > 1:
        rgb = cv2.resize(rgb, None, fx=up, fy=up, interpolation=cv2.INTER_CUBIC)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    rects = []
    for lo, hi in ((30, 120), (60, 180)):
        edges = cv2.Canny(cv2.GaussianBlur(gray, (3, 3), 0), lo, hi)
        edges = cv2.dilate(edges, np.ones((2, 2), np.uint8))
        contours, _ = cv2.findContours(edges, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            if h < 50 * up / 2 or w < 34 * up / 2:
                continue
            if not 0.62 <= w / h <= 0.76:
                continue
            if cv2.contourArea(cv2.convexHull(c)) < 0.82 * w * h:
                continue
            rects.append((x, y, w, h))
    # on garde le contour extérieur de chaque carte
    rects.sort(key=lambda r: -r[2] * r[3])
    kept = []
    for r in rects:
        if any(_contains(k, r) or _iou(k, r) > 0.4 for k in kept):
            continue
        kept.append(r)
    if not kept:
        return []
    med = statistics.median(r[3] for r in kept)
    kept = [r for r in kept if 0.75 * med <= r[3] <= 1.3 * med]
    kept = [tuple(int(v / up) for v in r) for r in kept]
    return _reading_order(kept)


def _reading_order(rects):
    if not rects:
        return []
    med = statistics.median(r[3] for r in rects)
    rows = []
    for r in sorted(rects, key=lambda r: r[1]):
        if rows and abs(rows[-1][0][1] - r[1]) < med * 0.4:
            rows[-1].append(r)
        else:
            rows.append([r])
    return [r for row in rows for r in sorted(row, key=lambda r: r[0])]


def _clusters(values, tol):
    out = []
    for v in sorted(values):
        if out and v - out[-1][-1] <= tol:
            out[-1].append(v)
        else:
            out.append([v])
    return [int(statistics.median(c)) for c in out]


def _lattice(values, size):
    """Origine et pas d'une grille régulière à partir des positions détectées (ou None)."""
    cl = _clusters(values, size * 0.3)
    if len(cl) < 2:
        return cl[0] if cl else None, None
    diffs = [b - a for a, b in zip(cl, cl[1:])]
    base = min(diffs)
    if not size * 0.95 <= base <= size * 1.6:
        return cl[0], None
    step = statistics.median(d / max(1, round(d / base)) for d in diffs)
    origin = statistics.median(v - round((v - cl[0]) / step) * step for v in cl)
    return origin, step


def fill_grid(img, rects, index):
    """Recale les cartes sur une grille régulière et ajoute celles dont le contour n'a pas été vu
    (cartes collées les unes aux autres, contours peu contrastés…)."""
    if len(rects) < 4:
        return rects
    w = int(statistics.median(r[2] for r in rects))
    h = int(statistics.median(r[3] for r in rects))
    W, H = img.size
    x0, sx = _lattice([r[0] for r in rects], w)
    y0, sy = _lattice([r[1] for r in rects], h)
    sx = sx or W  # une seule colonne / ligne : pas de répétition
    sy = sy or H
    xs = [x0 + i * sx for i in range(-int(x0 // sx), int((W - x0) // sx) + 1)]
    ys = [y0 + j * sy for j in range(-int(y0 // sy), int((H - y0) // sy) + 1)]
    out = list(rects)
    for y in ys:
        for x in xs:
            cand = (int(round(x)), int(round(y)), w, h)
            if cand[0] < -2 or cand[1] < -2 or cand[0] + w > W + 2 or cand[1] + h > H + 2:
                continue
            if any(_iou(cand, r) > 0.3 for r in out):
                continue
            crop = img.crop((cand[0], cand[1], cand[0] + w, cand[1] + h))
            if np.asarray(crop.convert("L"), dtype=np.float32).std() < 28:  # case vide (fond uni)
                continue
            m = index.match(crop, k=1) if index is not None else []
            if m and m[0][1] < ART_OK:
                out.append(cand)
    return _reading_order(out)


def _ocr_name(card_img, db, ocr):
    w, h = card_img.size
    bar = card_img.crop((int(w * 0.06), int(h * 0.035), int(w * 0.80), int(h * 0.115)))
    if bar.height < 9:  # trop petit pour être lu
        return None
    scale = max(1.0, 48 / bar.height)
    try:
        lines = ocr(bar, scale)
    except Exception:
        return None
    text = " ".join(l["text"] for l in lines)
    c, score = db.match(text, 84) if text else (None, 0)
    return c


def recognize(img, db, index, ocr=None):
    """Retourne {'cards': [{rect, id, conf, alts}], 'mode': 'image'|'texte'}."""
    img = img.convert("RGB")
    rects = detect_cards(img)
    if len(rects) >= 3 and index is not None:
        rects = fill_grid(img, rects, index)
    results = []
    for (x, y, w, h) in rects:
        crop = img.crop((x, y, x + w, y + h))
        matches = index.match(crop, k=6) if index is not None and len(index) else []
        if index is not None and (index.learned or not matches or matches[0][1] >= ART_OK):
            # carte façon DMO/anime (illustration en haut, barre en dessous) ou illustration apprise
            from artindex import ART_BOX_IN_ART
            from ingame import art_of
            alt = index.match(art_of(crop), k=6, box=ART_BOX_IN_ART)
            if alt and (not matches or alt[0][1] < matches[0][1]):
                matches = alt
        named = _ocr_name(crop, db, ocr) if ocr else None
        if named:
            cid, conf = named["id"], "sûr"
        elif matches:
            cid, d = matches[0]
            conf = "sûr" if d < ART_OK else "probable" if d < ART_MAYBE else "incertain"
        else:
            cid, conf = None, "incertain"
        alts = [m[0] for m in matches if m[0] != cid][:5]
        # inventaire DMO : badge de quantité + ATK lisible -> on vérifie / corrige avec l'ATK
        qty = None
        if index is not None and ocr is not None:
            from ingame import art_of, bar_kind, bar_subkind, identify, rank_candidates, read_quantity, read_stats
            qty = read_quantity(crop)
            if qty is not None:
                atk, pre = read_stats(crop)
                sub = bar_subkind(crop)
                card = db.get(cid) if cid is not None else None

                def fits(c):
                    """La carte proposée est-elle compatible avec ATK, début de DEF et Normal/Effet lus ?"""
                    if c is None or c["atk"] != atk:
                        return False
                    if pre and not str(c["def"]).startswith(pre):
                        return False
                    if sub and ("Normal" in c["type"]) != (sub == "normal"):
                        return False
                    return True

                if atk is not None and (not fits(card) or conf != "sûr"):
                    hints = {"atk_only": atk}
                    if pre:
                        hints["def_prefix"] = pre
                    if sub:
                        hints["sub"] = sub
                    k = bar_kind(crop)
                    if k:
                        hints["kind"] = k
                    ident = identify(art_of(crop), hints, db, index)
                    if ident and ident["how"] == "illustration" and not fits(db.get(ident["id"])):
                        ident = None  # l'illustration ressemble mais les chiffres lus disent autre chose
                    if ident:
                        cid, conf = ident["id"], ident["conf"]
                        alts = ident.get("alts") or alts
                    elif not fits(card):
                        conf = "incertain"
                        # par défaut la carte qui a vraiment ces stats et l'illustration la plus proche,
                        # les autres en propositions
                        ranked = rank_candidates(art_of(crop), hints, db, index)
                        if ranked:
                            cid, alts = ranked[0], ranked[1:]
                entry_stats = {"atk_read": atk, "def_read": pre}
        if cid is None:
            continue
        entry = {"rect": [x, y, w, h], "id": cid, "conf": conf, "alts": alts}
        if qty:
            entry.update(entry_stats)
            entry["qty"] = qty
        results.append(entry)
        for _ in range(min(qty or 1, 99) - 1):  # exemplaires supplémentaires (sans cadre sur l'image)
            results.append({**entry, "rect": None})
    if len(results) >= 3 or ocr is None:
        return {"cards": results, "mode": "image"}
    # pas de cartes visibles : liste texte ?
    lines = [l["text"] for l in ocr(img, 2.0 if img.width < 1200 else 1.0)]
    return {"cards": parse_text_list(lines, db), "mode": "texte"}


QTY = re.compile(r"^\s*(\d)\s*[x×]?\s+(.+)$|^(.+?)\s*[x×]\s*(\d)\s*$", re.I)


def parse_text_list(lines, db, unknown=None):
    """Une carte par ligne (ou séparées par « ; »), quantité optionnelle. unknown : reçoit les lignes non reconnues."""
    lines = [part for line in lines for part in str(line).split(";")]
    out = []
    for line in lines:
        line = line.strip(" -•*\t,")
        if not line or line.startswith(("#", "!")):
            continue
        if line.isdigit() and db.get(int(line)):
            out.append({"rect": None, "id": int(line), "conf": "sûr", "alts": []})
            continue
        qty, name = 1, line
        m = QTY.match(line)
        if m:
            qty, name = (int(m.group(1)), m.group(2)) if m.group(1) else (int(m.group(4)), m.group(3))
        c, score = db.match(name, 82)
        if c:
            conf = "sûr" if score >= 92 else "probable"
            alts = [a["id"] for a in db.search(name, limit=6) if a["id"] != c["id"]][:5] if conf != "sûr" else []
            for _ in range(max(1, min(qty, 3))):
                out.append({"rect": None, "id": c["id"], "conf": conf, "alts": alts})
        elif unknown is not None:
            unknown.append(line)
    return out
