"""Traduction automatique hors ligne (anglais → français) des textes de cartes sans version française officielle.

Modèle OPUS-MT (via Argos Translate, exécuté avec CTranslate2) + glossaire Yu-Gi-Oh! pour retrouver la
terminologie officielle française. Les noms de cartes entre guillemets sont remplacés par leur nom
français officiel s'il existe.
"""
import os
import re

import carddb

MODEL_DIR = os.path.join(carddb.DATA, "mt", "translate-en_fr-1_9")
CACHE_PATH = os.path.join(carddb.DATA, "translations_fr.json")

# corrections appliquées après traduction : (motif regex, remplacement)
GLOSSARY = [
    (r"\b[Ii]nvocation [Ss]péciale|\b[Cc]onvocation spéciale|\b[Ss]ommation spéciale|\b[Aa]ppel spécial", "Invocation Spéciale"),
    (r"\b[Ii]nvoqu(?:ez|er|é|ée|és|ées) [Ss]pécialement|\b[Cc]onvoqu(?:ez|er|é|ée|és|ées) spécialement|\b[Aa]ppel(?:ez|er) spécialement",
     lambda m: "Invoquez Spécialement" if m.group(0).lower().endswith("ez spécialement") else "Invoqué Spécialement"),
    (r"\b[Cc]onvocation [Nn]ormale|\b[Ss]ommation normale|\b[Aa]ppel normal", "Invocation Normale"),
    (r"\b[Cc]onvocation [Pp]ar [Ss]acrifice|\b[Cc]onvocation [Hh]ommage|\b[Hh]ommage [Cc]onvocation", "Invocation Sacrifice"),
    (r"\b[Cc]onvocation [Ff]lip|\b[Cc]onvocation [Rr]etournée", "Invocation Flip"),
    (r"\b[Cc]onvocation [Ss]ynchro", "Invocation Synchro"),
    (r"\b[Cc]onvocation [Ff]usion", "Invocation Fusion"),
    (r"\b[Cc]onvocation [Ll]ien|\b[Cc]onvocation [Ll]ink", "Invocation Lien"),
    (r"\b[Cc]onvocation [Xx]yz|\b[Cc]onvocation XYZ", "Invocation Xyz"),
    (r"\b[Cc]onvocation [Rr]ituelle", "Invocation Rituelle"),
    (r"\b[Cc]onvocation [Pp]endule", "Invocation Pendule"),
    (r"\b[Cc]onvoqu(?:ez|er)\b", "Invoquez"), (r"\b[Cc]onvoqu(?:é|ée|és|ées)\b", "Invoqué"),
    (r"\b[Cc]onvocations?\b", "Invocation"),
    (r"\b(?:[Ll]e |[Aa]u |[Dd]u )?[Cc]imetière|\b[Gg]raveyard\b|\b[Gg]rave\b|\b(?<!\w)GY\b", None),  # géré à part
    (r"\b[Pp]ont[- ][Mm]ort\b|\b[Cc]imetière de la tombe\b", "Cimetière"),
    (r"\b[Zz]one [Mm]onstre [Pp]rincipale", "Zone Monstre Principale"),
    (r"\b[Zz]one [Mm]onstre [Ss]upplémentaire|\b[Zz]one [Mm]onstre [Ee]xtra", "Zone Monstre Extra"),
    (r"\b[Zz]one [Dd]e [Mm]onstres?", "Zone Monstre"),
    (r"\b[Zz]one [Dd]e [Mm]agie(?:/| et | ou )[Pp]iège|\b[Zz]one [Ss]ort(?:/| et | ou )[Pp]iège", "Zone Magie & Piège"),
    (r"\b[Cc]artes? [Ss]ort(?:s)?\b", lambda m: "Cartes Magie" if m.group(0).lower().startswith("cartes") else "Carte Magie"),
    (r"\b[Ss]orts?/[Pp]ièges?|\b[Ss]ort(?:s)? et [Pp]iège(?:s)?", "Magie/Piège"),
    (r"\b[Dd]eck [Ss]upplémentaire|\b[Pp]ont [Ss]upplémentaire|\b[Ee]xtra [Dd]eck", "Extra Deck"),
    (r"\b[Pp]oints? de [Vv]ie|\b[Pp]oints? d'[Ee]xistence|\bLP\b", "LP"),
    (r"\b[Pp]hase de [Bb]ataille|\b[Pp]hase de [Cc]ombat", "Battle Phase"),
    (r"\b[Pp]hase [Pp]rincipale(?: 1)?", "Main Phase"),
    (r"\b[Pp]hase de [Ff]in\b|\b[Ff]in de [Pp]hase\b", "End Phase"),
    (r"\b[Pp]hase de [Pp]ioche|\b[Pp]hase de [Tt]irage", "Draw Phase"),
    (r"\b[Pp]hase de [Ss]tandby|\b[Pp]hase [Dd]e [Vv]eille|\b[Pp]hase d'attente", "Standby Phase"),
    (r"\b[Ee]ffet [Rr]apide|\b[Ee]ffet [Rr]apide", "Effet Rapide"),
    (r"\b[Mm]onstres? [Tt]uner|\b[Mm]onstres? [Aa]ccordeur", lambda m: "Monstres Syntoniseurs" if "s " in m.group(0) else "Monstre Syntoniseur"),
    (r"\b[Tt]uners?\b|\b[Aa]ccordeurs?\b", "Syntoniseur"),
    (r"\b[Mm]atériel(?:s)? Xyz|\b[Mm]atériaux Xyz", "Matériels Xyz"),
    (r"\b[Mm]atériaux de [Ff]usion", "Matériels de Fusion"), (r"\b[Mm]atériaux\b", "Matériels"),
    (r"\b[Dd]ans le sens du jeu|\b[Ff]ace vers le haut\b", "face recto"), (r"\b[Ff]ace vers le bas\b", "face verso"),
    (r"\b[Pp]osition de [Dd]éfense", "Position de Défense"), (r"\b[Pp]osition d'[Aa]ttaque", "Position d'Attaque"),
    (r"\b[Bb]anni(?:r|ssez)\b", "bannissez"), (r"\b[Jj]etons?\b", "Jeton"),
    (r"\b[Dd]éclenchement\b", "activation"), (r"\b[Ff]ois par tour\b", "fois par tour"),
    (r"\b[Nn]e peut être utilisé qu'une fois par tour", "ne peut être utilisé qu'une fois par tour"),
    (r"\bATK\b|\b[Aa]ttaque originale\b", "ATK"), (r"\bDEF\b", "DEF"),
    (r"\b[Cc]artes? Spell Quick-Play\b|\b[Cc]artes? (?:de )?[Ss]ort [Rr]apide\b",
     lambda m: "Cartes Magie Jeu-Rapide" if m.group(0).lower().startswith("cartes") else "Carte Magie Jeu-Rapide"),
    (r"\bSpell Quick-Play\b|\bQuick-Play Spell\b", "Magie Jeu-Rapide"), (r"\bQuick-Play\b", "Jeu-Rapide"),
    (r"\b[Cc]artes? Spell\b", lambda m: "Cartes Magie" if m.group(0).lower().startswith("cartes") else "Carte Magie"),
    (r"\b[Cc]artes? Trap\b", lambda m: "Cartes Piège" if m.group(0).lower().startswith("cartes") else "Carte Piège"),
    (r"\bSpell/Trap\b|\bSpells?/Traps?\b", "Magie/Piège"), (r"\bSpells?\b", "Magie"), (r"\bTraps?\b", "Piège"),
    (r"\b[Ee]ffet Quick\b|\b[Ee]ffet [Rr]apide\b", "Effet Rapide"),
    (r"\b[Ff]ace[- ]haut\b", "face recto"), (r"\b[Ff]ace[- ]bas\b", "face verso"),
    (r"\b(?:le |du |au |sur le |le )?[Cc]hamp\b", lambda m: m.group(0)[:-5] + "Terrain"),
    (r"\best Hommage\b|\best [Hh]ommagée?\b", "est Sacrifiée"), (r"\b[Hh]ommages?\b", "Sacrifice"),
    (r"\b[Dd]essin(?:er|ez)\b", lambda m: "piocher" if m.group(0).lower().endswith("er") else "piochez"),
    (r"\b[Jj]eter cette carte\b|\b[Jj]etez cette carte\b", "défausser cette carte"),
    (r"\b[Mm]atériau\b", "Matériel"),
    (r"\b[Ii]nvoquée? [Ss]péciale\b", "Invoquée Spécialement"), (r"\bSynchro Invoquée?\b", "Invoquée par Synchronisation"),
    (r"\bXyz Invoquée?\b", "Invoquée par Xyz"), (r"\bFusion Invoquée?\b", "Invoquée par Fusion"),
    (r"\bLien Invoquée?\b|\bLink Invoquée?\b", "Invoquée par Lien"),
    (r"\bDARK\b", "TÉNÈBRES"), (r"\bLIGHT\b", "LUMIÈRE"), (r"\bEARTH\b", "TERRE"), (r"\bWATER\b", "EAU"),
    (r"\bFIRE\b", "FEU"), (r"\bWIND\b", "VENT"), (r"\bDIVINE\b", "DIVIN"),
    (r"\[[Ee]ffet du [Pp]endule\]|\[[Ee]ffet [Pp]endulum\]", "[Effet Pendule]"), (r"\[[Ee]ffet [Mm]onstre\]", "[Effet de Monstre]"),
    (r"\b[Zz]one Pendulum\b", "Zone Pendule"), (r"\b[Éé]chelle Pendulum\b|\bl'échelle Pendulum\b", "Échelle Pendule"),
    (r"\bPendulum Monsters?\b", "Monstre Pendule"), (r"\bPendulum\b", "Pendule"),
    (r"\b[Cc]arte Monster\b", "Monstre"), (r"\bMonsters?\b", "Monstre"),
    (r"\bface-up\b", "face recto"), (r"\bface-down\b", "face verso"),
    (r"\b[Jj]et(?:er|ez) (\d+)\b", r"défausser \1"),
    (r"\b[Ii]nvoquez cette carte spéciale\b", "Invoquez Spécialement cette carte"),
    (r"\b[Ii]nvoquez spéciale(?:ment)?\b", "Invoquez Spécialement"),
    (r"\b(est|sont) [Nn]ormale?s? ou [Ss]péciale?s? [Ii]nvoquée?s?\b", r"\1 Invoquée Normalement ou Spécialement"),
    (r"\b(le|du|au|sur le) terrain\b", r"\1 Terrain"),
    (r"\b(est|sont) [Nn]ormale?s? [Ii]nvoquée?s?\b", r"\1 Invoquée Normalement"),
    (r"\b(est|sont) [Ss]péciale?s? [Ii]nvoquée?s?\b", r"\1 Invoquée Spécialement"),
    (r"\b[Ii]nvoquer [Ss]péciale\b", "Invoquer Spécialement"), (r"\b[Ii]nvoquer [Nn]ormale\b", "Invoquer Normalement"),
    (r"\b(?:que |de )?votre adversaire contrôles\b", "que votre adversaire contrôle"),
    (r"\b[Ii]nvoquée [Ss]pécialement [Ss]pécialement\b", "Invoquée Spécialement"),
    (r"(?<=: )[Vv]ous\b", "vous"),
]
TERMS_BEFORE = [  # remplacements faits sur l'anglais avant traduction (abréviations que le modèle ne connaît pas)
    (r"\bGY\b", "Graveyard"), (r"\bATK\b", "ATK"), (r"\bLP\b", "Life Points"),
]


def translate_missing(db, on_progress=None, batch=24):
    """Traduit (une fois, avec cache) toutes les cartes sans texte français officiel. Renvoie {id: texte}."""
    import json
    cache = {}
    if os.path.exists(CACHE_PATH):
        with open(CACHE_PATH, encoding="utf-8") as f:
            cache = json.load(f)
    names = {c["name_en"]: c["name_fr"] for c in db.cards.values() if c["desc_fr"]}
    todo = [c for c in db.cards.values() if not c["desc_fr"] and c["desc_en"] and str(c["id"]) not in cache]
    for i, c in enumerate(todo, 1):
        try:
            cache[str(c["id"])] = translate_card_text(c["desc_en"], names)
        except Exception:
            pass
        if i % 100 == 0 or i == len(todo):
            with open(CACHE_PATH + ".tmp", "w", encoding="utf-8") as f:
                json.dump(cache, f, ensure_ascii=False)
            os.replace(CACHE_PATH + ".tmp", CACHE_PATH)
            if on_progress:
                on_progress(i, len(todo))
    return cache
_translator = None
_sp = None


def available():
    return os.path.exists(os.path.join(MODEL_DIR, "model", "model.bin"))


def _load():
    global _translator, _sp
    if _translator is None:
        import ctranslate2
        import sentencepiece
        _translator = ctranslate2.Translator(os.path.join(MODEL_DIR, "model"), device="cpu", compute_type="int8",
                                             inter_threads=2)
        _sp = sentencepiece.SentencePieceProcessor(model_file=os.path.join(MODEL_DIR, "sentencepiece.model"))
    return _translator, _sp


def _fix_graveyard(text):
    text = re.sub(r"\b[Gg]raveyard\b|\b[Gg]rave\b|\b[Cc]imetières?\b", "Cimetière", text)
    return text


def _post(text):
    for pat, rep in GLOSSARY:
        if rep is None:
            continue
        text = re.sub(pat, rep, text)
    text = _fix_graveyard(text)
    text = re.sub(r"\s+([;:!?])", r" \1", text)          # espaces typographiques français
    text = re.sub(r"(?<=\w)([;:!?])", r" \1", text)
    text = text.replace(" ,", ",").replace(" .", ".")
    return text.strip()


def _split(text):
    """Découpe en lignes puis en phrases (les puces ● et numéros sont conservés)."""
    out = []
    for line in text.replace("\r", "").split("\n"):
        if not line.strip():
            out.append(("", ""))
            continue
        m = re.match(r"^(\s*(?:●|•|-|\(\d+\)|①|②|③|\d+\.)\s*)", line)
        prefix = m.group(1) if m else ""
        body = line[len(prefix):]
        parts = re.split(r"(?<=[.!?])\s+(?=[A-Z\"(●])", body)
        out.append((prefix, parts))
    return out


def translate_card_text(text, names_fr=None):
    """Traduit un texte de carte. names_fr : {nom anglais: nom français} pour les noms entre guillemets."""
    tr, sp = _load()
    names_fr = names_fr or {}
    holders = {}

    def protect(m):
        name = m.group(1)
        key = f"Z{len(holders)}Q"
        holders[key] = f'"{names_fr.get(name, name)}"'
        return key

    lines = _split(text)
    batch, where = [], []
    for li, (prefix, parts) in enumerate(lines):
        if not parts:
            continue
        for pi, part in enumerate(parts):
            src = re.sub(r'"([^"]+)"', protect, part)
            for pat, rep in TERMS_BEFORE:
                src = re.sub(pat, rep, src)
            batch.append(sp.encode(src, out_type=str))
            where.append((li, pi))
    results = tr.translate_batch(batch, beam_size=2, max_decoding_length=256) if batch else []
    out_lines = [[prefix, [""] * len(parts)] if parts else [prefix, []] for prefix, parts in lines]
    for (li, pi), res in zip(where, results):
        out_lines[li][1][pi] = "".join(res.hypotheses[0]).replace("▁", " ").strip()
    text_fr = "\n".join(prefix + " ".join(parts) for prefix, parts in out_lines)
    for key, val in holders.items():
        text_fr = re.sub(re.escape(key), val, text_fr, flags=re.I)
    return _post(text_fr)
