"""Mises à jour automatiques : le .exe lance le code du dossier app/, que l'on remplace par la dernière version publiée.

Le manifeste publié (version.json) a la forme :
  {"version": "1.2.0", "date": "2026-10-27", "zip": "<url de app.zip>", "sha256": "...",
   "launcher": 1, "download": "<page de téléchargement complet>",
   "history": [{"version": "1.2.0", "date": "...", "notes": ["...", "..."]}, ...]}
"""
import hashlib
import json
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile

import carddb

APP_DIR = carddb.APP_DIR
VERSION_PATH = os.path.join(APP_DIR, "version.json")
SOURCE_PATH = os.path.join(APP_DIR, "update.json")   # {"manifest": "<url de version.json>"}
LAUNCHER = int(os.environ.get("DMO_LAUNCHER", "0"))  # version du lanceur .exe (0 = lancé depuis les sources)


def _vt(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)


def newer(a, b):
    return _vt(a) > _vt(b)


def local():
    try:
        with open(VERSION_PATH, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"version": "0.0.0", "history": []}


def manifest_url():
    try:
        with open(SOURCE_PATH, encoding="utf-8") as f:
            return json.load(f).get("manifest") or None
    except Exception:
        return None


def enabled():
    """Seule la version .exe se met à jour (depuis les sources, c'est toi qui publies)."""
    return getattr(sys, "frozen", False) or LAUNCHER > 0


def _get(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": "DMO-Assistant-Updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def check():
    """Renvoie le manifeste distant s'il est plus récent que la version installée, sinon None."""
    url = manifest_url()
    if not url or not enabled():
        return None
    remote = json.loads(_get(url).decode("utf-8"))
    return remote if newer(remote.get("version"), local()["version"]) else None


def notes_between(history, old, new):
    """Entrées de l'historique strictement après `old`, jusqu'à `new` inclus (plus récentes d'abord)."""
    out = [h for h in history if newer(h["version"], old) and not newer(h["version"], new)]
    return sorted(out, key=lambda h: _vt(h["version"]), reverse=True)


def apply(remote):
    """Télécharge app.zip, vérifie son empreinte et remplace les fichiers du dossier app/."""
    if remote.get("launcher", 1) > max(LAUNCHER, 1):
        raise RuntimeError("Cette mise à jour demande de retélécharger l'application complète.")
    data = _get(remote["zip"], timeout=120)
    if remote.get("sha256") and hashlib.sha256(data).hexdigest() != remote["sha256"]:
        raise RuntimeError("Fichier de mise à jour corrompu (empreinte différente).")
    tmp = tempfile.mkdtemp(prefix="dmo_update_")
    try:
        zpath = os.path.join(tmp, "app.zip")
        with open(zpath, "wb") as f:
            f.write(data)
        out = os.path.join(tmp, "app")
        with zipfile.ZipFile(zpath) as z:
            for name in z.namelist():  # refuse les chemins qui sortiraient du dossier
                dest = os.path.realpath(os.path.join(out, name))
                if not dest.startswith(os.path.realpath(out) + os.sep):
                    raise RuntimeError("Archive de mise à jour invalide.")
            z.extractall(out)
        # tout est extrait sans erreur : on remplace fichier par fichier (le cache d'images est conservé)
        for dirpath, _, files in os.walk(out):
            rel = os.path.relpath(dirpath, out)
            os.makedirs(os.path.join(APP_DIR, rel), exist_ok=True)
            for fn in files:
                shutil.copy2(os.path.join(dirpath, fn), os.path.join(APP_DIR, rel, fn))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return local()
