"""Sélection d'une zone d'écran (lancé en sous-processus). Affiche 'x y w h', 'reset' ou rien."""
import ctypes
import sys
import tkinter as tk

import mss

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    pass

DECK_MODE = len(sys.argv) > 1 and sys.argv[1] == "deck"
ART_MODE = len(sys.argv) > 1 and sys.argv[1] == "art"

with mss.mss() as sct:
    v = sct.monitors[0]

root = tk.Tk()
root.overrideredirect(True)
root.attributes("-topmost", True)
root.attributes("-alpha", 0.4)
root.geometry(f"{v['width']}x{v['height']}+{v['left']}+{v['top']}")
cv = tk.Canvas(root, bg="black", highlightthickness=0, cursor="crosshair")
cv.pack(fill="both", expand=True)

with mss.mss() as sct:
    for m in sct.monitors[1:]:
        cx, cy = m["left"] - v["left"] + m["width"] // 2, m["top"] - v["top"]
        if ART_MODE:
            cv.create_text(cx, cy + 70, fill="white", font=("Segoe UI Semibold", 22),
                           text="Encadre la CARTE ENTIÈRE affichée en détail (illustration + barre ATK/DEF)")
            cv.create_text(cx, cy + 110, fill="#cfd3dc", font=("Segoe UI", 13),
                           text="Échap : annuler   ·   Clic droit : supprimer la zone (retour au mode souris)")
        elif DECK_MODE:
            cv.create_text(cx, cy + 70, fill="white", font=("Segoe UI Semibold", 22),
                           text="Encadre les cartes du deck à importer")
            cv.create_text(cx, cy + 110, fill="#cfd3dc", font=("Segoe UI", 13), text="Échap : annuler")
        else:
            cv.create_text(cx, cy + 70, fill="white", font=("Segoe UI Semibold", 22),
                           text="Encadre le NOM de la carte dans le jeu")
            cv.create_text(cx, cy + 110, fill="#cfd3dc", font=("Segoe UI", 13),
                           text="Échap : annuler   ·   Clic droit : scanner tout l'écran (pas de zone)")

state = {}


def press(e):
    state["x"], state["y"] = e.x, e.y
    state["r"] = cv.create_rectangle(e.x, e.y, e.x, e.y, outline="#f5c451", width=3)


def move(e):
    if "r" in state:
        cv.coords(state["r"], state["x"], state["y"], e.x, e.y)


def release(e):
    if "x" not in state:
        return
    x, y = min(state["x"], e.x), min(state["y"], e.y)
    w, h = abs(e.x - state["x"]), abs(e.y - state["y"])
    if w > 10 and h > 5:
        print(x + v["left"], y + v["top"], w, h)
    root.destroy()


def reset(e):
    if not DECK_MODE:
        print("reset")
    root.destroy()


cv.bind("<ButtonPress-1>", press)
cv.bind("<B1-Motion>", move)
cv.bind("<ButtonRelease-1>", release)
cv.bind("<Button-3>", reset)
root.bind("<Escape>", lambda e: root.destroy())
root.after(100, root.focus_force)
root.mainloop()
sys.stdout.flush()
